# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import QTableWidget, QVBoxLayout


class Sport(object):
    def setupUi(self, SportCode):
        conLayout = QVBoxLayout()
        self.tblw_center = QTableWidget()
        conLayout.addWidget(self.tblw_center)
        SportCode.setLayout(conLayout)
