import sys

from PyQt5.QtWidgets import *
import cls_database
from func_json import *
from frm_display_code import cod_display
from frm_main import *
# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import QTableWidget, QVBoxLayout

class cod_main(QWidget, Ui_Form):
	def __init__(self, table_params):
		super(cod_main, self).__init__()
		self.setupUi(self)

		self.table_params = table_params
		self.path="./initialize/confige.ini"
		params = read_file(self.path)
		self.load_dictfile(self.tbwgt_center,params)
		self.tbwgt_center.resizeColumnsToContents()  # 与内容同宽

		self.btn_OK.clicked.connect(self.Ok)
		self.btn_Cancel.clicked.connect(self.Cancel)

	def Cancel(self):
		if QMessageBox.Ok == QMessageBox.information(self, "提示", "确定退出!", QMessageBox.Cancel | QMessageBox.Ok):
			self.close()

	def Ok(self):
		self.save_dictfile(self.tbwgt_center,self.path)
		self.close()
		self.y=cod_display(self)
		self.y.show()

	def save_dictfile(self,tablewidget,path):
		'''保存配置文件'''
		args={}
		rows = tablewidget.rowCount()
		if (rows == 0) : return False
		for row in range(0,rows):
			tag = tablewidget.item(row, 0).text()
			prop = tablewidget.item(row, 1).text()
			args[tag] = prop
		write_file(self.path,args)
		return True

	def load_dictfile(self, tablewidget, params):
		"""加载配置文件"""
		tablewidget.setColumnCount(2)  # 设定列数
		tablewidget.setHorizontalHeaderLabels(['tag','property'])  # 设置表头内容
		# 加载数据到表格
		i = 0
		for row in params.items():
			j = 0
			tablewidget.setRowCount(i + 1)
			for cln in row:
				tablewidget.setItem(i, j, QTableWidgetItem(str(cln)))
				j += 1
			i += 1
		self.column = tablewidget.columnCount()

		
if __name__ == '__main__':
	app = QApplication(sys.argv)
	example = cod_main("hello")
	example.show()
	sys.exit(app.exec_())