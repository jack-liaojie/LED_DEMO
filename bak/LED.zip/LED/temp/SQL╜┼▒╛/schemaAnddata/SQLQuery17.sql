DECLARE @Result int EXEC Proc_InitialDownload_IntiTempRegisterTable @Result output
select @Result