-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.20 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 导出 eq 的数据库结构
CREATE DATABASE IF NOT EXISTS `eq` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `eq`;

-- 导出  存储过程 eq.proc_AddCity 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCity`(
in CityCode VARCHAR(10),
in LanguageCode CHAR(3),
in CityLongName VARCHAR(50),
in CityShortName VARCHAR(50),
in CityComment VARCHAR(50),
out Result int)
LABEL:begin
declare NewCityID int;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result = 0;  
  

START TRANSACTION;

INSERT INTO TC_City (F_CityCode) VALUES (CityCode);

SET NewCityID = @@IDENTITY;

    INSERT INTO TC_City_Des (F_CityID, F_LanguageCode, F_CityLongName, F_CityShortName, F_CityComment) 
    VALUES(NewCityID, LanguageCode, CityLongName, CityShortName, CityComment);

COMMIT; 
SET Result = NewCityID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddClub 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddClub`(
in ClubCode VARCHAR(10),
    in LanguageCode CHAR(3),
in ClubLongName VARCHAR(50),
in ClubShortName VARCHAR(50),
out Result INT)
LABEL:begin
declare NewClubID int;

declare f_error int default 0;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result = 0;  
  

START TRANSACTION;

INSERT INTO TC_CLub (F_ClubCode) VALUES (ClubCode);

SET NewClubID = @@IDENTITY;

    INSERT INTO TC_Club_Des (F_CLubID, F_LanguageCode, F_ClubLongName, F_ClubShortName) 
    VALUES(NewClubID, LanguageCode, ClubLongName, ClubShortName);

COMMIT; 
SET Result = NewClubID;


end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddColor 结构
DELIMITER //
CREATE PROCEDURE `proc_AddColor`(
in LanguageCode CHAR(3),
in ColorLongName VARCHAR(100),
in ColorShortName VARCHAR(50),
in ColorComment VARCHAR(100),
out Result INT
)
LABEL:begin
declare NewColorID int;

declare f_error int default 0;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result = 0;  
  

START TRANSACTION;

IF (SELECT count(*) FROM TC_Color)>0 then
      SELECT NewColorID = MAX(F_ColorID) FROM TC_Color;
      SET NewColorID = NewColorID + 1;
    ELSE
      SET NewColorID = 1;
    end if;

INSERT INTO TC_Color (F_ColorID) VALUES(NewColorID);

SET NewColorID = @@IDENTITY;

    INSERT INTO TC_Color_Des (F_ColorID, F_LanguageCode, F_ColorLongName, F_ColorShortName, F_ColorComment) 
    VALUES(NewColorID, LanguageCode, ColorLongName, ColorShortName, ColorComment);
COMMIT; 
SET Result = NewColorID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddComment 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddComment`(
in RegisterID INT,
in aorder INT,
in Title VARCHAR(50),
in Comment VARCHAR(50),
out Result INT
)
LABEL:begin
declare NewCommentID int;
DECLARE NewOrder INT;

declare f_error int default 0;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result = 0;  
 
                     
IF (SELECT count(*) FROM TR_Register_Comment 
WHERE F_RegisterID = RegisterID AND F_Title = Title AND Title IS NOT NULL)>0 then
      SET Result = -1;
  leave LABEL;
end if;
  
SELECT NewCommentID = (CASE WHEN MAX(F_CommentID) IS NULL THEN 0 ELSE MAX(F_CommentID) END) + 1 
FROM TR_Register_Comment;
    SELECT NewOrder = (CASE WHEN MAX(F_Comment_Order) IS NULL THEN 0 ELSE MAX(F_Comment_Order) END) + 1 
    FROM TR_Register_Comment WHERE F_RegisterID = RegisterID;
    
    START TRANSACTION;

INSERT INTO TR_Register_Comment (F_CommentID, F_RegisterID, F_Comment_Order, F_Title, F_Comment) 
        VALUES (NewCommentID, RegisterID, NewOrder, Title, Comment);

COMMIT; 
SET Result = NewCommentID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonCity 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonCity`(
    out Result int
    )
LABEL:begin
    declare CityID int;
    
    declare f_error int default 0;
    
    declare exit handler for sqlexception 
    err:begin
        ROLLBACK; 
        SET Result=0;
    end err;
    
    set autocommit = 0;
    SET Result = 0;  
                      
    
    START TRANSACTION;
    
    IF (SELECT F_CityID FROM TC_City WHERE F_CityCode = 'SZR')>0 then
        SELECT @CityID = F_CityID FROM TC_City WHERE F_CityCode = 'SZR';
    ELSE
        INSERT INTO TC_City (F_CityCode) VALUES ('SZR');
        
    end if;
    
    SET CityID = @@IDENTITY;
    
    DELETE FROM TC_City_Des WHERE F_CityID = CityID;
    
    INSERT INTO TC_City_Des (F_CityID, F_LanguageCode, F_CityLongName, F_CityShortName, F_CityComment) 
    VALUES(CityID, 'CHN', '深圳', '深圳', '');

    INSERT INTO TC_City_Des (F_CityID, F_LanguageCode, F_CityLongName, F_CityShortName, F_CityComment) 
    VALUES(CityID, 'ENG', 'ShengZhen', 'ShengZhen', '');
    
    COMMIT; 
    SET Result = CityID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonCountry 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonCountry`(
    in F_NOC CHAR(3),
    in LanguageCode CHAR(3),
    in CountryLongName VARCHAR(100),
    in CountryShortName VARCHAR(50),
    out Result INT
    )
LABEL:begin
    
    declare f_error int default 0;
    
    declare exit handler for sqlexception 
    err:begin
        ROLLBACK; 
        SET Result=0;
    end err;
    
    set autocommit = 0;
    SET Result = 0;  
                      
    
    START TRANSACTION;
    
    IF (SELECT count(*) FROM TC_Country WHERE F_NOC = NOC) >0 then

        INSERT INTO TC_Country (F_NOC) VALUES (NOC);
        
    end if;

    DELETE FROM TC_Country_Des WHERE F_NOC = NOC AND F_LanguageCode = LanguageCode;

    INSERT INTO TC_Country_Des (F_NOC, F_LanguageCode, F_CountryLongName, F_CountryShortName)
        VALUES(NOC, LanguageCode, CountryLongName, CountryShortName);
    COMMIT; 
    SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonCourt 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonCourt`(
  in VenueCode varchar(50),
  in CourtCode varchar(10),
  in LanguageCode  CHAR(3),
  in CourtLongName  varchar(50),
  in CourtShortName  varchar(50),
  in CourtComment  varchar(50),
  in DisciplineCode  CHAR(2),
  out Result  INT
)
LABEL:begin
    DECLARE VenueID  INT;
    DECLARE CourtID  INT;
    DECLARE DisciplineID  INT;

    
    declare f_error int default 0;
    
    declare exit handler for sqlexception 
    err:begin
        ROLLBACK; 
        SET Result=0;
    end err;

    
    set autocommit = 0;
    set Result = 0;  

    IF (SELECT count(*) FROM TC_Venue WHERE F_VenueCode =  VenueCode) >0 then
        SELECT VenueID = F_VenueID FROM TC_Venue WHERE F_VenueCode = VenueCode limit 1;
    ELSE
        SET Result = -1;
        leave LABEL;
    end if;

    START TRANSACTION;

    IF (SELECT count(*) FROM TC_Court WHERE F_CourtCode = CourtCode)<>0 then
        SELECT CourtID = F_CourtID FROM TC_Court WHERE F_CourtCode = CourtCode limit 1;
        UPDATE TC_Court SET F_VenueID = VenueID WHERE F_CourtID = CourtID AND F_CourtCode = CourtCode;

    ELSE
        INSERT INTO TC_Court (F_VenueID, F_CourtCode) VALUES (VenueID, CourtCode);

        SET CourtID = @@IDENTITY;

    END IF;

    
    IF (SELECT count(*) FROM TC_Country WHERE F_NOC = NOC) >0 then

        INSERT INTO TC_Country (F_NOC) VALUES (NOC);

    end if;

    DELETE FROM TC_Court_Des WHERE F_CourtID = CourtID AND F_LanguageCode = LanguageCode;

    INSERT INTO TC_Court_Des (F_CourtID, F_LanguageCode, F_CourtLongName, F_CourtShortName, F_CourtComment) 
    VALUES(CourtID, LanguageCode, CourtLongName, CourtShortName, CourtComment);

    IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineCode = DisciplineCode)>0 then
        SELECT DisciplineID = F_DisciplineID FROM TS_Discipline WHERE F_DisciplineCode = DisciplineCode limit 1;
        IF (SELECT count(*) FROM TD_Discipline_Venue WHERE F_DisciplineID = DisciplineID AND F_VenueID = VenueID)>0 then
              INSERT INTO TD_Discipline_Venue (F_DisciplineID, F_VenueID) VALUES(DisciplineID, VenueID);
                      
        end if;
    end if;

    COMMIT; 
    SET Result = CourtID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonDelegation 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonDelegation`(
in DelegationCode  VARCHAR(10),
    in DelegationType  VARCHAR(10),
    in LanguageCode  CHAR(3),
in DeleLongName  VARCHAR(100),
in DeleShortName  VARCHAR(100),
    in DeleComment  VARCHAR(50),
out Result  INT
)
LABEL:begin
declare NewCityID int;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result = 0;  
  

START TRANSACTION;
IF (SELECT count(*) FROM TC_Delegation_Des WHERE F_DelegationComment = DeleComment)>0 then
      SELECT DelegationID = F_DelegationID FROM TC_Delegation_Des WHERE F_DelegationComment = DeleComment limit 1;
      UPDATE TC_Delegation SET F_DelegationType = DelegationType WHERE F_DelegationID = DelegationID;
    ELSE
      INSERT INTO TC_Delegation (F_DelegationCode, F_DelegationType) 
      VALUES(DelegationCode, DelegationType);
      SET NewCityID = @@IDENTITY;
    END IF;

DELETE FROM TC_Delegation_Des WHERE F_DelegationID = DelegationID AND F_LanguageCode = LanguageCode;

    INSERT INTO TC_Delegation_Des (F_DelegationID, F_LanguageCode, F_DelegationLongName, F_DelegationShortName, F_DelegationComment)
        VALUES(DelegationID, LanguageCode, DeleLongName, DeleShortName, DeleComment);

COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonEvent 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonEvent`(
in DisciplineCode  CHAR(2),
in EventCode  varchar(10),
in GenderCode  varchar(10),
in languageCode  CHAR(3),
in EventLongName  varchar(100),
in EventShortName varchar(50),
out Result  INT 
)
LABEL:begin

    DECLARE DisciplineID int;
DECLARE EventID int;
    DECLARE SexCode int;
    DECLARE Aorder int;

declare NewCityID int;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  


    IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineCode = DisciplineCode)=0 then
SET Result = -1;
leave LABEL;
    ELSE
        SELECT DisciplineID = F_DisciplineID FROM TS_Discipline WHERE F_DisciplineCode = DisciplineCode;
    end if;

SELECT AOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 FROM TS_Event WHERE F_DisciplineID = DisciplineID;

    IF (SELECT F_SexCode FROM TC_Sex WHERE F_GenderCode = GenderCode)=0 then
SET Result = -2;
leave LABEL;
    ELSE
        SELECT SexCode = F_SexCode FROM TC_Sex WHERE F_GenderCode = GenderCode limit 1;
    end if;

START TRANSACTION;

IF (SELECT count(*) FROM TS_Event WHERE F_DisciplineID = DisciplineID AND F_EventCode = EventCode AND F_SexCode = SexCode)>0 then
        SELECT EventID = F_EventID FROM TS_Event WHERE F_DisciplineID = DisciplineID AND F_EventCode = EventCode AND F_SexCode = SexCode;
    ELSE
        INSERT INTO TS_Event (F_DisciplineID, F_EventCode, F_Order, F_SexCode) VALUES (DisciplineID, EventCode, Aorder, SexCode);
SET EventID = @@IDENTITY;

end if;

DELETE FROM TS_Event_Des WHERE F_EventID = EventID AND F_LanguageCode = languageCode;

INSERT INTO TS_Event_Des (F_EventID, F_LanguageCode, F_EventLongName, F_EventShortName)
VALUES (EventID, languageCode, EventLongName, EventShortName);

COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddCommonFunction 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddCommonFunction`(
 in DisciplineID  INT,
    in FunctionCode  VARCHAR(10),
    in FunctionCategoryCode VARCHAR(50),
in LanguageCode CHAR(3),
in FunctionLongName VARCHAR(50),
in FunctionShortName VARCHAR(50),
in FunctionComment VARCHAR(50),
in Result INT 
)
LABEL:begin
DECLARE FunctionID INT;
declare NewCityID int;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineID = DisciplineID) =0 then
      SET Result = -1;
      leave LABEL;
    END if;

START TRANSACTION;

    IF (SELECT count(*) FROM TD_Function WHERE F_FunctionCode = FunctionCode AND F_DisciplineID = DisciplineID)>0 then
      SELECT FunctionID = F_FunctionID FROM TD_Function WHERE F_FunctionCode = FunctionCode AND F_DisciplineID = DisciplineID limit 1;
      UPDATE TD_Function SET F_FunctionCategoryCode = FunctionCategoryCode WHERE F_FunctionID = FunctionID;
ELSE
        SELECT FunctionID = (CASE WHEN MAX(F_FunctionID) IS NULL THEN 0 ELSE MAX(F_FunctionID) END) + 1 FROM TD_Function;
        INSERT INTO TD_Function (F_FunctionID, F_DisciplineID, F_FunctionCode, F_FunctionCategoryCode) 
        VALUES(FunctionID, DisciplineID, FunctionCode, FunctionCategoryCode);
END if;

    DELETE FROM TD_Function_Des WHERE F_FunctionID = FunctionID AND F_LanguageCode = LanguageCode;
    INSERT INTO TD_Function_Des (F_FunctionID, F_LanguageCode, F_FunctionLongName, F_FunctionShortName, F_FunctionComment)
VALUES(FunctionID, LanguageCode, FunctionLongName, FunctionShortName, FunctionComment);

    DELETE FROM TC_RegtypeFunction WHERE F_FunctionID = FunctionID;
    INSERT INTO TC_RegtypeFunction (F_RegtypeID, F_FunctionID)
    SELECT F_RegTypeID, FunctionID AS F_FunctionID FROM TC_RegType WHERE F_RegTypeCode = FunctionCategoryCode limit 1;

COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddCommonPosition 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddCommonPosition`(
in DisciplineID INT,
    in PositionCode varchar(10),
in LanguageCode CHAR(3),
in PositionLongName varchar(50),
in PositionShortName varchar(50),
in PositionComment varchar(50),
out Result  INT
)
LABEL:begin
DECLARE PositionID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

    IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineID = DisciplineID) =0 then
      SET Result = -1;
      leave label;
    END if;

START TRANSACTION;

    IF (SELECT count(*) FROM TD_Position WHERE F_PositionCode = PositionCode AND F_DisciplineID = DisciplineID)>0 then
      SELECT PositionID = F_PositionID FROM TD_Position WHERE F_PositionCode = PositionCode AND F_DisciplineID = DisciplineID limit 1;
ELSE
        SELECT PositionID = (CASE WHEN MAX(F_PositionID) IS NULL THEN 0 ELSE MAX(F_PositionID) END) + 1 FROM TD_Position;
        INSERT INTO TD_Position (F_PositionID, F_DisciplineID, F_PositionCode) VALUES(PositionID, DisciplineID, PositionCode);

END if;

    DELETE FROM TD_Position_Des WHERE F_PositionID = PositionID AND F_LanguageCode = LanguageCode;

    INSERT INTO TD_Position_Des (F_PositionID, F_LanguageCode, F_PositionLongName, F_PositionShortName, F_PositionComment) 
VALUES(PositionID, LanguageCode, PositionLongName, PositionShortName, PositionComment);

COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCommonVenue 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCommonVenue`(
in VenueCode varchar(10),
    in LanguageCode CHAR(3),
in VenueLongName varchar(100),
in VenueShortName varchar(100),
in VenueComment varchar(50),
in Result INT
)
LABEL:begin

DECLARE VenueID INT;
    DECLARE CityID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  


    IF (SELECT count(*) FROM TC_City WHERE F_CityCode = 'SZR')>0 then
        SELECT CityID = F_CityID FROM TC_City WHERE F_CityCode = 'SZR';
    ELSE
        SET Result = -1;
        leave LABEL;
    END if;
    

START TRANSACTION;
 IF (SELECT count(*) FROM TC_Venue WHERE F_VenueCode = VenueCode)>0 then
        SELECT VenueID = F_VenueID FROM TC_Venue WHERE F_VenueCode = VenueCode limit 1;
        UPDATE TC_Venue SET F_CityID = CityID WHERE F_VenueID = VenueID AND F_VenueCode = VenueCode;
    ELSE
        INSERT INTO TC_Venue (F_CityID, F_VenueCode) VALUES (CityID, VenueCode);
    END if;

    DELETE FROM TC_Venue_Des WHERE F_VenueID = VenueID AND F_LanguageCode = LanguageCode;

    INSERT INTO TC_Venue_Des (F_VenueID, F_LanguageCode, F_VenueLongName, F_VenueShortName, F_VenueComment) 
    VALUES(VenueID, LanguageCode, VenueLongName, VenueShortName, VenueComment);

        
COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddCommonWeatherType 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddCommonWeatherType`(
in WeatherCode VARCHAR(10),
in LanguageCode CHAR(3),
in WeatherTypeLongDescription VARCHAR(50),
in WeatherTypeShortDescription VARCHAR(50),
in Result INT
)
LABEL:begin

DECLARE WeatherTypeID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

START TRANSACTION;

IF (SELECT count(*) FROM TC_WeatherType WHERE F_WeatherCode = WeatherCode)>0 then
      SELECT WeatherTypeID = F_WeatherTypeID FROM TC_WeatherType WHERE F_WeatherCode = WeatherCode limit 1;
ELSE
    SELECT WeatherTypeID = (CASE WHEN MAX(F_WeatherTypeID) IS NULL THEN 0 ELSE MAX(F_WeatherTypeID) END) + 1 FROM TC_WeatherType;
    INSERT INTO TC_WeatherType (F_WeatherTypeID, F_WeatherCode) VALUES(WeatherTypeID, WeatherCode);

END if;

    DELETE FROM TC_WeatherType_Des WHERE F_WeatherTypeID = WeatherTypeID AND F_LanguageCode = LanguageCode;
    INSERT INTO TC_WeatherType_Des (F_WeatherTypeID, F_LanguageCode, F_WeatherTypeLongDescription, F_WeatherTypeShortDescription) 
VALUES(WeatherTypeID, LanguageCode, WeatherTypeLongDescription, WeatherTypeShortDescription);

COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddCommonWindDirection 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddCommonWindDirection`(
in WindCode varchar(10),
    in aOrder NCHAR(10),
in LanguageCode CHAR(3),
in WindDirectionLongName varchar(100),
in WindDirectionShortName varchar(50),
    in WindDirectionComment varchar(100),
out Result INT
)
LABEL:begin

DECLARE WinderDirectionID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  


    

START TRANSACTION;
IF (SELECT F_WindDirectionID FROM TC_WindDirection WHERE F_WindDirectionCode = WindCode)>0 THEN
      SELECT WinderDirectionID = F_WindDirectionID FROM TC_WindDirection WHERE F_WindDirectionCode = WindCode limit 1;

ELSE
        SELECT WinderDirectionID = (CASE WHEN MAX(F_WindDirectionID) IS NULL THEN 0 ELSE MAX(F_WindDirectionID) END) + 1 FROM TC_WindDirection;
        INSERT INTO TC_WindDirection (F_WindDirectionID, F_WindDirectionCode, F_Order) VALUES(WinderDirectionID, WindCode, aOrder);

END if;

    DELETE FROM TC_WindDirection_Des WHERE F_WindDirectionID = WinderDirectionID AND F_LanguageCode = LanguageCode;
    INSERT INTO TC_WindDirection_Des (F_WindDirectionID, F_LanguageCode, F_WindDirectionLongName, F_WindDirectionShortName, F_WindDirectionComment) 
VALUES(WinderDirectionID, LanguageCode, WindDirectionLongName, WindDirectionShortName, WindDirectionComment);


COMMIT; 
SET Result = EventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCompetitionPosition 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCompetitionPosition`(
in MatchID INT,
out Result INT
)
LABEL:begin
DECLARE CompetitionPosition INT;
DECLARE CompetitionPositionDes1 INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT F_MatchID FROM TS_Match WHERE F_MatchID = MatchID)=0 THEN
SET Result = -1;
leave LABEL;
END if;

SELECT CompetitionPosition = (CASE WHEN MAX(F_CompetitionPosition) IS NULL THEN 0 ELSE MAX(F_CompetitionPosition) END) + 1 
FROM TS_Match_Result WHERE F_MatchID = MatchID;

SELECT CompetitionPositionDes1 = (CASE WHEN MAX(F_CompetitionPositionDes1) IS NULL THEN 0 ELSE MAX(F_CompetitionPositionDes1) END) + 1 
FROM TS_Match_Result WHERE F_MatchID = MatchID;

START TRANSACTION;
INSERT INTO TS_Match_Result (F_MatchID, F_CompetitionPosition, F_CompetitionPositionDes1) VALUES (MatchID, CompetitionPosition, CompetitionPositionDes1);

INSERT INTO TS_Match_Split_Result (F_MatchID, F_MatchSplitID, F_FatherMatchSplitID, F_CompetitionPosition)
SELECT F_MatchID, F_MatchSplitID, F_FatherMatchSplitID, CompetitionPosition AS F_CompetitionPosition
FROM TS_Match_Split_info WHERE F_MatchID = MatchID;

COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCountry 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCountry`(
in NOC CHAR(3),
    in LanguageCode CHAR(3),
in CountryLongName VARCHAR(100),
in CountryShortName VARCHAR(50),
in Result INT 
)
LABEL:begin



declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

    IF (SELECT F_NOC FROM TC_Country WHERE F_NOC = NOC)>0 then
SET Result = -1;
leave LABEL;
END if;
    

START TRANSACTION;
INSERT INTO TC_Country (F_NOC) VALUES (NOC);
    INSERT INTO TC_Country_Des (F_NOC, F_LanguageCode, F_CountryLongName, F_CountryShortName)
            VALUES(NOC, LanguageCode, CountryLongName, CountryShortName);

COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddCourt 结构
DELIMITER //
CREATE PROCEDURE `proc_AddCourt`(
in VenueID VARCHAR(10),
    in LanguageCode CHAR(3),
in CourtLongName VARCHAR(50),
in CourtShortName VARCHAR(50),
in CourtComment VARCHAR(50),
    in CourtCode VARCHAR(10),
    in CourtOrder INT,
out Result INT
)
LABEL:begin
DECLARE NewCourtID  INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
    
    IF VenueID IS NOT NULL then
       IF (SELECT count(*) FROM TC_Venue WHERE F_VenueID = VenueID)=0 then
SET Result=-1;
leave label;
   END if;
       IF (SELECT count(*) FROM TC_Court WHERE F_VenueID = VenueID AND F_CourtCode = CourtCode)>0 then
            SET Result=-2;
leave label;
       END if;
    END if;

START TRANSACTION;
INSERT INTO TC_Court (F_VenueID, F_CourtCode, F_Order) VALUES (VenueID, CourtCode,CourtOrder);

SET NewCourtID = @@IDENTITY;

    INSERT INTO TC_Court_Des (F_CourtID, F_LanguageCode, F_CourtLongName, F_CourtShortName, F_CourtComment) 
    VALUES(NewCourtID, LanguageCode, CourtLongName, CourtShortName, CourtComment);

COMMIT; 
SET Result = NewCourtID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddDelegation 结构
DELIMITER //
CREATE PROCEDURE `proc_AddDelegation`(
in DelegationCode VARCHAR(10),
    in LanguageCode CHAR(3),
in DelegationLongName VARCHAR(50),
in DelegationShortName VARCHAR(50),
in DelegationComment VARCHAR(50),
    in DelegationType VARCHAR(10),
out Result INT
)
LABEL:begin

DECLARE NewDelegationID  INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TC_Delegation WHERE F_DelegationCode = DelegationCode)>0 then
SET Result = -1;
leave label;
END if;
   

START TRANSACTION;
INSERT INTO TC_Delegation (F_DelegationCode, F_DelegationType) VALUES (DelegationCode, DelegationType);

SET NewDelegationID = @@IDENTITY;

    INSERT INTO TC_Delegation_Des (F_DelegationID, F_LanguageCode, F_DelegationLongName, F_DelegationShortName, F_DelegationComment) 
    VALUES(NewDelegationID, LanguageCode, DelegationLongName, DelegationShortName, DelegationComment);

COMMIT; 
SET Result = NewDelegationID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddDiscipline 结构
DELIMITER //
CREATE PROCEDURE `proc_AddDiscipline`(
in SportID INT,
in DisciplineCode VARCHAR(10),
in aOrder INT,
in DisciplineInfo VARCHAR(50),
in languageCode CHAR(3),
in DisciplineLongName VARCHAR(100),
in DisciplineShortName VARCHAR(50),
in DisciplineComment VARCHAR(100),
out Result INT
)
LABEL:begin

DECLARE NewDisciplineID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Sport WHERE F_SportID = SportID)=0 then
SET Result = -1;
leave label;
END if;


IF ((DisciplineCode IS NULL) OR (DisciplineCode = '')) then
SET Result = -2;
leave label;
END if;

IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineCode = DisciplineCode AND F_SportID = SportID)>0 then
SET Result = -2;
leave label;
END if;


IF aOrder = 0 OR aOrder IS NULL then
SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 FROM TS_Discipline WHERE F_SportID = SportID;
END if;


START TRANSACTION;
INSERT INTO TS_Discipline (F_SportID, F_DisciplineCode, F_Order, F_DisciplineInfo, F_Active)
VALUES (SportID, DisciplineCode, aOrder, DisciplineInfo, 0);

SET NewDisciplineID = @@IDENTITY;

insert into TS_Discipline_Des (F_DisciplineID, F_LanguageCode, F_DisciplineLongName, F_DisciplineShortName, F_DisciplineComment)
VALUES (NewDisciplineID, languageCode, DisciplineLongName, DisciplineShortName, DisciplineComment);

COMMIT; 
SET Result = NewDisciplineID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddEvent 结构
DELIMITER //
CREATE PROCEDURE `proc_AddEvent`(
in DisciplineID INT,
in EventCode VARCHAR(10),
in OpenDate DATETIME,
in CloseDate DATETIME,
in aOrder INT,
in SexCode INT,
in PlayerRegTypeID INT,
in EventInfo VARCHAR(50),
in languageCode CHAR(3),
in EventLongName VARCHAR(100),
in EventShortName VARCHAR(50),
in EventComment VARCHAR(100),
in CompetitionType INT,
out Result INT
)
LABEL:begin

DECLARE NewEventID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(*) FROM TS_Discipline WHERE F_DisciplineID = DisciplineID)=0 then
SET Result = -1;
leave LABEL;
END if;


IF aOrder = 0 OR aOrder IS NULL then
SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 FROM TS_Event WHERE F_DisciplineID = DisciplineID;
END if;
    

START TRANSACTION;
INSERT INTO TS_Event (F_DisciplineID, F_EventCode, F_OpenDate, F_CloseDate, F_Order, F_SexCode, F_EventInfo, F_PlayerRegTypeID, F_CompetitionTypeID)
VALUES (DisciplineID, EventCode, OpenDate, CloseDate, aOrder, SexCode, EventInfo, PlayerRegTypeID, CompetitionType);


SET NewEventID = @@IDENTITY;

insert into TS_Event_Des (F_EventID, F_LanguageCode, F_EventLongName, F_EventShortName, F_EventComment)
VALUES (NewEventID, languageCode, EventLongName, EventShortName, EventComment);


COMMIT; 
SET Result = NewEventID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddEventRecord 结构
DELIMITER //
CREATE PROCEDURE `proc_AddEventRecord`(
in EventID INT,
in bAddNew BIT,
in RecordID INT,
    in EventCode VARCHAR(50),
in RecordType VARCHAR(50),
in Equalled VARCHAR(50),
    in Location VARCHAR(50),
    in LocationNOC CHAR(3),
    in RecordSport VARCHAR(50),
    in RecordDate DATETIME,
    in RecordValue VARCHAR(50),
    in CompetitorCode VARCHAR(50),
    in CompetitorNOC CHAR(3),
    in CompetitorGender VARCHAR(50),
    in CompetitorFamilyName VARCHAR(50),
    in CompetitorGivenName VARCHAR(50),
    in CompetitorBirthDate DATETIME,
    in RecordWind VARCHAR(50),
    in RecordComment VARCHAR(50),
    in CompetitorReportName VARCHAR(50),
    in Active Int,
out Result INT
)
LABEL:begin
DECLARE NewRecordID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(*) FROM TS_Event WHERE F_EventID = EventID)=0 then
SET Result = -1;
leave label;
END if;


IF bAddNew =1 then
    
START TRANSACTION;

INSERT INTO TS_Event_Record (F_RecordType, F_Equalled, F_EventCode, F_EventID, F_Location, F_LocationNOC, F_RecordSport, F_RecordDate, F_RecordValue,
F_CompetitorCode, F_CompetitorNOC, F_CompetitorGender, F_CompetitorFamilyName, F_CompetitorGivenName, F_CompetitorBirthDate,
F_RecordWind, F_RecordComment, F_CompetitorReportingName, F_Active, F_IsNewCreated)
VALUES (RecordType, Equalled, EventCode, EventID, Location, LocationNOC, RecordSport, RecordDate, RecordValue, CompetitorCode,
 CompetitorNOC, CompetitorGender, CompetitorFamilyName, CompetitorGivenName, CompetitorBirthDate, 
 RecordWind, RecordComment, CompetitorReportName, Active, 0);

SET NewRecordID = @@IDENTITY;
COMMIT; 
SET Result = NewRecordID;
leave LABEL;
else
IF (SELECT F_RecordID FROM TS_Event_Record WHERE F_EventID = EventID AND F_RecordID = RecordID)=0 then
SET Result = -2;
leave label;
END if;

START TRANSACTION; 
UPDATE TS_Event_Record SET 
F_EventCode = EventCode,
F_RecordType = RecordType, 
F_Equalled = Equalled, 
F_Location = Location, 
F_LocationNOC = LocationNOC, 
F_RecordSport = RecordSport, 
F_RecordDate = RecordDate, 
F_RecordValue = RecordValue,
F_CompetitorCode = CompetitorCode, 
F_CompetitorNOC = CompetitorNOC, 
F_CompetitorGender = CompetitorGender, 
F_CompetitorFamilyName = CompetitorFamilyName, 
F_CompetitorGivenName = CompetitorGivenName, 
F_CompetitorBirthDate = CompetitorBirthDate, 
F_RecordWind = RecordWind, 
F_RecordComment = RecordComment, 
F_CompetitorReportingName = CompetitorReportName,
                    F_Active  =  Active
WHERE F_EventID = EventID AND F_RecordID = RecordID;

COMMIT;

SET Result=1;
end if;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddEventRecord_InitialDownLoad 结构
DELIMITER //
CREATE PROCEDURE `proc_AddEventRecord_InitialDownLoad`(
    in EventID INT,    
    in RecordTypeID INT,
    in RegisterID Int,
    in Location VARCHAR(50),
    in RecordSport VARCHAR(50),
    in RecordDate DATETIME,
    in RecordValue VARCHAR(50),
    in LocationNOC CHAR(50),
    in Active Int,
    in aOrder Int,
    in Equal int,
    in IsNew int,
    in SubEventCode VARCHAR(20),
    out Result int
)
LABEL:begin
    DECLARE NewRecordID INT;

    
    declare exit handler for sqlexception 
    err:begin
        ROLLBACK; 
        SET Result=0;
    end err;
    
    set autocommit = 0;
    SET Result=0;  

    IF (SELECT count(*) FROM TS_Event WHERE F_EventID = EventID)=0 THEN
        SET Result = -1;
        leave label;
    END if;

   
   IF (aOrder IS NULL) THEN
      SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) +1 FROM TS_Event_Record;
   END if;
    

    START TRANSACTION;
    INSERT INTO TS_Event_Record (F_RecordTypeID, F_RegisterID, F_EventID, F_RecordValue, F_RecordSport, F_Location, F_RecordDate, F_Active, F_Order, F_Equalled, F_IsNewCreated,F_SubEventCode)
                    VALUES (RecordTypeID, RegisterID, EventID, RecordValue, RecordSport, Location, RecordDate, Active, aOrder, Equal, IsNew, SubEventCode);
    
    COMMIT; 
    SET Result = NewRecordID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddEventResult 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddEventResult`(
    in EventID INT,
out Result INT
)
LABEL:begin

DECLARE EventResultNumber  INT;
DECLARE EventRank INT;
DECLARE EventDiplayPosition INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Event WHERE F_EventID = EventID)=0 then
      SET Result = -1;
      leave label;
    END IF;

SELECT EventResultNumber = (CASE WHEN MAX(F_EventResultNumber) IS NULL THEN 0 ELSE MAX(F_EventResultNumber) END) + 1 
FROM TS_Event_Result WHERE F_EventID = EventID;
    SELECT EventRank = (CASE WHEN MAX(F_EventRank) IS NULL THEN 0 ELSE MAX(F_EventRank) END) + 1 
    FROM TS_Event_Result WHERE F_EventID = EventID;
    SELECT EventDiplayPosition = (CASE WHEN MAX(F_EventDisplayPosition) IS NULL THEN 0 ELSE MAX(F_EventDisplayPosition) END) + 1 
    FROM TS_Event_Result WHERE F_EventID = EventID;

    

START TRANSACTION;
INSERT INTO TS_Event_Result (F_EventID, F_EventResultNumber, F_EventRank, F_EventDisplayPosition) 
VALUES (EventID, EventResultNumber, EventRank, EventDiplayPosition);


COMMIT; 
SET Result = EventResultNumber;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddEventResultWithDetail 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddEventResultWithDetail`(
in EventID INT,
in EventRank INT,
in SourcePhaseID INT,
in SourcePhaseRank INT, 
in SourceMatchID INT, 
in SourceMatchRank INT,
out Result INT
)
LABEL:begin

DECLARE EventResultID  INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
SELECT EventResultID = (CASE WHEN MAX(F_EventResultNumber) IS NULL THEN 0 ELSE MAX(F_EventResultNumber) END) + 1 
FROM TS_Event_Result WHERE F_EventID = EventID;                    

START TRANSACTION;

INSERT INTO TS_Event_Result (F_EventID, F_EventResultNumber, F_EventRank, F_SourcePhaseID, F_SourcePhaseRank, F_SourceMatchID, F_SourceMatchRank) 
VALUES (EventID, EventResultID, EventRank, SourcePhaseID, SourcePhaseRank, SourceMatchID, SourceMatchRank);
COMMIT; 
SET Result = EventResultID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddFederation 结构
DELIMITER //
CREATE PROCEDURE `proc_AddFederation`(
in FederationCode VARCHAR(10),
    in LanguageCode CHAR(3),
in FederationLongName VARCHAR(50),
in FederationShortName VARCHAR(50),
in FederationComment VARCHAR(50),
out Result INT
)
LABEL:begin
DECLARE NewFederationID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT F_FederationID FROM TC_Federation WHERE F_FederationCode = FederationCode)>0 then
SET Result = -1;
leave LABEL;
END IF;
    

START TRANSACTION;
INSERT INTO TC_Federation (F_FederationCode) VALUES (FederationCode);
SET NewFederationID = @@IDENTITY;

    INSERT INTO TC_Federation_Des (F_FederationID, F_LanguageCode, F_FederationLongName, F_FederationShortName, F_FederationComment) 
    VALUES(NewFederationID, LanguageCode, FederationLongName, FederationShortName, FederationComment);
COMMIT; 
SET Result = NewFederationID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddFunction 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddFunction`(
in LanguageCode CHAR(3),
in DisciplineID INT,
in FunctionLongName VARCHAR(50),
in FunctionShortName VARCHAR(50),
in FunctionComment VARCHAR(50),
    in FunctionCode VARCHAR(10),
    in FunctionCategoryCode VARCHAR(50),
out Result INT
)
LABEL:begin
DECLARE NewFunctionID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(*) FROM TD_Function WHERE F_DisciplineID = DisciplineID AND F_FunctionCode = FunctionCode AND F_FunctionCategoryCode = FunctionCategoryCode)> 0 then
          SET Result = -1;
          leave LABEL;
    END if;
    
    IF (SELECT count(*) FROM TD_Function)>0 then
      SELECT NewFunctionID = MAX(F_FunctionID) FROM TD_Function;
      SET NewFunctionID = NewFunctionID + 1;
ELSE
SET NewFunctionID = 1;
END if;
    

START TRANSACTION;
INSERT INTO TD_Function (F_FunctionID, F_DisciplineID, F_FunctionCode, F_FunctionCategoryCode) 
VALUES(NewFunctionID, DisciplineID, FunctionCode, FunctionCategoryCode);

INSERT INTO TD_Function_Des(F_FunctionID, F_LanguageCode, F_FunctionLongName, F_FunctionShortName, F_FunctionComment) 
VALUES(NewFunctionID, LanguageCode, FunctionLongName, FunctionShortName, FunctionComment);

COMMIT; 
SET Result = NewFunctionID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddIRM 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddIRM`(
in LanguageCode CHAR(3),
    in DisciplineID INT,
in aOrder INT,
in IRMCode VARCHAR(20),
in IRMLongName VARCHAR(100),
in IRMShortName VARCHAR(50),
in IRMComment VARCHAR(100),
out Result INT
)
LABEL:begin
DECLARE NewIRMID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TC_IRM)>0 then
      SELECT NewIRMID = MAX(F_IRMID) FROM TC_IRM;
      SET NewIRMID = NewIRMID + 1;
ELSE
SET NewIRMID = 1;
END if;

START TRANSACTION;
INSERT INTO TC_IRM (F_IRMID, F_DisciplineID, F_Order, F_IRMCode) 
VALUES(NewIRMID, DisciplineID, aOrder, IRMCode);
INSERT INTO TC_IRM_Des (F_IRMID, F_LanguageCode, F_IRMLongName, F_IRMShortName, F_IRMComment) 
VALUES(NewIRMID, LanguageCode, IRMLongName, IRMShortName, IRMComment);


COMMIT; 
SET Result = NewIRMID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddLanguage 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddLanguage`(
in LanguageCode CHAR(3),
in LanguageDescription VARCHAR(50),
in aOrder INT,
out Result INT
)
LABEL:begin



declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  


    IF (SELECT count(*) FROM TC_Language WHERE F_LanguageCode = LanguageCode)>0 then
SET Result = -1;
leave LABEL;
END IF;

START TRANSACTION;
INSERT INTO TC_Language (F_Active, F_LanguageCode, F_LanguageDescription, F_Order)
VALUES(0, LanguageCode, LanguageDescription, aOrder);

COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMatch 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMatch`(
in PhaseID INT,
in MatchStatusID INT,
in VenueID INT,
in CourtID INT,
in WeatherID INT,
in SessionID INT,
in MatchDate DATETIME,
in StartTime DATETIME,
in EndTime DATETIME,
in SpendTime INT,
in aOrder INT,
in MatchNum INT,
in Code VARCHAR(20),
in MatchType INT,
in CompetitorNum INT,
in MatchInfo VARCHAR(50),
in languageCode CHAR(3),
in MatchLongName VARCHAR(100),
in MatchShortName VARCHAR(50),
in MatchComment VARCHAR(100),
out Result  INT
)
LABEL:begin
DECLARE NewMatchID INT;
DECLARE PhaseStatusID INT;
DECLARE curPosition INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Phase WHERE F_PhaseID = PhaseID)=0 then 
SET Result = -1;
leave label;
END if;


SELECT PhaseStatusID = F_PhaseStatusID FROM TS_Phase WHERE F_PhaseID = PhaseID;

IF PhaseStatusID > 10 THEN
SET Result = -2;
leave label;
END if;

IF aOrder = 0 OR aOrder IS NULL THEN
SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 FROM TS_Match WHERE F_PhaseID = PhaseID;
END IF;

IF MatchStatusID IS NULL THEN
SET MatchStatusID = 10;
END IF;

START TRANSACTION;
INSERT INTO TS_Match (F_PhaseID, F_MatchStatusID, F_VenueID, F_CourtID, F_WeatherID, F_SessionID, F_MatchDate, F_StartTime, F_EndTime, F_SpendTime, F_Order, F_MatchNum, F_MatchCode, F_MatchTypeID, F_MatchInfo)
VALUES (PhaseID, MatchStatusID, VenueID, CourtID, WeatherID, SessionID, MatchDate, StartTime, EndTime, SpendTime, aOrder, MatchNum, Code, MatchType, MatchInfo);

SET NewMatchID = @@IDENTITY;

insert into TS_Match_DES (F_MatchID, F_LanguageCode, F_MatchLongName, F_MatchShortName, F_MatchComment)
VALUES (NewMatchID, languageCode, MatchLongName, MatchShortName, MatchComment);


SET curPosition = 1;
WHILE (curPosition <= CompetitorNum ) DO
insert into TS_Match_Result (F_MatchID, F_CompetitionPosition, F_CompetitionPositionDes1)
VALUES (NewMatchID, curPosition, curPosition);

SET curPosition = curPosition + 1;
END WHILE;

INSERT INTO TS_Match_Result_Des (F_MatchID, F_CompetitionPosition, F_LanguageCode)
SELECT F_MatchID, F_CompetitionPosition, languageCode AS F_LanguageCode FROM TS_Match_Result WHERE F_MatchID = NewMatchID;

COMMIT; 

SET Result = NewMatchID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMatchRank2PhaseRank 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMatchRank2PhaseRank`(
in MatchID INT,
in MatchRank INT,
in PhaseID INT,
in PhaseRank INT,
out Result INT
)
LABEL:begin



declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
    IF (SELECT count(*) FROM TS_Match WHERE F_MatchID = MatchID)=0 then
SET Result = -1;
leave label;
END if;

IF (SELECT count(*) FROM TS_MatchRank2PhaseRank WHERE F_MatchID = MatchID AND F_MatchRank = MatchRank AND F_PhaseID = PhaseID)>0 then
SET Result = -1;
leave label;
END if;                

    

START TRANSACTION;

INSERT INTO TS_MatchRank2PhaseRank (F_MatchID, F_MatchRank, F_PhaseID, F_PhaseRank)
VALUES (MatchID, MatchRank, PhaseID, PhaseRank);


COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMatchSplit 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMatchSplit`(
in MatchID INT,
in FatherMatchSplitID INT,
in MatchSplitOrder INT,
in MatchType INT,
out  Result INT
)
LABEL:begin

    DECLARE MatchSplitID INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Match_Result WHERE F_MatchID = MatchID)=0 THEN
SET Result = -1;
leave label;
END if;

IF FatherMatchSplitID IS NULL OR FatherMatchSplitID = '' OR FatherMatchSplitID = 0 THEN
        SET FatherMatchSplitID = 0;
    ELSE
IF (SELECT count(*)  FROM TS_Match_Split_Info WHERE F_MatchID = MatchID AND F_MatchSplitID = FatherMatchSplitID) =0 then 
SET Result = -2;
leave label;
END if;
    END if;
    
    IF (SELECT count(*)  FROM TS_Match_Split_Info WHERE F_MatchID = MatchID AND F_FatherMatchSplitID = FatherMatchSplitID AND F_Order = MatchSplitOrder)>0 THEN
SET Result = -3;
leave label;
END if;

    

START TRANSACTION;
 IF (MatchSplitOrder = 0 OR MatchSplitOrder IS NULL OR MatchSplitOrder = '') THEN
         SELECT MatchSplitOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 
         FROM TS_Match_Split_Info WHERE F_MatchID = MatchID AND F_FatherMatchSplitID = FatherMatchSplitID;
    END if;
   
    SELECT MatchSplitID = (CASE WHEN MAX(F_MatchSplitID) IS NULL THEN 0 ELSE MAX(F_MatchSplitID) END) + 1 FROM TS_Match_Split_Info WHERE F_MatchID = MatchID;
   
    INSERT INTO TS_Match_Split_Info (F_MatchID,F_MatchSplitID,F_FatherMatchSplitID,F_Order,F_MatchSplitStatusID,F_MatchSplitType) 
                VALUES (MatchID,MatchSplitID,FatherMatchSplitID,MatchSplitOrder,0,MatchType);

   
    INSERT INTO TS_Match_Split_Result (F_MatchID,F_MatchSplitID,F_CompetitionPosition) VALUES(MatchID, MatchSplitID,1);
    
    INSERT INTO TS_Match_Split_Result (F_MatchID,F_MatchSplitID,F_CompetitionPosition) VALUES(MatchID, MatchSplitID,2);
   

COMMIT; 
SET Result = MatchSplitID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMatchWithCompetitors 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMatchWithCompetitors`(
in PhaseID INT,
in MatchStatusID INT,
in VenueID INT,
in CourtID INT,
in WeatherID INT,
in SessionID INT,
in MatchDate DATETIME,
in StartTime DATETIME,
in EndTime DATETIME,
in SpendTime INT,
in aOrder INT,
in MatchType INT,
in MatchInfo  VARCHAR(50),
in languageCode CHAR(3),
in MatchLongName  VARCHAR(100),
in MatchShortName VARCHAR(50),
in MatchComment VARCHAR(100),
in APosition INT,
in ARegisterID INT,
in AStartPhaseID INT,
in AStartPhasePosition INT,
in ASourcePhaseID INT,
in ASourcePhaseRank INT,
in ASourceMatchID INT,
in ASourceMatchRank INT,
in AResult INT,
in ARank INT,
in APoints INT,
in AService INT,
in BPosition INT,
in BRegisterID INT,
in BStartPhaseID INT,
in BStartPhasePosition INT,
in BSourcePhaseID INT,
in BSourcePhaseRank INT,
in BSourceMatchID INT,
in BSourceMatchRank INT,
in BResult INT,
in BRank INT,
in BPoints  INT,
in BService INT,
in MatchNum INT,
out Result  INT
)
LABEL:begin
DECLARE NewMatchID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(*) FROM TS_Phase WHERE F_PhaseID = PhaseID) =0 then
SET Result = -1;
leave label;
END if;


IF aOrder = 0 OR aOrder IS NULL then 
SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 FROM TS_Match WHERE F_PhaseID = PhaseID;
END if;

IF MatchStatusID IS NULL THEN
SET MatchStatusID = 10;
END IF;
    

START TRANSACTION;

INSERT INTO TS_Match (F_PhaseID, F_MatchStatusID, F_VenueID, F_CourtID, F_WeatherID, F_SessionID, F_MatchDate, F_StartTime, F_EndTime, F_SpendTime, F_Order, F_MatchTypeID, F_MatchInfo, F_MatchNum)
VALUES (PhaseID, MatchStatusID, VenueID, CourtID, WeatherID, SessionID, MatchDate, StartTime, EndTime, SpendTime, aOrder, MatchType, MatchInfo, MatchNum);

SET NewMatchID = @@IDENTITY;

insert into TS_Match_DES (F_MatchID, F_LanguageCode, F_MatchLongName, F_MatchShortName, F_MatchComment)
VALUES (NewMatchID, languageCode, MatchLongName, MatchShortName, MatchComment);


insert into TS_Match_Result (F_MatchID, F_CompetitionPosition, F_RegisterID, F_StartPhaseID, F_StartPhasePosition, F_SourcePhaseID, F_SourcePhaseRank, F_SourceMatchID, F_SourceMatchRank, F_ResultID, F_Rank, F_Points, F_Service, F_CompetitionPositionDes1)
VALUES (NewMatchID, APosition, ARegisterID, AStartPhaseID, AStartPhasePosition, ASourcePhaseID, ASourcePhaseRank, ASourceMatchID, ASourceMatchRank, AResult, ARank, APoints, AService, APosition);


insert into TS_Match_Result (F_MatchID, F_CompetitionPosition, F_RegisterID, F_StartPhaseID, F_StartPhasePosition, F_SourcePhaseID, F_SourcePhaseRank, F_SourceMatchID, F_SourceMatchRank, F_ResultID, F_Rank, F_Points, F_Service, F_CompetitionPositionDes1)
VALUES (NewMatchID, BPosition, BRegisterID, BStartPhaseID, BStartPhasePosition, BSourcePhaseID, BSourcePhaseRank, BSourceMatchID, BSourceMatchRank, BResult, BRank, BPoints, BService, BPosition);


COMMIT;
SET Result = NewMatchID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddMatch_for_Schedule 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddMatch_for_Schedule`(
    in PhaseID INT,
    in MatchStatusID INT,
    in VenueID INT,
    in CourtID INT,
    in WeatherID INT,
    in SessionID INT,
    in MatchDate DATETIME,
    in StartTime DATETIME,
    in EndTime DATETIME,
    in SpendTime INT,
    in aOrder INT,
    in MatchNum INT,
    in Code VARCHAR(20),
    in MatchType INT,
    in HasMedal INT,
    in CompetitorNum INT,
    in MatchInfo VARCHAR(50),
    in languageCode CHAR(3),
    in MatchLongName VARCHAR(100),
    in MatchShortName VARCHAR(50),
    in MatchComment VARCHAR(100),
    in MatchComment2 VARCHAR(100),
    out Result INT
)
LABEL:begin
    DECLARE NewMatchID INT;
    DECLARE PhaseStatusID INT;
    DECLARE curPosition INT;

    
    declare exit handler for sqlexception 
    err:begin
        ROLLBACK; 
        SET Result=0;
    end err;
    
    set autocommit = 0;
    SET Result=0;  
    IF (SELECT count(*) FROM TS_Phase WHERE F_PhaseID = PhaseID)=0 THEN
        SET Result = -1;
        leave label;
    END if;

    SELECT PhaseStatusID = F_PhaseStatusID FROM TS_Phase WHERE F_PhaseID = PhaseID;

    IF PhaseStatusID > 10 THEN
        SET Result = -2;
        leave label;
    END IF;

    IF aOrder = 0 OR aOrder IS NULL THEN
        SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 
            FROM TS_Match WHERE F_PhaseID = PhaseID;
    END IF;
    
    IF MatchStatusID IS NULL THEN
        SET MatchStatusID = 10;
    END IF;


    START TRANSACTION;
    INSERT INTO TS_Match (F_PhaseID, F_MatchStatusID, F_VenueID, F_CourtID, F_WeatherID, F_SessionID, F_MatchDate, F_StartTime, F_EndTime, F_SpendTime, F_Order, F_MatchNum, F_MatchCode, F_MatchTypeID, F_MatchInfo, F_MatchHasMedal)
            VALUES (PhaseID, MatchStatusID, VenueID, CourtID, WeatherID, SessionID, MatchDate, StartTime, EndTime, SpendTime, aOrder, MatchNum, Code, MatchType, MatchInfo, HasMedal);

    SET NewMatchID = @@IDENTITY;

    insert into TS_Match_DES (F_MatchID, F_LanguageCode, F_MatchLongName, F_MatchShortName, F_MatchComment, F_MatchComment2)
            VALUES (NewMatchID, languageCode, MatchLongName, MatchShortName, MatchComment, MatchComment2);


    SET curPosition = 1;

    WHILE (curPosition <= CompetitorNum ) DO
        insert into TS_Match_Result (F_MatchID, F_CompetitionPosition, F_CompetitionPositionDes1)
            VALUES (NewMatchID, curPosition, curPosition);

        SET curPosition = curPosition + 1;
    END WHILE;
    
    INSERT INTO TS_Match_Result_Des (F_MatchID, F_CompetitionPosition, F_LanguageCode)
        SELECT F_MatchID, F_CompetitionPosition, languageCode AS F_LanguageCode 
        FROM TS_Match_Result WHERE F_MatchID = NewMatchID;

    COMMIT; 
    SET Result = NewMatchID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMemberRegister 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMemberRegister`(
in RegisterID INT,
    in MemberRegisterID INT,
    in FunctionID INT,
    in PositionID INT,
    in aOrder INT,
    in ShirtNum INT,
out Result INT
)
LABEL:begin



declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(0) FROM TR_Register)=0 then
SET Result = -1;
leave label;
END if;

    IF (SELECT count(*) FROM TR_Register)=0 then
SET Result = -2;
leave label;
END if;

    

START TRANSACTION;

INSERT INTO TR_Register_Member (F_RegisterID, F_MemberRegisterID, F_Order, F_FunctionID, F_PositionID, F_ShirtNumber)
VALUES (RegisterID, MemberRegisterID, aOrder, FunctionID, PositionID, ShirtNum);
COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddMemberRegister_WithOrder 结构
DELIMITER //
CREATE PROCEDURE `proc_AddMemberRegister_WithOrder`(
in RegisterID INT,
    in MemberRegisterID INT,
    in FunctionID INT,
    in PositionID INT,
    in aOrder INT,
    in ShirtNum INT,
out Result  INT
)
LABEL:begin

DECLARE NodeLevel INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(RegisterID) FROM TR_Register)=0 THEN
SET Result = -1;
leave label;
END IF;

    IF (SELECT count(MemberRegisterID) FROM TR_Register)=0 THEN
SET Result = -2;
leave label;
END if;


SET NodeLevel = 0;

CREATE TABLE tmp_table(
             F_RegisterID INT,
             F_MemberID INT,
             F_MidMemberID INT,
             F_NodeLevel INT);
     
    INSERT INTO tmp_table (F_RegisterID, F_MemberID,F_NodeLevel, F_MidMemberID)
               SELECT MemberRegisterID, A.F_MemberRegisterID, 0, A.F_MemberRegisterID
                 FROM TR_Register_Member AS A LEFT JOIN TR_Register AS B  ON A.F_MemberRegisterID = B.F_RegisterID
                   WHERE A.F_RegisterID = MemberRegisterID AND B.F_RegTypeID IN (2,3);
           
     WHILE (SELECT count(*) FROM tmp_table WHERE F_NodeLevel = 0)>0 do
         SET NodeLevel = NodeLevel + 1;
     UPDATE tmp_table SET F_NodeLevel = NodeLevel WHERE F_NodeLevel = 0;
     
         INSERT INTO tmp_table (F_RegisterID, F_MemberID, F_NodeLevel, F_MidMemberID)
             SELECT MemberRegisterID, B.F_MemberRegisterID,  0,  B.F_MemberRegisterID
              FROM tmp_table AS A LEFT JOIN TR_Register_Member AS B ON A.F_MidMemberID = B.F_RegisterID 
                    LEFT JOIN TR_Register AS C ON B.F_MemberRegisterID = C.F_RegisterID 
                WHERE A.F_NodeLevel = NodeLevel AND C.F_RegTypeID IN (2,3);
     END WHILE;
    
    IF (SELECT count(*) FROM tmp_table WHERE F_RegisterID = MemberRegisterID AND F_MemberID = RegisterID)>0 THEN
         SET Result = -3;
 leave label;
    END if;
    
    IF (aOrder IS NULL OR aOrder = 0 OR aOrder = NULL) THEN
         SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) FROM TR_Register_Member WHERE F_RegisterID = RegisterID;
         SET aOrder = aOrder + 1;
    END if;
    

START TRANSACTION;

INSERT INTO TR_Register_Member (F_RegisterID, F_MemberRegisterID, F_Order, F_FunctionID, F_PositionID, F_ShirtNumber)
VALUES (RegisterID, MemberRegisterID, aOrder, FunctionID, PositionID, ShirtNum);

COMMIT; 
SET Result = 1;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.Proc_AddNation 结构
DELIMITER //
CREATE PROCEDURE `Proc_AddNation`(
in LanguageCode CHAR(3),
in NationLongName VARCHAR(50),
in NationShortName VARCHAR(50),
in NationComment VARCHAR(50),
out Result INT 
)
LABEL:begin
DECLARE NewNationID INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

SELECT NewNationID = (CASE WHEN MAX(F_NationID) IS NULL THEN 0 ELSE MAX(F_NationID) END) + 1 
FROM TC_Nation;
    

START TRANSACTION;

INSERT INTO TC_Nation (F_NationID) VALUES (NewNationID);
INSERT INTO TC_Nation_Des (F_NationID, F_LanguageCode, F_NationLongName, F_NationShortName, F_NationComment) 
VALUES(NewNationID, LanguageCode, NationLongName, NationShortName, NationComment);



COMMIT; 
SET Result = NewNationID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddPhase 结构
DELIMITER //
CREATE PROCEDURE `proc_AddPhase`(
in EventID INT,
in FatherPhaseID INT,
in PhaseCode VARCHAR(10),
in OpenDate DATETIME,
in CloseDate DATETIME,
in PhaseStatusID INT,
in PhaseNodeType INT,
in aOrder INT,
in PhaseType INT,
in PhaseSize INT,
in PhaseRankSize INT,
in PhaseIsQual INT,
in PhaseInfo VARCHAR(50),
in languageCode CHAR(3),
in PhaseLongName VARCHAR(100),
in PhaseShortName VARCHAR(50),
in PhaseComment VARCHAR(100),
out Result INT
)
LABEL:begin

DECLARE NewPhaseID INT;
DECLARE ParentStatusID  INT;
DECLARE FatherPhaseType INT;

declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  

IF (SELECT count(*) FROM TS_Event WHERE F_EventID = EventID)=0 THEN
SET Result = -1;
leave label;
END if;

IF FatherPhaseID <> 0 THEN
IF (SELECT count(*) FROM TS_Phase WHERE F_PhaseID = FatherPhaseID)=0 THEN
SET Result = -1;
leave label;
END IF;
END if;



IF FatherPhaseID = 0 THEN
SELECT ParentStatusID = F_EventStatusID FROM TS_Event WHERE F_EventID = EventID;
ELSE 
SELECT ParentStatusID = F_PhaseStatusID FROM TS_Phase WHERE F_PhaseID = FatherPhaseID; 
END IF;

IF ParentStatusID > 10 THEN
SET Result = -2;
leave label;
END if;


IF aOrder = 0 OR aOrder IS NULL THEN
SELECT aOrder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1 
FROM TS_Phase WHERE F_EventID = EventID AND F_FatherPhaseID = FatherPhaseID;
END if;

IF PhaseStatusID IS NULL THEN
SET PhaseStatusID = 10;
END if;


IF FatherPhaseID <> 0 THEN
SELECT FatherPhaseType = F_PhaseType FROM TS_Phase WHERE F_PhaseID = FatherPhaseID;
END if;

IF(PhaseType=1 AND FatherPhaseID <> 0) THEN
IF FatherPhaseType = 2 THEN
SET PhaseType = 21;
ELSEIF  FatherPhaseType = 3 THEN
SET PhaseType = 31;
END if;
END if;

START TRANSACTION;
INSERT INTO TS_PHASE (F_EventID, F_FatherPhaseID, F_PhaseCode, F_OpenDate, F_CloseDate, F_PhaseStatusID, F_PhaseNodeType, F_Order, F_PhaseType, F_PhaseSize, F_PhaseRankSize, F_PhaseIsQual, F_PhaseInfo)
    VALUES (EventID, FatherPhaseID, PhaseCode, OpenDate, CloseDate, PhaseStatusID, PhaseNodeType, aOrder, PhaseType, PhaseSize, PhaseRankSize, PhaseIsQual, PhaseInfo);
    SET NewPhaseID = @@IDENTITY;

insert into TS_PHASE_DES (F_PhaseID, F_LanguageCode, F_PhaseLongName, F_PhaseShortName, F_PhaseComment)
VALUES (NewPhaseID, languageCode, PhaseLongName, PhaseShortName, PhaseComment);


COMMIT; 
SET Result = NewPhaseID;

end LABEL//
DELIMITER ;

-- 导出  存储过程 eq.proc_AddPhase_for_Schedule 结构
DELIMITER //
CREATE PROCEDURE `proc_AddPhase_for_Schedule`(
in EventID INT,
in FatherPhaseID INT,
in PhaseCode VARCHAR(10),
in OpenDate DATETIME,
in CloseDate DATETIME,
in PhaseStatusID INT,
in PhaseNodeType INT,
in aOrder INT,
in PhaseType INT,
in PhaseSize INT,
in PhaseRankSize INT,
in PhaseIsQual INT,
in PhaseInfo VARCHAR(50),
in languageCode CHAR(3),
in PhaseLongName VARCHAR(100),
in PhaseShortName VARCHAR(50),
in PhaseComment VARCHAR(100),
in IsPool INT,
in HasPools INT,
out Result INT 
)
LABEL:begin
DECLARE NewPhaseID INT;
DECLARE ParentStatusID INT;
DECLARE FatherPhaseType  INT;


declare exit handler for sqlexception 
err:begin
ROLLBACK; 
SET Result=0;
end err;

set autocommit = 0;
SET Result=0;  
IF (SELECT count(*) FROM TS_Event WHERE F_EventID = EventID)= 0 THEN
SET Result = -1;
leave label;
END if;

IF FatherPhaseID != 0 THEN
IF (SELECT count(*) FROM TS_Phase WHERE F_PhaseID = FatherPhaseID) =0 THEN
SET Result = -1;
leave label;
END if;
END if;



IF FatherPhaseID = 0 THEN
SELECT ParentStatusID = F_EventStatusID FROM TS_Event WHERE F_EventID = EventID;
ELSE 
SELECT ParentStatusID = F_PhaseStatusID FROM TS_Phase WHERE F_PhaseID = FatherPhaseID ;
END if;

IF ParentStatusID > 10 THEN
SET Result = -2;
leave label;
END if;

IF aorder= 0 OR aorder IS NULL THEN
SELECT aorder = (CASE WHEN MAX(F_Order) IS NULL THEN 0 ELSE MAX(F_Order) END) + 1
 FROM TS_Phase WHERE F_EventID = EventID AND F_FatherPhaseID = FatherPhaseID;
END if;

IF PhaseStatusID IS NULL THEN
SET PhaseStatusID = 10;
END if;



IF FatherPhaseID <> 0 THEN
SELECT FatherPhaseType = F_PhaseType FROM TS_Phase WHERE F_PhaseID = FatherPhaseID;
END if;

IF(PhaseType=1 AND FatherPhaseID <> 0) THEN
IF FatherPhaseType = 2 THEN
SET PhaseType = 21;
ELSEIF FatherPhaseType = 3 THEN
SET PhaseType = 31;
END if;
END if;

START TRANSACTION;

INSERT INTO TS_PHASE (F_EventID, F_FatherPhaseID, F_PhaseCode, F_OpenDate, F_CloseDate, F_PhaseStatusID, F_PhaseNodeType, F_Order, F_PhaseIsPool, F_PhaseHasPools, F_PhaseType, F_PhaseSize, F_PhaseRankSize, F_PhaseIsQual, F_PhaseInfo)
VALUES (EventID, FatherPhaseID, PhaseCode, OpenDate, CloseDate, PhaseStatusID, PhaseNodeType, aOrder, IsPool, HasPools, PhaseType, PhaseSize, PhaseRankSize, PhaseIsQual, PhaseInfo);

SET NewPhaseID = @@IDENTITY;

insert into TS_PHASE_DES (F_PhaseID, F_LanguageCode, F_PhaseLongName, F_PhaseShortName, F_PhaseComment)
VALUES (NewPhaseID, languageCode, PhaseLongName, PhaseShortName, PhaseComment);

COMMIT; 
SET Result = NewPhaseID;

end LABEL//
DELIMITER ;

-- 导出  表 eq.rd_actiontype_des 结构
CREATE TABLE IF NOT EXISTS `rd_actiontype_des` (
  `f_actiontypeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_actiontypelongname` varchar(50) DEFAULT NULL,
  `f_actiontypeshortname` varchar(50) DEFAULT NULL,
  `f_actiontypecomment` varchar(50) DEFAULT NULL,
  `f_actiontypecomment1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_actiontypeid`,`f_languagecode`),
  KEY `fk_td_actiontype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_actiontype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_td_actiontype_des_td_actiontype` FOREIGN KEY (`f_actiontypeid`) REFERENCES `td_actiontype` (`f_actiontypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_city 结构
CREATE TABLE IF NOT EXISTS `tc_city` (
  `F_CityID` int NOT NULL AUTO_INCREMENT,
  `F_CityCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`F_CityID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_city_des 结构
CREATE TABLE IF NOT EXISTS `tc_city_des` (
  `F_CityID` int NOT NULL AUTO_INCREMENT,
  `F_LanguageCode` char(3) NOT NULL,
  `F_CityLongName` varchar(50) DEFAULT NULL,
  `F_CityShortName` varchar(50) DEFAULT NULL,
  `F_CityComment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_CityID`,`F_LanguageCode`),
  KEY `FK_TC_City_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TC_City_Des_TC_Color` FOREIGN KEY (`F_CityID`) REFERENCES `tc_city` (`F_CityID`),
  CONSTRAINT `FK_TC_City_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_club 结构
CREATE TABLE IF NOT EXISTS `tc_club` (
  `F_ClubID` int NOT NULL AUTO_INCREMENT,
  `F_ClubCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`F_ClubID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_club_des 结构
CREATE TABLE IF NOT EXISTS `tc_club_des` (
  `F_ClubID` int NOT NULL AUTO_INCREMENT,
  `F_LanguageCode` char(3) NOT NULL,
  `F_ClubLongName` varchar(50) DEFAULT NULL,
  `F_ClubShortName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_ClubID`,`F_LanguageCode`),
  KEY `FK_TC_Club_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TC_Club_Des_TC_Club` FOREIGN KEY (`F_ClubID`) REFERENCES `tc_club` (`F_ClubID`),
  CONSTRAINT `FK_TC_Club_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_color 结构
CREATE TABLE IF NOT EXISTS `tc_color` (
  `F_ColorID` int NOT NULL,
  PRIMARY KEY (`F_ColorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_color_des 结构
CREATE TABLE IF NOT EXISTS `tc_color_des` (
  `F_ColorID` int NOT NULL AUTO_INCREMENT,
  `F_LanguageCode` char(3) NOT NULL,
  `F_ColorLongName` varchar(100) DEFAULT NULL,
  `F_ColorShortName` varchar(50) DEFAULT NULL,
  `F_ColorComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_ColorID`,`F_LanguageCode`),
  KEY `FK_TC_Color_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TC_Color_Des_TC_Color` FOREIGN KEY (`F_ColorID`) REFERENCES `tc_color` (`F_ColorID`),
  CONSTRAINT `FK_TC_Color_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_competitiontype 结构
CREATE TABLE IF NOT EXISTS `tc_competitiontype` (
  `f_competitiontypeid` int NOT NULL AUTO_INCREMENT,
  `f_competitiontypecode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`f_competitiontypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_competitiontype_des 结构
CREATE TABLE IF NOT EXISTS `tc_competitiontype_des` (
  `f_competitiontypeid` int NOT NULL AUTO_INCREMENT,
  `f_languagecode` char(3) NOT NULL,
  `f_competitiontypelongname` varchar(50) DEFAULT NULL,
  `f_competitiontypeshortname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_competitiontypeid`,`f_languagecode`),
  KEY `fk_tc_competitiontype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_competitiontype_des_tc_competitiontype` FOREIGN KEY (`f_competitiontypeid`) REFERENCES `tc_competitiontype` (`f_competitiontypeid`),
  CONSTRAINT `fk_tc_competitiontype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_country 结构
CREATE TABLE IF NOT EXISTS `tc_country` (
  `f_noc` char(3) NOT NULL,
  PRIMARY KEY (`f_noc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_country_des 结构
CREATE TABLE IF NOT EXISTS `tc_country_des` (
  `f_noc` char(3) NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_countrylongname` varchar(100) DEFAULT NULL,
  `f_countryshortname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_noc`,`f_languagecode`),
  KEY `fk_tc_country_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_country_des_tc_country` FOREIGN KEY (`f_noc`) REFERENCES `tc_country` (`f_noc`),
  CONSTRAINT `fk_tc_country_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_court 结构
CREATE TABLE IF NOT EXISTS `tc_court` (
  `f_courtid` int NOT NULL AUTO_INCREMENT,
  `f_venueid` int DEFAULT NULL,
  `f_courtcode` varchar(10) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_courtid`),
  KEY `fk_tc_court_tc_venue` (`f_venueid`),
  CONSTRAINT `fk_tc_court_tc_venue` FOREIGN KEY (`f_venueid`) REFERENCES `tc_venue` (`f_venueid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_court_des 结构
CREATE TABLE IF NOT EXISTS `tc_court_des` (
  `f_courtid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_courtlongname` varchar(100) DEFAULT NULL,
  `f_courtshortname` varchar(100) DEFAULT NULL,
  `f_courtcomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_courtid`,`f_languagecode`),
  KEY `fk_tc_court_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_court_des_tc_court` FOREIGN KEY (`f_courtid`) REFERENCES `tc_court` (`f_courtid`),
  CONSTRAINT `fk_tc_court_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_databaseversion 结构
CREATE TABLE IF NOT EXISTS `tc_databaseversion` (
  `f_versionid` int NOT NULL,
  `f_versioninfo` varchar(100) DEFAULT NULL,
  `f_versiondate` datetime DEFAULT NULL,
  `f_versiondes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_versionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_decision 结构
CREATE TABLE IF NOT EXISTS `tc_decision` (
  `f_decisionid` int NOT NULL AUTO_INCREMENT,
  `f_decisioncode` varchar(50) DEFAULT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_decisionid`),
  KEY `fk_tc_decision_tc_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_tc_decision_tc_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_decision_des 结构
CREATE TABLE IF NOT EXISTS `tc_decision_des` (
  `f_decisionid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_decisionlongname` varchar(100) DEFAULT NULL,
  `f_decisionshortname` varchar(50) DEFAULT NULL,
  `f_decisioncomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_decisionid`,`f_languagecode`),
  KEY `fk_tc_decision_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_decision_des_tc_decision` FOREIGN KEY (`f_decisionid`) REFERENCES `tc_decision` (`f_decisionid`),
  CONSTRAINT `fk_tc_decision_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_delegation 结构
CREATE TABLE IF NOT EXISTS `tc_delegation` (
  `f_delegationid` int NOT NULL AUTO_INCREMENT,
  `f_delegationcode` varchar(100) DEFAULT NULL,
  `f_delegationtype` varchar(10) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_delegationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_delegation_des 结构
CREATE TABLE IF NOT EXISTS `tc_delegation_des` (
  `f_delegationid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_delegationlongname` varchar(100) DEFAULT NULL,
  `f_delegationshortname` varchar(100) DEFAULT NULL,
  `f_delegationcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_delegationid`,`f_languagecode`),
  KEY `fk_tc_delegation_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_delegation_des_tc_delegation` FOREIGN KEY (`f_delegationid`) REFERENCES `tc_delegation` (`f_delegationid`),
  CONSTRAINT `fk_tc_delegation_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_discipline_config 结构
CREATE TABLE IF NOT EXISTS `tc_discipline_config` (
  `itemid` int NOT NULL,
  `itemname` varchar(50) DEFAULT NULL,
  `itemvalue` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_event_status 结构
CREATE TABLE IF NOT EXISTS `tc_event_status` (
  `f_statusid` int NOT NULL,
  PRIMARY KEY (`f_statusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_event_status_des 结构
CREATE TABLE IF NOT EXISTS `tc_event_status_des` (
  `f_statusid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_statuslongname` varchar(50) DEFAULT NULL,
  `f_statusshortname` varchar(50) DEFAULT NULL,
  `f_statuscomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_statusid`,`f_languagecode`),
  KEY `fk_tc_event_status_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_event_status_des_tc_event_status` FOREIGN KEY (`f_statusid`) REFERENCES `tc_event_status` (`f_statusid`),
  CONSTRAINT `fk_tc_event_status_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_federation 结构
CREATE TABLE IF NOT EXISTS `tc_federation` (
  `f_federationid` int NOT NULL AUTO_INCREMENT,
  `f_federationcode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`f_federationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_federation_des 结构
CREATE TABLE IF NOT EXISTS `tc_federation_des` (
  `f_federationid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_federationlongname` varchar(100) DEFAULT NULL,
  `f_federationshortname` varchar(50) DEFAULT NULL,
  `f_federationcomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_federationid`,`f_languagecode`),
  KEY `fk_tc_federation_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_federation_des_tc_federation` FOREIGN KEY (`f_federationid`) REFERENCES `tc_federation` (`f_federationid`),
  CONSTRAINT `fk_tc_federation_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsebreed 结构
CREATE TABLE IF NOT EXISTS `tc_horsebreed` (
  `f_horsebreedid` int NOT NULL,
  PRIMARY KEY (`f_horsebreedid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsebreed_des 结构
CREATE TABLE IF NOT EXISTS `tc_horsebreed_des` (
  `f_horsebreedid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_horsebreedlongname` varchar(100) DEFAULT NULL,
  `f_horsebreedshortname` varchar(50) DEFAULT NULL,
  `f_horsebreedcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_horsebreedid`,`f_languagecode`),
  KEY `fk_tc_horsebreed_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_horsebreed_des_tc_horsebreed` FOREIGN KEY (`f_horsebreedid`) REFERENCES `tc_horsebreed` (`f_horsebreedid`),
  CONSTRAINT `fk_tc_horsebreed_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsecolor 结构
CREATE TABLE IF NOT EXISTS `tc_horsecolor` (
  `f_horsecolorid` int NOT NULL,
  PRIMARY KEY (`f_horsecolorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsecolor_des 结构
CREATE TABLE IF NOT EXISTS `tc_horsecolor_des` (
  `f_horsecolorid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_horsecolorlangname` varchar(100) DEFAULT NULL,
  `f_horsecolorshortname` varchar(50) DEFAULT NULL,
  `f_horsecolorcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_horsecolorid`,`f_languagecode`),
  KEY `fk_tc_horsecolor_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_horsecolor_des_tc_horsecolor` FOREIGN KEY (`f_horsecolorid`) REFERENCES `tc_horsecolor` (`f_horsecolorid`),
  CONSTRAINT `fk_tc_horsecolor_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsesex 结构
CREATE TABLE IF NOT EXISTS `tc_horsesex` (
  `f_horsesexid` int NOT NULL,
  PRIMARY KEY (`f_horsesexid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_horsesex_des 结构
CREATE TABLE IF NOT EXISTS `tc_horsesex_des` (
  `f_horsesexid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_horsesexlongname` varchar(100) DEFAULT NULL,
  `f_horsesexshortname` varchar(50) DEFAULT NULL,
  `f_horsesexcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_horsesexid`,`f_languagecode`),
  KEY `fk_tc_horsesex_des_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_horsesex_des_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_horsesex_des_tc_horsesex` FOREIGN KEY (`f_horsesexid`) REFERENCES `tc_horsesex` (`f_horsesexid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_irm 结构
CREATE TABLE IF NOT EXISTS `tc_irm` (
  `f_irmid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_irmcode` varchar(20) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_irmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_irm_des 结构
CREATE TABLE IF NOT EXISTS `tc_irm_des` (
  `f_irmid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_irmlongname` varchar(100) DEFAULT NULL,
  `f_irmshortname` varchar(50) DEFAULT NULL,
  `f_irmcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_irmid`,`f_languagecode`),
  KEY `fk_tc_irm_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_irm_des_tc_irm` FOREIGN KEY (`f_irmid`) REFERENCES `tc_irm` (`f_irmid`),
  CONSTRAINT `fk_tc_irm_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_kr_config 结构
CREATE TABLE IF NOT EXISTS `tc_kr_config` (
  `f_matchnumber` int DEFAULT NULL,
  `f_competitionposition` int DEFAULT NULL,
  `f_historylevel` int DEFAULT NULL,
  `f_comment` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_language 结构
CREATE TABLE IF NOT EXISTS `tc_language` (
  `F_LanguageCode` char(3) NOT NULL,
  `F_LanguageDescription` varchar(50) DEFAULT NULL,
  `F_Active` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_medal 结构
CREATE TABLE IF NOT EXISTS `tc_medal` (
  `f_medalid` int NOT NULL,
  `f_medalcode` char(10) DEFAULT NULL,
  PRIMARY KEY (`f_medalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_medal_des 结构
CREATE TABLE IF NOT EXISTS `tc_medal_des` (
  `f_medalid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_medallongname` varchar(100) DEFAULT NULL,
  `f_medalshortname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_medalid`,`f_languagecode`),
  KEY `fk_tc_medal_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_medal_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_medal_des_tc_medal` FOREIGN KEY (`f_medalid`) REFERENCES `tc_medal` (`f_medalid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_nation 结构
CREATE TABLE IF NOT EXISTS `tc_nation` (
  `f_nationid` int NOT NULL AUTO_INCREMENT,
  `f_nationcode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`f_nationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_nation_des 结构
CREATE TABLE IF NOT EXISTS `tc_nation_des` (
  `f_nationid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_nationlongname` varchar(100) DEFAULT NULL,
  `f_nationshortname` varchar(50) DEFAULT NULL,
  `f_nationcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_nationid`,`f_languagecode`),
  KEY `fk_tc_nation_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_nation_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_nation_des_tc_nation` FOREIGN KEY (`f_nationid`) REFERENCES `tc_nation` (`f_nationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_phase_status 结构
CREATE TABLE IF NOT EXISTS `tc_phase_status` (
  `f_statusid` int NOT NULL,
  PRIMARY KEY (`f_statusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_phase_status_des 结构
CREATE TABLE IF NOT EXISTS `tc_phase_status_des` (
  `f_statusid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_statuslongname` varchar(100) DEFAULT NULL,
  `f_statusshortname` varchar(50) DEFAULT NULL,
  `f_statuscomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_statusid`,`f_languagecode`),
  KEY `fk_tc_phase_status_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_phase_status_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_phase_status_des_tc_phase_status` FOREIGN KEY (`f_statusid`) REFERENCES `tc_phase_status` (`f_statusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_picfile_info 结构
CREATE TABLE IF NOT EXISTS `tc_picfile_info` (
  `f_fileid` int NOT NULL AUTO_INCREMENT,
  `f_filecode` varchar(50) DEFAULT NULL,
  `f_filecomment` varchar(50) DEFAULT NULL,
  `f_filetype` varchar(50) DEFAULT NULL,
  `f_fileinfo` blob,
  PRIMARY KEY (`f_fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_recordtype 结构
CREATE TABLE IF NOT EXISTS `tc_recordtype` (
  `f_recordtypeid` int NOT NULL,
  `f_fatherrecordtypeid` int DEFAULT NULL,
  `f_recordtypecode` varchar(50) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_recordtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_recordtype_des 结构
CREATE TABLE IF NOT EXISTS `tc_recordtype_des` (
  `f_recordtypeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_recordtypelongname` varchar(100) DEFAULT NULL,
  `f_recordtypeshortname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_recordtypeid`,`f_languagecode`),
  KEY `fk_tc_recordtype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_recordtype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_recordtype_des_tc_recordtype` FOREIGN KEY (`f_recordtypeid`) REFERENCES `tc_recordtype` (`f_recordtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_regtype 结构
CREATE TABLE IF NOT EXISTS `tc_regtype` (
  `f_regtypeid` int NOT NULL,
  `f_regtypecode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_regtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_regtypefunction 结构
CREATE TABLE IF NOT EXISTS `tc_regtypefunction` (
  `f_regtypeid` int NOT NULL,
  `f_functionid` int NOT NULL,
  PRIMARY KEY (`f_regtypeid`,`f_functionid`),
  KEY `fk_tc_regtypefunction_td_function` (`f_functionid`),
  CONSTRAINT `fk_tc_regtypefunction_tc_regtype` FOREIGN KEY (`f_regtypeid`) REFERENCES `tc_regtype` (`f_regtypeid`),
  CONSTRAINT `fk_tc_regtypefunction_td_function` FOREIGN KEY (`f_functionid`) REFERENCES `td_function` (`f_functionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_regtype_des 结构
CREATE TABLE IF NOT EXISTS `tc_regtype_des` (
  `f_regtypeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_regtypelangdescription` varchar(50) DEFAULT NULL,
  `f_regtypeshortdescription` varchar(50) DEFAULT NULL,
  `f_regtypecomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_regtypeid`,`f_languagecode`),
  KEY `fk_tc_regtype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_regtype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_regtype_des_tc_regtype` FOREIGN KEY (`f_regtypeid`) REFERENCES `tc_regtype` (`f_regtypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_result 结构
CREATE TABLE IF NOT EXISTS `tc_result` (
  `f_resultid` int NOT NULL,
  `f_resultcode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_result_des 结构
CREATE TABLE IF NOT EXISTS `tc_result_des` (
  `f_resultid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_resultlongname` varchar(100) DEFAULT NULL,
  `f_resultshortname` varchar(50) DEFAULT NULL,
  `f_resultcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_resultid`,`f_languagecode`),
  KEY `fk_tc_result_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_result_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_result_des_tc_result` FOREIGN KEY (`f_resultid`) REFERENCES `tc_result` (`f_resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sessiontype 结构
CREATE TABLE IF NOT EXISTS `tc_sessiontype` (
  `f_sessiontypeid` int NOT NULL,
  PRIMARY KEY (`f_sessiontypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sessiontype_des 结构
CREATE TABLE IF NOT EXISTS `tc_sessiontype_des` (
  `f_sessiontypeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_sessiontypelongname` varchar(50) DEFAULT NULL,
  `f_sessiontypeshortname` varchar(50) DEFAULT NULL,
  `f_sessiontypecomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_sessiontypeid`,`f_languagecode`),
  KEY `fk_tc_sessiontype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_sessiontype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_sessiontype_des_tc_sessiontype` FOREIGN KEY (`f_sessiontypeid`) REFERENCES `tc_sessiontype` (`f_sessiontypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sex 结构
CREATE TABLE IF NOT EXISTS `tc_sex` (
  `f_sexcode` int NOT NULL,
  `f_gendercode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`f_sexcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sex_des 结构
CREATE TABLE IF NOT EXISTS `tc_sex_des` (
  `f_sexcode` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_sexlangname` varchar(50) DEFAULT NULL,
  `f_sexshortname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_sexcode`,`f_languagecode`),
  KEY `pk_tc_sex_des_tc_language` (`f_languagecode`),
  CONSTRAINT `pk_tc_sex_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `pk_tc_sex_des_tc_sex` FOREIGN KEY (`f_sexcode`) REFERENCES `tc_sex` (`f_sexcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sh_seriescode 结构
CREATE TABLE IF NOT EXISTS `tc_sh_seriescode` (
  `f_eventcode` char(3) DEFAULT NULL,
  `f_eventdescribe` varchar(100) DEFAULT NULL,
  `f_stageno` int DEFAULT NULL,
  `f_seriesno` int DEFAULT NULL,
  `f_seriescode` char(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_status 结构
CREATE TABLE IF NOT EXISTS `tc_status` (
  `f_statusid` int NOT NULL,
  `f_statuscode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_statusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_status_des 结构
CREATE TABLE IF NOT EXISTS `tc_status_des` (
  `f_statusid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_statusLongname` varchar(50) DEFAULT NULL,
  `f_statusshortname` varchar(50) DEFAULT NULL,
  `f_statuscomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_statusid`,`f_languagecode`),
  KEY `fk_tc_status_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_status_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_status_des_tc_status` FOREIGN KEY (`f_statusid`) REFERENCES `tc_status` (`f_statusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_sysconfig 结构
CREATE TABLE IF NOT EXISTS `tc_sysconfig` (
  `f_itemid` int NOT NULL,
  `f_itemname` varchar(50) DEFAULT NULL,
  `f_itemvalue` varchar(100) DEFAULT NULL,
  `f_itemcomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_venue 结构
CREATE TABLE IF NOT EXISTS `tc_venue` (
  `f_venueid` int NOT NULL AUTO_INCREMENT,
  `f_cityid` int DEFAULT NULL,
  `f_venuecode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_venueid`),
  KEY `fk_tc_venue_tc_city` (`f_cityid`),
  CONSTRAINT `fk_tc_venue_tc_city` FOREIGN KEY (`f_cityid`) REFERENCES `tc_city` (`F_CityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_venue_des 结构
CREATE TABLE IF NOT EXISTS `tc_venue_des` (
  `f_venueid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_venuelongname` varchar(100) DEFAULT NULL,
  `f_venueshortname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_venueid`,`f_languagecode`),
  KEY `fk_tc_venue_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_venue_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_venue_des_tc_venue` FOREIGN KEY (`f_venueid`) REFERENCES `tc_venue` (`f_venueid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_weathertype 结构
CREATE TABLE IF NOT EXISTS `tc_weathertype` (
  `f_weathertypeid` int NOT NULL,
  `f_weathercode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`f_weathertypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_weathertype_des 结构
CREATE TABLE IF NOT EXISTS `tc_weathertype_des` (
  `f_weathertypeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_weathertypelongdescription` varchar(50) DEFAULT NULL,
  `f_weathertypeshortdescription` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_weathertypeid`,`f_languagecode`),
  KEY `fk_tc_weathertype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_weathertype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_weathertype_des_tc_weathertype` FOREIGN KEY (`f_weathertypeid`) REFERENCES `tc_weathertype` (`f_weathertypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_winddirection 结构
CREATE TABLE IF NOT EXISTS `tc_winddirection` (
  `f_winddirectionid` int NOT NULL,
  `f_winddirectioncode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_winddirectionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tc_winddirection_des 结构
CREATE TABLE IF NOT EXISTS `tc_winddirection_des` (
  `f_winddirectionid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_winddirectionlongname` varchar(100) DEFAULT NULL,
  `f_winddirectionshortname` varchar(50) DEFAULT NULL,
  `f_winddirectioncomment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_winddirectionid`,`f_languagecode`),
  KEY `fk_tc_winddirection_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_tc_winddirection_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_tc_winddirection_des_tc_winddirection` FOREIGN KEY (`f_winddirectionid`) REFERENCES `tc_winddirection` (`f_winddirectionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_actiontype 结构
CREATE TABLE IF NOT EXISTS `td_actiontype` (
  `f_actiontypeid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_actioncode` varchar(20) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  `f_actioneffect` int DEFAULT NULL,
  `f_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_actiontypeid`),
  KEY `fk_td_actiontype_ts_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_td_actiontype_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_competitionrule 结构
CREATE TABLE IF NOT EXISTS `td_competitionrule` (
  `f_competitionruleid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_competitionruleinfo` text,
  PRIMARY KEY (`f_competitionruleid`),
  KEY `fk_td_competitionrule_ts_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_td_competitionrule_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_competitionrule_des 结构
CREATE TABLE IF NOT EXISTS `td_competitionrule_des` (
  `f_competitionruleid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_competitionlongname` varchar(100) DEFAULT NULL,
  `f_competitionshortname` varchar(50) DEFAULT NULL,
  `f_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_competitionruleid`,`f_languagecode`),
  KEY `fk_td_competitionrule_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_competitionrule_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_td_competitionrule_des_td_competitionrule` FOREIGN KEY (`f_competitionruleid`) REFERENCES `td_competitionrule` (`f_competitionruleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_competitiontype_sq 结构
CREATE TABLE IF NOT EXISTS `td_competitiontype_sq` (
  `f_competitionruleid` int DEFAULT NULL,
  `f_type` int DEFAULT NULL,
  `f_set` int DEFAULT NULL,
  `f_game` int DEFAULT NULL,
  `f_gamepoint` int DEFAULT NULL,
  `f_servertype` int DEFAULT NULL,
  `f_advantage` int DEFAULT NULL,
  `f_winscore1` int DEFAULT NULL,
  `f_winscore2` int DEFAULT NULL,
  `f_setrule` int DEFAULT NULL,
  `f_spliterule` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_discipline_venue 结构
CREATE TABLE IF NOT EXISTS `td_discipline_venue` (
  `f_disciplineid` int NOT NULL,
  `f_venueid` int NOT NULL,
  PRIMARY KEY (`f_disciplineid`,`f_venueid`),
  KEY `fk_td_discipline_venue_tc_venue` (`f_venueid`),
  CONSTRAINT `fk_td_discipline_venue_tc_venue` FOREIGN KEY (`f_venueid`) REFERENCES `tc_venue` (`f_venueid`),
  CONSTRAINT `fk_td_discipline_venue_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_function 结构
CREATE TABLE IF NOT EXISTS `td_function` (
  `f_functionid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_functioncode` varchar(20) DEFAULT NULL,
  `f_functioncategorycode` varchar(50) DEFAULT NULL,
  `f_functiontype` int DEFAULT NULL,
  PRIMARY KEY (`f_functionid`),
  KEY `fk_td_function_ts_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_td_function_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_function_des 结构
CREATE TABLE IF NOT EXISTS `td_function_des` (
  `f_functionid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_functionlongname` varchar(50) DEFAULT NULL,
  `f_functionshortname` varchar(50) DEFAULT NULL,
  `f_functioncomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_functionid`,`f_languagecode`),
  KEY `fk_td_function_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_function_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_td_function_des_td_function` FOREIGN KEY (`f_functionid`) REFERENCES `td_function` (`f_functionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_kr_katatype_des 结构
CREATE TABLE IF NOT EXISTS `td_kr_katatype_des` (
  `f_typeid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_typename` varchar(50) DEFAULT NULL,
  `f_typenamedetail` varchar(100) DEFAULT NULL,
  `f_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_typeid`,`f_languagecode`),
  KEY `fk_td_kr_katatype_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_kr_katatype_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_officialgroup_des 结构
CREATE TABLE IF NOT EXISTS `td_officialgroup_des` (
  `f_officialgroupid` int NOT NULL,
  `f_grouplongname` varchar(50) DEFAULT NULL,
  `f_groupshortname` varchar(20) DEFAULT NULL,
  `f_groupcomment` text,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_officialgroupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_position 结构
CREATE TABLE IF NOT EXISTS `td_position` (
  `f_positionid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_positioncode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`f_positionid`),
  KEY `fk_td_position_ts_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_td_position_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_position_des 结构
CREATE TABLE IF NOT EXISTS `td_position_des` (
  `f_positionid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_positionlongname` varchar(50) DEFAULT NULL,
  `f_positionshortname` varchar(50) DEFAULT NULL,
  `f_positioncomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_positionid`,`f_languagecode`),
  KEY `fk_td_position_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_position_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_td_position_des_td_position` FOREIGN KEY (`f_positionid`) REFERENCES `td_position` (`f_positionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_sp_ro_competitionrulevalue 结构
CREATE TABLE IF NOT EXISTS `td_sp_ro_competitionrulevalue` (
  `f_competitionruleid` int NOT NULL,
  `f_distance` int DEFAULT NULL,
  `f_splites` int DEFAULT NULL,
  PRIMARY KEY (`f_competitionruleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_statistic 结构
CREATE TABLE IF NOT EXISTS `td_statistic` (
  `f_statisticid` int NOT NULL,
  `f_disciplineid` int DEFAULT NULL,
  `f_statisticcode` varchar(20) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  PRIMARY KEY (`f_statisticid`),
  KEY `fk_td_statistic_ts_discipline` (`f_disciplineid`),
  CONSTRAINT `fk_td_statistic_ts_discipline` FOREIGN KEY (`f_disciplineid`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.td_statistic_des 结构
CREATE TABLE IF NOT EXISTS `td_statistic_des` (
  `f_statisticid` int NOT NULL,
  `f_languagecode` char(3) NOT NULL,
  `f_statisticlongname` varchar(50) DEFAULT NULL,
  `f_statisticshortname` varchar(50) DEFAULT NULL,
  `f_statisticcomment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_statisticid`,`f_languagecode`),
  KEY `fk_td_statistic_des_tc_language` (`f_languagecode`),
  CONSTRAINT `fk_td_statistic_des_tc_language` FOREIGN KEY (`f_languagecode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_td_statistic_des_td_statistic` FOREIGN KEY (`f_statisticid`) REFERENCES `td_statistic` (`f_statisticid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.temp_record 结构
CREATE TABLE IF NOT EXISTS `temp_record` (
  `EventName` varchar(100) DEFAULT NULL,
  `EventGender` varchar(50) DEFAULT NULL,
  `EventCode` varchar(50) DEFAULT NULL,
  `SubEventCode` varchar(50) DEFAULT NULL,
  `RecordType` varchar(50) DEFAULT NULL,
  `TeamMember` int DEFAULT NULL,
  `RegisterName` varchar(100) DEFAULT NULL,
  `CountryCode` varchar(50) DEFAULT NULL,
  `RecordValue` varchar(100) DEFAULT NULL,
  `SplitOrder` int DEFAULT NULL,
  `SplitValue` varchar(100) DEFAULT NULL,
  `RecordDate` varchar(100) DEFAULT NULL,
  `RecordLocation` varchar(100) DEFAULT NULL,
  `RecordLocationNOC` varchar(100) DEFAULT NULL,
  `RecordSport` varchar(100) DEFAULT NULL,
  `RecordWind` varchar(100) DEFAULT NULL,
  `RecordComment` varchar(100) DEFAULT NULL,
  `Active` int DEFAULT NULL,
  `IsEquall` int DEFAULT NULL,
  `F_EventID` int DEFAULT NULL,
  `F_RecordTypeID` int DEFAULT NULL,
  `F_RecordTypeOrder` int DEFAULT NULL,
  `F_RecordID` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_SexCode` int DEFAULT NULL,
  `F_RegisterCode` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_cis_server 结构
CREATE TABLE IF NOT EXISTS `ti_cis_server` (
  `f_disciplinecode` varchar(10) NOT NULL,
  `f_itemname` varchar(50) NOT NULL,
  `f_itemleveltype` varchar(50) DEFAULT NULL,
  `f_sqlprocedure` text,
  `f_itemdes` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`f_disciplinecode`,`f_itemname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_crs_info 结构
CREATE TABLE IF NOT EXISTS `ti_crs_info` (
  `f_msgkey` varchar(50) NOT NULL,
  `f_disciplinecode` varchar(50) DEFAULT NULL,
  `f_msgtypeid` varchar(50) DEFAULT NULL,
  `f_msgtypedes` varchar(50) DEFAULT NULL,
  `f_sqlprocedure` text,
  `f_language` varchar(50) DEFAULT NULL,
  `f_msglevel` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`f_msgkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_ids_msgstack 结构
CREATE TABLE IF NOT EXISTS `ti_ids_msgstack` (
  `f_id` int NOT NULL AUTO_INCREMENT,
  `f_disciplinecode` varchar(10) DEFAULT NULL,
  `f_msgid` int DEFAULT NULL,
  `f_destination` int DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_ids_number 结构
CREATE TABLE IF NOT EXISTS `ti_ids_number` (
  `f_id` int NOT NULL AUTO_INCREMENT,
  `f_disciplinecode` varchar(10) DEFAULT NULL,
  `f_rsc` varchar(10) DEFAULT NULL,
  `f_category` varchar(10) DEFAULT NULL,
  `f_msgtype` varchar(10) DEFAULT NULL,
  `f_destination` int DEFAULT NULL,
  `f_version` int DEFAULT NULL,
  `f_correction` int DEFAULT NULL,
  `f_freeze` int DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_ids_setting 结构
CREATE TABLE IF NOT EXISTS `ti_ids_setting` (
  `f_id` int NOT NULL AUTO_INCREMENT,
  `f_disciplinecode` varchar(10) DEFAULT NULL,
  `f_category` varchar(10) DEFAULT NULL,
  `f_msgcode` varchar(10) DEFAULT NULL,
  `f_msgtype` varchar(10) DEFAULT NULL,
  `f_msglevel` int DEFAULT NULL,
  `f_description` varchar(100) DEFAULT NULL,
  `f_sql` text,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_id_msg 结构
CREATE TABLE IF NOT EXISTS `ti_id_msg` (
  `f_id` int NOT NULL AUTO_INCREMENT,
  `f_disciplinecode` varchar(10) DEFAULT NULL,
  `f_rsc` varchar(10) DEFAULT NULL,
  `f_category` varchar(10) DEFAULT NULL,
  `f_msgcode` varchar(10) DEFAULT NULL,
  `f_parameter` varchar(100) DEFAULT NULL,
  `f_paramdes` varchar(200) DEFAULT NULL,
  `f_lasttime` varchar(50) DEFAULT NULL,
  `f_stkcount` int DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_infotopic 结构
CREATE TABLE IF NOT EXISTS `ti_infotopic` (
  `F_InfoTopicID` int NOT NULL AUTO_INCREMENT,
  `F_DisciplineCode` varchar(10) DEFAULT NULL,
  `F_TopicID` int DEFAULT NULL,
  `F_TopicName` varchar(50) DEFAULT NULL,
  `F_TopicDescription` varchar(100) DEFAULT NULL,
  `F_SubscriptionType` int DEFAULT NULL,
  `F_UpdateType` int DEFAULT NULL,
  `F_UpdateStatus` int DEFAULT NULL,
  `F_NeedUpdateCount` int DEFAULT NULL,
  `F_UpdatedCount` int DEFAULT NULL,
  `F_SqlProcedure` text,
  `F_FieldsDefine` text,
  `F_IndexValue` int DEFAULT NULL,
  PRIMARY KEY (`F_InfoTopicID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ti_tvresulttable 结构
CREATE TABLE IF NOT EXISTS `ti_tvresulttable` (
  `f_disciplinecode` varchar(10) NOT NULL,
  `f_tablename` varchar(50) NOT NULL,
  `f_tableleveltype` varchar(50) DEFAULT NULL,
  `f_sqlprocedure` text,
  `f_updatetype` int DEFAULT NULL,
  PRIMARY KEY (`f_disciplinecode`,`f_tablename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tm_ha_config 结构
CREATE TABLE IF NOT EXISTS `tm_ha_config` (
  `f_eventcode` varchar(20) DEFAULT NULL,
  `f_homenoc` char(3) DEFAULT NULL,
  `f_awaynoc` char(3) DEFAULT NULL,
  `f_number` int DEFAULT NULL,
  `f_hregisterid` int DEFAULT NULL,
  `f_aregisterid` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tm_modeltype_position 结构
CREATE TABLE IF NOT EXISTS `tm_modeltype_position` (
  `f_modeltype` int DEFAULT NULL,
  `f_modelposition` int DEFAULT NULL,
  `f_modelsection_l1` int DEFAULT NULL,
  `f_modelsection_l2` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tm_phase_matchpoint 结构
CREATE TABLE IF NOT EXISTS `tm_phase_matchpoint` (
  `f_modelid` int NOT NULL,
  `f_phaseid` int NOT NULL,
  `f_wonmatchpoint` int DEFAULT NULL,
  `f_drawmatchpoint` int DEFAULT NULL,
  `f_lostmatchpoint` int DEFAULT NULL,
  PRIMARY KEY (`f_modelid`,`f_phaseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_event_operator 结构
CREATE TABLE IF NOT EXISTS `to_event_operator` (
  `F_EventID` int NOT NULL,
  `F_RoleID` int NOT NULL,
  `F_PersonID` int NOT NULL,
  PRIMARY KEY (`F_EventID`,`F_RoleID`,`F_PersonID`),
  KEY `FK_TO_Event_Operator_TO_Person_Role` (`F_PersonID`,`F_RoleID`),
  CONSTRAINT `FK_TO_Event_Operator_TO_Person_Role` FOREIGN KEY (`F_PersonID`, `F_RoleID`) REFERENCES `to_person_role` (`F_PersonID`, `F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_match_operator 结构
CREATE TABLE IF NOT EXISTS `to_match_operator` (
  `F_MatchID` int NOT NULL,
  `F_RoleID` int NOT NULL,
  `F_PersonID` int NOT NULL,
  PRIMARY KEY (`F_MatchID`,`F_RoleID`,`F_PersonID`),
  KEY `FK_TO_Match_Operator_TO_Person_Role` (`F_PersonID`,`F_RoleID`),
  CONSTRAINT `FK_TO_Match_Operator_TO_Person_Role` FOREIGN KEY (`F_PersonID`, `F_RoleID`) REFERENCES `to_person_role` (`F_PersonID`, `F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_module 结构
CREATE TABLE IF NOT EXISTS `to_module` (
  `F_ModuleID` int NOT NULL,
  PRIMARY KEY (`F_ModuleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_module_des 结构
CREATE TABLE IF NOT EXISTS `to_module_des` (
  `F_ModuleID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_ModuleLongName` varchar(100) DEFAULT NULL,
  `F_ModuleShortName` varchar(50) DEFAULT NULL,
  `F_ModuleComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_ModuleID`,`F_LanguageCode`),
  KEY `FK_TO_Module_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TO_Module_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TO_Module_Des_TO_Module` FOREIGN KEY (`F_ModuleID`) REFERENCES `to_module` (`F_ModuleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_operate 结构
CREATE TABLE IF NOT EXISTS `to_operate` (
  `F_OperateID` int NOT NULL,
  PRIMARY KEY (`F_OperateID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_operate_des 结构
CREATE TABLE IF NOT EXISTS `to_operate_des` (
  `F_OperateID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_OperateLongName` varchar(50) DEFAULT NULL,
  `F_OperateShortName` varchar(50) DEFAULT NULL,
  `F_OperateComment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_OperateID`,`F_LanguageCode`),
  KEY `FK_TO_Operate_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TO_Operate_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TO_Operate_Des_TO_Operate` FOREIGN KEY (`F_OperateID`) REFERENCES `to_operate` (`F_OperateID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_person 结构
CREATE TABLE IF NOT EXISTS `to_person` (
  `F_PersonID` int NOT NULL AUTO_INCREMENT,
  `F_PersonLongName` varchar(50) DEFAULT NULL,
  `F_PersonShortName` varchar(30) DEFAULT NULL,
  `F_PassWord` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_person_role 结构
CREATE TABLE IF NOT EXISTS `to_person_role` (
  `F_PersonID` int NOT NULL,
  `F_RoleID` int NOT NULL,
  PRIMARY KEY (`F_PersonID`,`F_RoleID`),
  CONSTRAINT `FK_TO_Person_Role_TO_Person` FOREIGN KEY (`F_PersonID`) REFERENCES `to_person` (`F_PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_phase_operator 结构
CREATE TABLE IF NOT EXISTS `to_phase_operator` (
  `F_PhaseID` int NOT NULL,
  `F_RoleID` int NOT NULL,
  `F_PersonID` int NOT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_RoleID`,`F_PersonID`),
  KEY `FK_TO_Phase_Operator_TO_Person_Role` (`F_PersonID`,`F_RoleID`),
  CONSTRAINT `FK_TO_Phase_Operator_TO_Person_Role` FOREIGN KEY (`F_PersonID`, `F_RoleID`) REFERENCES `to_person_role` (`F_PersonID`, `F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_role 结构
CREATE TABLE IF NOT EXISTS `to_role` (
  `F_RoleID` int NOT NULL,
  PRIMARY KEY (`F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_role_des 结构
CREATE TABLE IF NOT EXISTS `to_role_des` (
  `F_RoleID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_LongRoleName` varchar(50) DEFAULT NULL,
  `F_ShortRoleName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RoleID`,`F_LanguageCode`),
  CONSTRAINT `FK_TO_Role_Des_TO_Role` FOREIGN KEY (`F_RoleID`) REFERENCES `to_role` (`F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_role_module 结构
CREATE TABLE IF NOT EXISTS `to_role_module` (
  `F_RoleID` int NOT NULL,
  `F_ModuleID` int NOT NULL,
  PRIMARY KEY (`F_RoleID`,`F_ModuleID`),
  KEY `FK_TO_Role_Module_TO_Module` (`F_ModuleID`),
  CONSTRAINT `FK_TO_Role_Module_TO_Module` FOREIGN KEY (`F_ModuleID`) REFERENCES `to_module` (`F_ModuleID`),
  CONSTRAINT `K_TO_Role_Module_TO_Role` FOREIGN KEY (`F_RoleID`) REFERENCES `to_role` (`F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_role_operate 结构
CREATE TABLE IF NOT EXISTS `to_role_operate` (
  `F_RoleID` int NOT NULL,
  `F_OperateID` int NOT NULL,
  PRIMARY KEY (`F_RoleID`,`F_OperateID`),
  KEY `FK_TO_Role_Operate_TO_Operate` (`F_OperateID`),
  CONSTRAINT `FK_TO_Role_Operate_TO_Operate` FOREIGN KEY (`F_OperateID`) REFERENCES `to_operate` (`F_OperateID`),
  CONSTRAINT `FK_TO_Role_Operate_TO_Role` FOREIGN KEY (`F_RoleID`) REFERENCES `to_role` (`F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.to_sport_operator 结构
CREATE TABLE IF NOT EXISTS `to_sport_operator` (
  `F_SportID` int NOT NULL,
  `F_RoleID` int NOT NULL,
  `F_PersonID` int NOT NULL,
  PRIMARY KEY (`F_SportID`,`F_RoleID`,`F_PersonID`),
  KEY `fk_to_sport_operator_to_person_role` (`F_PersonID`,`F_RoleID`),
  CONSTRAINT `fk_to_sport_operator_to_person_role` FOREIGN KEY (`F_PersonID`, `F_RoleID`) REFERENCES `to_person_role` (`F_PersonID`, `F_RoleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_inscriptiovarchar 结构
CREATE TABLE IF NOT EXISTS `tr_inscriptiovarchar` (
  `F_EventID` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  `F_Seed` int DEFAULT NULL,
  `F_InscriptionNum` int DEFAULT NULL,
  `F_InscriptionResult` varchar(100) DEFAULT NULL,
  `F_InscriptionRank` int DEFAULT NULL,
  `F_Reserve` int DEFAULT NULL,
  `F_ShirtNum` varchar(50) DEFAULT NULL,
  `F_ShirtName` varchar(50) DEFAULT NULL,
  `F_QualificationMethod` varchar(50) DEFAULT NULL,
  `F_InscriptionComment` varchar(100) DEFAULT NULL,
  `F_InscriptionComment1` varchar(100) DEFAULT NULL,
  `F_InscriptionComment2` varchar(100) DEFAULT NULL,
  `F_InscriptionComment3` varchar(100) DEFAULT NULL,
  `F_HorseID` int DEFAULT NULL,
  PRIMARY KEY (`F_EventID`,`F_RegisterID`),
  KEY `fk_TR_Inscription_TR_Register` (`F_RegisterID`),
  CONSTRAINT `fk_TR_Inscription_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `fk_TR_Inscription_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_register 结构
CREATE TABLE IF NOT EXISTS `tr_register` (
  `F_RegisterID` int NOT NULL AUTO_INCREMENT,
  `F_RegTypeID` int DEFAULT NULL,
  `F_RegisterCode` varchar(120) DEFAULT NULL,
  `F_NOC` char(3) DEFAULT NULL,
  `F_ClubID` int DEFAULT NULL,
  `F_FederationID` int DEFAULT NULL,
  `F_SexCode` int DEFAULT NULL,
  `F_Birth_Date` datetime DEFAULT NULL,
  `F_Height` decimal(9,2) DEFAULT NULL,
  `F_Weight` decimal(9,2) DEFAULT NULL,
  `F_NationID` int DEFAULT NULL,
  `F_DisciplineID` int DEFAULT NULL,
  `F_Bib` varchar(20) DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_DelegationID` int DEFAULT NULL,
  `F_RegisterNum` varchar(20) DEFAULT NULL,
  `F_IsRecord` int DEFAULT NULL,
  `F_Birth_City` varchar(50) DEFAULT NULL,
  `F_Birth_Country` char(3) DEFAULT NULL,
  `F_Residence_City` varchar(50) DEFAULT NULL,
  `F_Residence_Country` char(3) DEFAULT NULL,
  `F_HorseSexID` int DEFAULT NULL,
  `F_HorseColorID` int DEFAULT NULL,
  `F_HorseBreedID` int DEFAULT NULL,
  `F_HDes1` varchar(35) DEFAULT NULL,
  `F_HDes2` varchar(35) DEFAULT NULL,
  `F_HDes3` varchar(35) DEFAULT NULL,
  `F_HDes4` varchar(35) DEFAULT NULL,
  `F_HDes5` varchar(35) DEFAULT NULL,
  `F_HDes6` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`F_RegisterID`),
  KEY `fk_TR_Register_TC_CLub` (`F_ClubID`),
  KEY `fk_TR_Register_TC_Country` (`F_NOC`),
  KEY `fk_TR_Register_TC_Country1` (`F_Birth_Country`),
  KEY `fk_TR_Register_TC_Country2` (`F_Residence_Country`),
  KEY `fk_TR_Register_TC_Delegation` (`F_DelegationID`),
  KEY `fk_TR_Register_TC_Federation` (`F_FederationID`),
  KEY `fk_TR_Register_TC_Nation` (`F_NationID`),
  KEY `fk_TR_Register_TC_RegType` (`F_RegTypeID`),
  KEY `fk_TR_Register_TC_Sex` (`F_SexCode`),
  KEY `fk_TR_Register_TD_Function` (`F_FunctionID`),
  KEY `fk_TR_Register_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `fk_TR_Register_TC_CLub` FOREIGN KEY (`F_ClubID`) REFERENCES `tc_club` (`F_ClubID`),
  CONSTRAINT `fk_TR_Register_TC_Country` FOREIGN KEY (`F_NOC`) REFERENCES `tc_country` (`f_noc`),
  CONSTRAINT `fk_TR_Register_TC_Country1` FOREIGN KEY (`F_Birth_Country`) REFERENCES `tc_country` (`f_noc`),
  CONSTRAINT `fk_TR_Register_TC_Country2` FOREIGN KEY (`F_Residence_Country`) REFERENCES `tc_country` (`f_noc`),
  CONSTRAINT `fk_TR_Register_TC_Delegation` FOREIGN KEY (`F_DelegationID`) REFERENCES `tc_delegation` (`f_delegationid`),
  CONSTRAINT `fk_TR_Register_TC_Federation` FOREIGN KEY (`F_FederationID`) REFERENCES `tc_federation` (`f_federationid`),
  CONSTRAINT `fk_TR_Register_TC_Nation` FOREIGN KEY (`F_NationID`) REFERENCES `tc_nation` (`f_nationid`),
  CONSTRAINT `fk_TR_Register_TC_RegType` FOREIGN KEY (`F_RegTypeID`) REFERENCES `tc_regtype` (`f_regtypeid`),
  CONSTRAINT `fk_TR_Register_TC_Sex` FOREIGN KEY (`F_SexCode`) REFERENCES `tc_sex` (`f_sexcode`),
  CONSTRAINT `fk_TR_Register_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `fk_TR_Register_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_register_comment 结构
CREATE TABLE IF NOT EXISTS `tr_register_comment` (
  `F_CommentID` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_Comment_Order` int DEFAULT NULL,
  `F_Title` varchar(50) DEFAULT NULL,
  `F_Comment` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`F_CommentID`),
  KEY `fk_TR_Register_Comment_TR_Register` (`F_RegisterID`),
  CONSTRAINT `fk_TR_Register_Comment_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_register_des 结构
CREATE TABLE IF NOT EXISTS `tr_register_des` (
  `F_RegisterID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_FirstName` varchar(50) DEFAULT NULL,
  `F_LastName` varchar(50) DEFAULT NULL,
  `F_LongName` varchar(100) DEFAULT NULL,
  `F_ShortName` varchar(100) DEFAULT NULL,
  `F_TvLongName` varchar(100) DEFAULT NULL,
  `F_TvShortName` varchar(100) DEFAULT NULL,
  `F_SBLongName` varchar(100) DEFAULT NULL,
  `F_SBShortName` varchar(100) DEFAULT NULL,
  `F_PrintLongName` varchar(100) DEFAULT NULL,
  `F_PrintShortName` varchar(100) DEFAULT NULL,
  `F_WNPA_FirstName` varchar(50) DEFAULT NULL,
  `F_WNPA_LastName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RegisterID`,`F_LanguageCode`),
  KEY `fk_TR_Register_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `fk_TR_Register_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `fk_TR_Register_Des_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_register_member 结构
CREATE TABLE IF NOT EXISTS `tr_register_member` (
  `F_RegisterID` int NOT NULL,
  `F_MemberRegisterID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_ShirtNumber` int DEFAULT NULL,
  `F_KeyPlayer` int DEFAULT NULL,
  `F_Comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RegisterID`,`F_MemberRegisterID`),
  KEY `fk_TR_Register_Member_TD_Function` (`F_FunctionID`),
  KEY `fk_TR_Register_Member_TD_Position` (`F_PositionID`),
  KEY `fk_TR_Register_Member_TR_Register1` (`F_MemberRegisterID`),
  CONSTRAINT `fk_TR_Register_Member_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `fk_TR_Register_Member_TD_Position` FOREIGN KEY (`F_PositionID`) REFERENCES `td_position` (`f_positionid`),
  CONSTRAINT `fk_TR_Register_Member_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `fk_TR_Register_Member_TR_Register1` FOREIGN KEY (`F_MemberRegisterID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.tr_uniform 结构
CREATE TABLE IF NOT EXISTS `tr_uniform` (
  `F_UniformID` int NOT NULL AUTO_INCREMENT,
  `F_RegisterID` int DEFAULT NULL,
  `F_Shirt` int DEFAULT NULL,
  `F_Shorts` int DEFAULT NULL,
  `F_Socks` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_UniformID`),
  KEY `fk_TR_Uniform_TC_Color` (`F_Shirt`),
  KEY `fk_TR_Uniform_TC_Color1` (`F_Shorts`),
  KEY `fk_TR_Uniform_TC_Color2` (`F_Socks`),
  KEY `fk_TR_Uniform_TR_Register` (`F_RegisterID`),
  CONSTRAINT `fk_TR_Uniform_TC_Color` FOREIGN KEY (`F_Shirt`) REFERENCES `tc_color` (`F_ColorID`),
  CONSTRAINT `fk_TR_Uniform_TC_Color1` FOREIGN KEY (`F_Shorts`) REFERENCES `tc_color` (`F_ColorID`),
  CONSTRAINT `fk_TR_Uniform_TC_Color2` FOREIGN KEY (`F_Socks`) REFERENCES `tc_color` (`F_ColorID`),
  CONSTRAINT `fk_TR_Uniform_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_activeclub 结构
CREATE TABLE IF NOT EXISTS `ts_activeclub` (
  `F_ClubID` int NOT NULL,
  `F_DisciplineID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_ClubID`,`F_DisciplineID`),
  KEY `FK_TS_ActiveClub_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_ActiveClub_TC_CLub` FOREIGN KEY (`F_ClubID`) REFERENCES `tc_club` (`F_ClubID`),
  CONSTRAINT `FK_TS_ActiveClub_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_activedelegation 结构
CREATE TABLE IF NOT EXISTS `ts_activedelegation` (
  `F_DelegationID` int NOT NULL,
  `F_DisciplineID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_DelegationID`,`F_DisciplineID`),
  KEY `FK_TS_ActiveDelegation_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_ActiveDelegation_TC_Delegation` FOREIGN KEY (`F_DelegationID`) REFERENCES `tc_delegation` (`f_delegationid`),
  CONSTRAINT `FK_TS_ActiveDelegation_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_activefederation 结构
CREATE TABLE IF NOT EXISTS `ts_activefederation` (
  `F_FederationID` int NOT NULL,
  `F_DisciplineID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_FederationID`,`F_DisciplineID`),
  KEY `FK_TS_ActiveFederation_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_ActiveFederation_TC_Federation` FOREIGN KEY (`F_FederationID`) REFERENCES `tc_federation` (`f_federationid`),
  CONSTRAINT `FK_TS_ActiveFederation_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_activenoc 结构
CREATE TABLE IF NOT EXISTS `ts_activenoc` (
  `F_NOC` char(3) NOT NULL,
  `F_DisciplineID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_NOC`,`F_DisciplineID`),
  KEY `FK_TS_ActiveNOC_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_ActiveNOC_TC_Country` FOREIGN KEY (`F_NOC`) REFERENCES `tc_country` (`f_noc`),
  CONSTRAINT `FK_TS_ActiveNOC_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_discipline 结构
CREATE TABLE IF NOT EXISTS `ts_discipline` (
  `f_disciplineid` int NOT NULL AUTO_INCREMENT,
  `f_sportid` int DEFAULT NULL,
  `f_disciplinecode` char(2) DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  `f_disciplineinfo` varchar(50) DEFAULT NULL,
  `f_active` int DEFAULT NULL,
  PRIMARY KEY (`f_disciplineid`),
  KEY `fk_ts_discipline_ts_sport` (`f_sportid`),
  CONSTRAINT `fk_ts_discipline_ts_sport` FOREIGN KEY (`f_sportid`) REFERENCES `ts_sport` (`f_sportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_disciplinedate 结构
CREATE TABLE IF NOT EXISTS `ts_disciplinedate` (
  `F_DisciplineDateID` int NOT NULL,
  `F_DisciplineID` int DEFAULT NULL,
  `F_DateOrder` int DEFAULT NULL,
  `F_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`F_DisciplineDateID`),
  KEY `FK_TS_DisciplineDate_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_DisciplineDate_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_disciplinedate_des 结构
CREATE TABLE IF NOT EXISTS `ts_disciplinedate_des` (
  `F_DisciplineDateID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_DateLongDescription` varchar(100) DEFAULT NULL,
  `F_DateShortDescription` varchar(50) DEFAULT NULL,
  `F_DateComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_DisciplineDateID`,`F_LanguageCode`),
  KEY `FK_TS_DisciplineDate_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_DisciplineDate_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_DisciplineDate_Des_TS_DisciplineDate` FOREIGN KEY (`F_DisciplineDateID`) REFERENCES `ts_disciplinedate` (`F_DisciplineDateID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_discipline_des 结构
CREATE TABLE IF NOT EXISTS `ts_discipline_des` (
  `F_DisciplineID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_DisciplineLongName` varchar(50) DEFAULT NULL,
  `F_DisciplineShortName` varchar(50) DEFAULT NULL,
  `F_DisciplineComment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_DisciplineID`,`F_LanguageCode`),
  CONSTRAINT `FK_TS_Discipline_Des_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_match_config 结构
CREATE TABLE IF NOT EXISTS `ts_eq_match_config` (
  `F_MatchConfigID` int NOT NULL,
  `F_TeamMatchConfigID` int DEFAULT NULL,
  `F_MatchConfigCode` varchar(10) DEFAULT NULL,
  `F_EventCode` varchar(10) DEFAULT NULL,
  `F_PhaseCode` varchar(10) DEFAULT NULL,
  `F_MatchCode` varchar(10) DEFAULT NULL,
  `F_EventConfigID` int DEFAULT NULL,
  `F_EventConfigCode` varchar(10) DEFAULT NULL,
  `F_MatchRuleID` int DEFAULT NULL,
  `F_MatchRuleCode` varchar(10) DEFAULT NULL,
  `F_Days` int DEFAULT NULL,
  `F_RiderToNext` int DEFAULT NULL,
  `F_RiderToNextTeam` int DEFAULT NULL,
  `F_AddResult` varchar(10) DEFAULT NULL,
  `F_AddResultTeam` varchar(10) DEFAULT NULL,
  `F_HasMedal` int DEFAULT NULL,
  `F_HasMedalTeam` int DEFAULT NULL,
  `F_Judge` varchar(20) DEFAULT NULL,
  `F_Break` int DEFAULT NULL,
  `F_PerNOC` int DEFAULT NULL,
  `F_MaxCode` int DEFAULT NULL,
  `F_MaxMovementScore` int DEFAULT NULL,
  `F_Distance` int DEFAULT NULL,
  `F_Speed` int DEFAULT NULL,
  `F_TimeAllowed` int DEFAULT NULL,
  `F_TimeLimit` int DEFAULT NULL,
  `F_Coefficients` int DEFAULT NULL,
  `F_Seconds` int DEFAULT NULL,
  `F_Penalties` decimal(5,2) DEFAULT NULL,
  `F_RiderInterval` varchar(50) DEFAULT NULL,
  `F_IsAgainstClock` int DEFAULT NULL,
  `F_IsYouth` int DEFAULT NULL,
  `F_TimeBest` int DEFAULT NULL,
  `F_IsJumpOff` int DEFAULT NULL,
  `F_Obstacles` varchar(50) DEFAULT NULL,
  `F_Efforts` varchar(50) DEFAULT NULL,
  `F_Rounds` varchar(50) DEFAULT NULL,
  `F_JumpOff` varchar(50) DEFAULT NULL,
  `F_Type` varchar(50) DEFAULT NULL,
  `F_TimeAllowedJO` varchar(50) DEFAULT NULL,
  `F_Comment1` varchar(50) DEFAULT NULL,
  `F_Comment2` varchar(50) DEFAULT NULL,
  `F_Comment3` varchar(50) DEFAULT NULL,
  `F_Comment4` varchar(50) DEFAULT NULL,
  `F_Comment5` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchConfigID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_match_mf 结构
CREATE TABLE IF NOT EXISTS `ts_eq_match_mf` (
  `F_MatchConfigID` int DEFAULT NULL,
  `F_MFCode` int DEFAULT NULL,
  `F_MFCodeDes` varchar(10) DEFAULT NULL,
  `F_MFID` int DEFAULT NULL,
  `F_Coefficient` int DEFAULT NULL,
  `F_MovementType` varchar(1) DEFAULT NULL,
  `F_SubFences` int DEFAULT NULL,
  `F_SubFencesDes` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_match_result 结构
CREATE TABLE IF NOT EXISTS `ts_eq_match_result` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_TeamOrder` int DEFAULT NULL,
  `F_RegisterID` int NOT NULL,
  `F_TeamRegisterID` int DEFAULT NULL,
  `F_HorseID` int DEFAULT NULL,
  `F_Status` int DEFAULT NULL,
  `F_PrePoints` decimal(18,9) DEFAULT NULL,
  `F_PreRank` varchar(10) DEFAULT NULL,
  `F_PreIRM` varchar(10) DEFAULT NULL,
  `F_E` decimal(18,9) DEFAULT NULL,
  `F_ENum` decimal(18,9) DEFAULT NULL,
  `F_ERank` varchar(10) DEFAULT NULL,
  `F_H` decimal(18,9) DEFAULT NULL,
  `F_HNum` decimal(18,9) DEFAULT NULL,
  `F_HRank` varchar(10) DEFAULT NULL,
  `F_C` decimal(18,9) DEFAULT NULL,
  `F_CNum` decimal(18,9) DEFAULT NULL,
  `F_CRank` varchar(10) DEFAULT NULL,
  `F_M` decimal(18,9) DEFAULT NULL,
  `F_MNum` decimal(18,9) DEFAULT NULL,
  `F_MRank` varchar(10) DEFAULT NULL,
  `F_B` decimal(18,9) DEFAULT NULL,
  `F_BNum` decimal(18,9) DEFAULT NULL,
  `F_BRank` varchar(10) DEFAULT NULL,
  `F_CurNumPoints` decimal(18,9) DEFAULT NULL,
  `F_CurPoints` decimal(18,9) DEFAULT NULL,
  `F_CurRank` varchar(10) DEFAULT NULL,
  `F_CurIRM` varchar(10) DEFAULT NULL,
  `F_TotPoints` decimal(18,9) DEFAULT NULL,
  `F_TotResult` varchar(50) DEFAULT NULL,
  `F_TotRank` varchar(10) DEFAULT NULL,
  `F_TotIRM` varchar(10) DEFAULT NULL,
  `F_TotOrder` int DEFAULT NULL,
  `F_TotTeamOrder` int DEFAULT NULL,
  `F_Qualify` char(1) DEFAULT NULL,
  `F_Team` char(1) DEFAULT NULL,
  `F_TeamUsed` char(1) DEFAULT NULL,
  `F_TeamRow` int DEFAULT NULL,
  `F_TeamTime` decimal(18,9) DEFAULT NULL,
  `F_StartTime` varchar(50) DEFAULT NULL,
  `F_IsBreak` int DEFAULT NULL,
  `F_BreakTime` varchar(50) DEFAULT NULL,
  `F_FinishTime` varchar(50) DEFAULT NULL,
  `F_CurTime` decimal(18,9) DEFAULT NULL,
  `F_CurTimeDiff` decimal(18,9) DEFAULT NULL,
  `F_TotTimeDiff` decimal(18,9) DEFAULT NULL,
  `F_CurTimePen` decimal(18,9) DEFAULT NULL,
  `F_CurJumpPen` decimal(18,9) DEFAULT NULL,
  `F_CurTotalPen` decimal(18,9) DEFAULT NULL,
  `F_ETec` decimal(18,9) DEFAULT NULL,
  `F_ETecRank` varchar(10) DEFAULT NULL,
  `F_HTec` decimal(18,9) DEFAULT NULL,
  `F_HTecRank` varchar(10) DEFAULT NULL,
  `F_CTec` decimal(18,9) DEFAULT NULL,
  `F_CTecRank` varchar(10) DEFAULT NULL,
  `F_MTec` decimal(18,9) DEFAULT NULL,
  `F_MTecRank` varchar(10) DEFAULT NULL,
  `F_BTec` decimal(18,9) DEFAULT NULL,
  `F_BTecRank` varchar(10) DEFAULT NULL,
  `F_EArt` decimal(18,9) DEFAULT NULL,
  `F_EArtRank` varchar(10) DEFAULT NULL,
  `F_HArt` decimal(18,9) DEFAULT NULL,
  `F_HArtRank` varchar(10) DEFAULT NULL,
  `F_CArt` decimal(18,9) DEFAULT NULL,
  `F_CArtRank` varchar(10) DEFAULT NULL,
  `F_MArt` decimal(18,9) DEFAULT NULL,
  `F_MArtRank` varchar(10) DEFAULT NULL,
  `F_BArt` decimal(18,9) DEFAULT NULL,
  `F_BArtRank` varchar(10) DEFAULT NULL,
  `F_TecPoints` decimal(18,9) DEFAULT NULL,
  `F_TecRank` varchar(10) DEFAULT NULL,
  `F_ArtPoints` decimal(18,9) DEFAULT NULL,
  `F_ArtRank` varchar(10) DEFAULT NULL,
  `F_HarmonyPoints` decimal(18,9) DEFAULT NULL,
  `F_EDRPoints` decimal(18,9) DEFAULT NULL,
  `F_Comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`,`F_RegisterID`),
  KEY `FK_TS_EQ_Match_Result_TR_Register` (`F_RegisterID`),
  KEY `FK_TS_EQ_Match_Result_TR_Register1` (`F_HorseID`),
  CONSTRAINT `FK_TS_EQ_Match_Result_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_EQ_Match_Result_TR_Register1` FOREIGN KEY (`F_HorseID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_match_resultdetail 结构
CREATE TABLE IF NOT EXISTS `ts_eq_match_resultdetail` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_JudgePosition` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  `F_Judge` char(1) DEFAULT NULL,
  `F_Status` int DEFAULT NULL,
  `F_StatusDes` varchar(10) DEFAULT NULL,
  `F_XmlScore` text,
  `F_NumPoints` float DEFAULT NULL,
  `F_TecNumPoints` float DEFAULT NULL,
  `F_ArtNumPoints` float DEFAULT NULL,
  `F_1` float DEFAULT NULL,
  `F_1Des` varchar(10) DEFAULT NULL,
  `F_2` float DEFAULT NULL,
  `F_2Des` varchar(10) DEFAULT NULL,
  `F_3` float DEFAULT NULL,
  `F_3Des` varchar(10) DEFAULT NULL,
  `F_4` float DEFAULT NULL,
  `F_4Des` varchar(10) DEFAULT NULL,
  `F_5` float DEFAULT NULL,
  `F_5Des` varchar(10) DEFAULT NULL,
  `F_6` float DEFAULT NULL,
  `F_6Des` varchar(10) DEFAULT NULL,
  `F_7` float DEFAULT NULL,
  `F_7Des` varchar(10) DEFAULT NULL,
  `F_8` float DEFAULT NULL,
  `F_8Des` varchar(10) DEFAULT NULL,
  `F_9` float DEFAULT NULL,
  `F_9Des` varchar(10) DEFAULT NULL,
  `F_10` float DEFAULT NULL,
  `F_10Des` varchar(10) DEFAULT NULL,
  `F_11` float DEFAULT NULL,
  `F_11Des` varchar(10) DEFAULT NULL,
  `F_12` float DEFAULT NULL,
  `F_12Des` varchar(10) DEFAULT NULL,
  `F_13` float DEFAULT NULL,
  `F_13Des` varchar(10) DEFAULT NULL,
  `F_14` float DEFAULT NULL,
  `F_14Des` varchar(10) DEFAULT NULL,
  `F_15` float DEFAULT NULL,
  `F_15Des` varchar(10) DEFAULT NULL,
  `F_16` float DEFAULT NULL,
  `F_16Des` varchar(10) DEFAULT NULL,
  `F_17` float DEFAULT NULL,
  `F_17Des` varchar(10) DEFAULT NULL,
  `F_18` float DEFAULT NULL,
  `F_18Des` varchar(10) DEFAULT NULL,
  `F_19` float DEFAULT NULL,
  `F_19Des` varchar(10) DEFAULT NULL,
  `F_20` float DEFAULT NULL,
  `F_20Des` varchar(10) DEFAULT NULL,
  `F_21` float DEFAULT NULL,
  `F_21Des` varchar(10) DEFAULT NULL,
  `F_22` float DEFAULT NULL,
  `F_22Des` varchar(10) DEFAULT NULL,
  `F_23` float DEFAULT NULL,
  `F_23Des` varchar(10) DEFAULT NULL,
  `F_24` float DEFAULT NULL,
  `F_24Des` varchar(10) DEFAULT NULL,
  `F_25` float DEFAULT NULL,
  `F_25Des` varchar(10) DEFAULT NULL,
  `F_26` float DEFAULT NULL,
  `F_26Des` varchar(10) DEFAULT NULL,
  `F_27` float DEFAULT NULL,
  `F_27Des` varchar(10) DEFAULT NULL,
  `F_28` float DEFAULT NULL,
  `F_28Des` varchar(10) DEFAULT NULL,
  `F_29` float DEFAULT NULL,
  `F_29Des` varchar(10) DEFAULT NULL,
  `F_30` float DEFAULT NULL,
  `F_30Des` varchar(10) DEFAULT NULL,
  `F_31` float DEFAULT NULL,
  `F_31Des` varchar(10) DEFAULT NULL,
  `F_32` float DEFAULT NULL,
  `F_32Des` varchar(10) DEFAULT NULL,
  `F_33` float DEFAULT NULL,
  `F_33Des` varchar(10) DEFAULT NULL,
  `F_34` float DEFAULT NULL,
  `F_34Des` varchar(10) DEFAULT NULL,
  `F_35` float DEFAULT NULL,
  `F_35Des` varchar(10) DEFAULT NULL,
  `F_36` float DEFAULT NULL,
  `F_36Des` varchar(10) DEFAULT NULL,
  `F_37` float DEFAULT NULL,
  `F_37Des` varchar(10) DEFAULT NULL,
  `F_38` float DEFAULT NULL,
  `F_38Des` varchar(10) DEFAULT NULL,
  `F_39` float DEFAULT NULL,
  `F_39Des` varchar(10) DEFAULT NULL,
  `F_40` float DEFAULT NULL,
  `F_40Des` varchar(10) DEFAULT NULL,
  `F_41` float DEFAULT NULL,
  `F_41Des` varchar(10) DEFAULT NULL,
  `F_42` float DEFAULT NULL,
  `F_42Des` varchar(10) DEFAULT NULL,
  `F_43` float DEFAULT NULL,
  `F_43Des` varchar(10) DEFAULT NULL,
  `F_44` float DEFAULT NULL,
  `F_44Des` varchar(10) DEFAULT NULL,
  `F_45` float DEFAULT NULL,
  `F_45Des` varchar(10) DEFAULT NULL,
  `F_46` float DEFAULT NULL,
  `F_46Des` varchar(10) DEFAULT NULL,
  `F_47` float DEFAULT NULL,
  `F_47Des` varchar(10) DEFAULT NULL,
  `F_48` float DEFAULT NULL,
  `F_48Des` varchar(10) DEFAULT NULL,
  `F_49` float DEFAULT NULL,
  `F_49Des` varchar(10) DEFAULT NULL,
  `F_50` float DEFAULT NULL,
  `F_50Des` varchar(10) DEFAULT NULL,
  `F_0` float DEFAULT NULL,
  `F_0Des` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`,`F_JudgePosition`,`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_mf 结构
CREATE TABLE IF NOT EXISTS `ts_eq_mf` (
  `F_MFID` int NOT NULL,
  `F_MFType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MFID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_mf_des 结构
CREATE TABLE IF NOT EXISTS `ts_eq_mf_des` (
  `F_MFID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_MFLongName` varchar(200) DEFAULT NULL,
  `F_MFShortName` varchar(200) DEFAULT NULL,
  `F_MFComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_MFID`,`F_LanguageCode`),
  KEY `FK_TS_EQ_MF_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_EQ_MF_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_EQ_MF_Des_TS_EQ_MF` FOREIGN KEY (`F_MFID`) REFERENCES `ts_eq_mf` (`F_MFID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_pentype 结构
CREATE TABLE IF NOT EXISTS `ts_eq_pentype` (
  `F_PenTypeID` int NOT NULL,
  `F_MatchRuleID` int DEFAULT NULL,
  `F_PenPoints` int DEFAULT NULL,
  `F_IRM` varchar(10) DEFAULT NULL,
  `F_Key` char(2) DEFAULT NULL,
  PRIMARY KEY (`F_PenTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_eq_pentype_des 结构
CREATE TABLE IF NOT EXISTS `ts_eq_pentype_des` (
  `F_PenTypeID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_PenTypeLongName` varchar(100) DEFAULT NULL,
  `F_PenTypeShortName` varchar(50) DEFAULT NULL,
  `F_PenTypeComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_PenTypeID`,`F_LanguageCode`),
  KEY `FK_TS_EQ_PenType_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_EQ_PenType_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_EQ_PenType_Des_TS_EQ_PenType` FOREIGN KEY (`F_PenTypeID`) REFERENCES `ts_eq_pentype` (`F_PenTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event 结构
CREATE TABLE IF NOT EXISTS `ts_event` (
  `F_EventID` int NOT NULL AUTO_INCREMENT,
  `F_DisciplineID` int DEFAULT NULL,
  `F_EventCode` varchar(10) DEFAULT NULL,
  `F_OpenDate` datetime DEFAULT NULL,
  `F_CloseDate` datetime DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_SexCode` int DEFAULT NULL,
  `F_EventInfo` varchar(50) DEFAULT NULL,
  `F_PlayerRegTypeID` int DEFAULT NULL,
  `F_CompetitionTypeID` int DEFAULT NULL,
  `F_EventStatusID` int DEFAULT NULL,
  `F_UsingModelID` int DEFAULT NULL,
  `F_EventOutCode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_EventID`),
  KEY `fk_TS_Event_TC_CompetitionType` (`F_CompetitionTypeID`),
  KEY `fk_TS_Event_TC_Event_Status` (`F_EventStatusID`),
  KEY `fk_TS_Event_TC_RegType` (`F_PlayerRegTypeID`),
  KEY `fk_TS_Event_TC_Sex` (`F_SexCode`),
  KEY `fk_TS_Event_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `fk_TS_Event_TC_CompetitionType` FOREIGN KEY (`F_CompetitionTypeID`) REFERENCES `tc_competitiontype` (`f_competitiontypeid`),
  CONSTRAINT `fk_TS_Event_TC_Event_Status` FOREIGN KEY (`F_EventStatusID`) REFERENCES `tc_event_status` (`f_statusid`),
  CONSTRAINT `fk_TS_Event_TC_RegType` FOREIGN KEY (`F_PlayerRegTypeID`) REFERENCES `tc_regtype` (`f_regtypeid`),
  CONSTRAINT `fk_TS_Event_TC_Sex` FOREIGN KEY (`F_SexCode`) REFERENCES `tc_sex` (`f_sexcode`),
  CONSTRAINT `fk_TS_Event_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event_competitors 结构
CREATE TABLE IF NOT EXISTS `ts_event_competitors` (
  `F_EventID` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  PRIMARY KEY (`F_EventID`,`F_RegisterID`),
  KEY `FK_TS_Event_Competitors_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Event_Competitors_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Event_Competitors_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event_des 结构
CREATE TABLE IF NOT EXISTS `ts_event_des` (
  `F_EventID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_EventLongName` varchar(100) DEFAULT NULL,
  `F_EventShortName` varchar(50) DEFAULT NULL,
  `F_EventComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_EventID`,`F_LanguageCode`),
  KEY `FK_TS_Event_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Event_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Event_Des_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event_position 结构
CREATE TABLE IF NOT EXISTS `ts_event_position` (
  `F_ItemID` int NOT NULL AUTO_INCREMENT,
  `F_EventID` int DEFAULT NULL,
  `F_EventPosition` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  PRIMARY KEY (`F_ItemID`),
  KEY `FK_TS_Event_Position_TR_Register` (`F_RegisterID`),
  KEY `FK_TS_Event_Position_TS_Event` (`F_EventID`),
  CONSTRAINT `FK_TS_Event_Position_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Event_Position_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event_record 结构
CREATE TABLE IF NOT EXISTS `ts_event_record` (
  `F_RecordID` int NOT NULL AUTO_INCREMENT,
  `F_RecordType` varchar(50) DEFAULT NULL,
  `F_Equalled` int DEFAULT NULL,
  `F_EventID` int DEFAULT NULL,
  `F_Location` varchar(50) DEFAULT NULL,
  `F_LocationNOC` char(3) DEFAULT NULL,
  `F_RecordSport` varchar(50) DEFAULT NULL,
  `F_CompetitorGender` varchar(50) DEFAULT NULL,
  `F_EventCode` varchar(50) DEFAULT NULL,
  `F_SubEventCode` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `F_RecordDate` datetime DEFAULT NULL,
  `F_RecordValue` varchar(50) DEFAULT NULL,
  `F_RecordWind` varchar(50) DEFAULT NULL,
  `F_RecordComment` varchar(50) DEFAULT NULL,
  `F_CompetitorCode` varchar(50) DEFAULT NULL,
  `F_CompetitorNOC` char(3) DEFAULT NULL,
  `F_CompetitorFamilyName` varchar(50) DEFAULT NULL,
  `F_CompetitorGivenName` varchar(50) DEFAULT NULL,
  `F_CompetitorBirthDate` datetime DEFAULT NULL,
  `F_CompetitorReportingName` varchar(50) DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_Active` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_RecordTypeID` int DEFAULT NULL,
  `F_IsNewCreated` int DEFAULT NULL,
  PRIMARY KEY (`F_RecordID`),
  KEY `FK_TS_Event_Record_TC_RecordType` (`F_RecordTypeID`),
  KEY `FK_TS_Event_Record_TS_Event` (`F_EventID`),
  CONSTRAINT `FK_TS_Event_Record_TC_RecordType` FOREIGN KEY (`F_RecordTypeID`) REFERENCES `tc_recordtype` (`f_recordtypeid`),
  CONSTRAINT `FK_TS_Event_Record_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_event_result 结构
CREATE TABLE IF NOT EXISTS `ts_event_result` (
  `F_EventID` int NOT NULL,
  `F_EventResultNumber` int NOT NULL,
  `F_EventRank` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_EventPoints` int DEFAULT NULL,
  `F_MedalID` int DEFAULT NULL,
  `F_IRMID` int DEFAULT NULL,
  `F_EventPointsIntDes1` int DEFAULT NULL,
  `F_EventPointsIntDes2` int DEFAULT NULL,
  `F_EventPointsIntDes3` int DEFAULT NULL,
  `F_EventPointsIntDes4` int DEFAULT NULL,
  `F_EventPointsCharDes1` varchar(50) DEFAULT NULL,
  `F_EventPointsCharDes2` varchar(50) DEFAULT NULL,
  `F_EventPointsCharDes3` varchar(50) DEFAULT NULL,
  `F_EventPointsCharDes4` varchar(50) DEFAULT NULL,
  `F_EventDisplayPosition` int DEFAULT NULL,
  `F_MedalCreateDate` datetime DEFAULT NULL,
  `F_ResultCreateDate` datetime DEFAULT NULL,
  PRIMARY KEY (`F_EventID`,`F_EventResultNumber`),
  KEY `FK_TS_Event_Result_TC_IRM` (`F_IRMID`),
  KEY `FK_TS_Event_Result_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Event_Result_TC_IRM` FOREIGN KEY (`F_IRMID`) REFERENCES `tc_irm` (`f_irmid`),
  CONSTRAINT `FK_TS_Event_Result_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Event_Result_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_group_official 结构
CREATE TABLE IF NOT EXISTS `ts_group_official` (
  `F_OfficialGroupID` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  KEY `FK_TS_Group_Official_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Group_Official_TD_OfficialGroup_Des` (`F_OfficialGroupID`),
  KEY `FK_TS_Group_Official_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Group_Official_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Group_Official_TD_OfficialGroup_Des` FOREIGN KEY (`F_OfficialGroupID`) REFERENCES `td_officialgroup_des` (`f_officialgroupid`),
  CONSTRAINT `FK_TS_Group_Official_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match 结构
CREATE TABLE IF NOT EXISTS `ts_match` (
  `F_MatchID` int NOT NULL AUTO_INCREMENT,
  `F_PhaseID` int DEFAULT NULL,
  `F_MatchStatusID` int DEFAULT NULL,
  `F_VenueID` int DEFAULT NULL,
  `F_CourtID` int DEFAULT NULL,
  `F_WeatherID` int DEFAULT NULL,
  `F_MatchDate` datetime DEFAULT NULL,
  `F_StartTime` datetime DEFAULT NULL,
  `F_EndTime` datetime DEFAULT NULL,
  `F_SpendTime` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_MatchTypeID` int DEFAULT NULL,
  `F_MatchInfo` varchar(50) DEFAULT NULL,
  `F_MatchNum` int DEFAULT NULL,
  `F_MatchCode` varchar(20) DEFAULT NULL,
  `F_RaceNum` varchar(20) DEFAULT NULL,
  `F_SessionID` int DEFAULT NULL,
  `F_OrderInSession` int DEFAULT NULL,
  `F_RoundID` int DEFAULT NULL,
  `F_OrderInRound` int DEFAULT NULL,
  `F_CompetitionRuleID` int DEFAULT NULL,
  `F_MatchHasMedal` int DEFAULT NULL,
  `F_MatchComment1` varchar(50) DEFAULT NULL,
  `F_MatchComment2` varchar(50) DEFAULT NULL,
  `F_MatchComment3` varchar(50) DEFAULT NULL,
  `F_MatchComment4` varchar(50) DEFAULT NULL,
  `F_MatchComment5` varchar(50) DEFAULT NULL,
  `F_MatchComment6` varchar(50) DEFAULT NULL,
  `F_UsingModelID` int DEFAULT NULL,
  `F_DecisionID` int DEFAULT NULL,
  `F_MatchComment7` varchar(50) DEFAULT NULL,
  `F_MatchStatXml` text,
  PRIMARY KEY (`F_MatchID`),
  KEY `FK_TS_Match_TC_Decision` (`F_DecisionID`),
  KEY `FK_TS_Match_TC_Status` (`F_MatchStatusID`),
  KEY `FK_TS_Match_TS_Weather_Conditions` (`F_WeatherID`),
  CONSTRAINT `FK_TS_Match_TC_Decision` FOREIGN KEY (`F_DecisionID`) REFERENCES `tc_decision` (`f_decisionid`),
  CONSTRAINT `FK_TS_Match_TC_Status` FOREIGN KEY (`F_MatchStatusID`) REFERENCES `tc_status` (`f_statusid`),
  CONSTRAINT `FK_TS_Match_TS_Weather_Conditions` FOREIGN KEY (`F_WeatherID`) REFERENCES `ts_weather_conditions` (`F_WeatherID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_matchrank2phaserank 结构
CREATE TABLE IF NOT EXISTS `ts_matchrank2phaserank` (
  `F_MatchID` int NOT NULL,
  `F_MatchRank` int NOT NULL,
  `F_PhaseID` int NOT NULL,
  `F_PhaseRank` int NOT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchRank`,`F_PhaseID`,`F_PhaseRank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_matchtype 结构
CREATE TABLE IF NOT EXISTS `ts_matchtype` (
  `F_MatchTypeID` int NOT NULL,
  `F_MatchTypeName` varchar(100) DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_RunFullMatch` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_matchtype_des_te 结构
CREATE TABLE IF NOT EXISTS `ts_matchtype_des_te` (
  `F_MatchTypeID` int NOT NULL,
  `F_TeamMatchID` int NOT NULL,
  `F_SetID` int NOT NULL,
  `F_TieBreak` int DEFAULT NULL,
  `F_GamesEnd` int DEFAULT NULL,
  `F_Dec_TieBreak` int DEFAULT NULL,
  `F_TieBreak_Points` int DEFAULT NULL,
  `F_Advantage` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchTypeID`,`F_TeamMatchID`,`F_SetID`),
  CONSTRAINT `FK_TS_MatchType_Des_TE_TS_MatchType` FOREIGN KEY (`F_MatchTypeID`) REFERENCES `ts_matchtype` (`F_MatchTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_actionlist 结构
CREATE TABLE IF NOT EXISTS `ts_match_actionlist` (
  `F_ActionNumberID` int NOT NULL AUTO_INCREMENT,
  `F_CompetitionPosition` int DEFAULT NULL,
  `F_MatchID` int DEFAULT NULL,
  `F_MatchSplitID` int DEFAULT NULL,
  `F_ActionTypeID` int DEFAULT NULL,
  `F_ActionOrder` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_ActionHappenTime` datetime DEFAULT NULL,
  `F_ActionHappenTimeSpan` varchar(50) DEFAULT NULL,
  `F_ServerPosition` int DEFAULT NULL,
  `F_PointPosition` int DEFAULT NULL,
  `F_ScoreDes` varchar(50) DEFAULT NULL,
  `F_CriticalPointPosition` int DEFAULT NULL,
  `F_CriticalPoint` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `F_ActionXMLComment` text,
  `F_ActionDetail1` int DEFAULT NULL,
  `F_ActionDetail2` int DEFAULT NULL,
  `F_ActionDetail3` int DEFAULT NULL,
  `F_ActionDetail4` int DEFAULT NULL,
  `F_ActionDetail5` int DEFAULT NULL,
  `F_ActionDetail6` int DEFAULT NULL,
  `F_ActionDetail7` int DEFAULT NULL,
  `F_ActionDetail8` int DEFAULT NULL,
  PRIMARY KEY (`F_ActionNumberID`),
  KEY `FK_TS_Match_ActionList_TD_ActionType` (`F_ActionTypeID`),
  KEY `FK_TS_Match_ActionList_TR_Register` (`F_RegisterID`),
  KEY `FK_TS_Match_ActionList_TS_Match` (`F_MatchID`),
  CONSTRAINT `FK_TS_Match_ActionList_TD_ActionType` FOREIGN KEY (`F_ActionTypeID`) REFERENCES `td_actiontype` (`f_actiontypeid`),
  CONSTRAINT `FK_TS_Match_ActionList_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_ActionList_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_des 结构
CREATE TABLE IF NOT EXISTS `ts_match_des` (
  `F_MatchID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_MatchLongName` varchar(100) DEFAULT NULL,
  `F_MatchShortName` varchar(50) DEFAULT NULL,
  `F_MatchComment` varchar(100) DEFAULT NULL,
  `F_MatchComment2` varchar(100) DEFAULT NULL,
  `F_MatchComment3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_LanguageCode`),
  KEY `FK_TS_Match_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Des_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_member 结构
CREATE TABLE IF NOT EXISTS `ts_match_member` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_ShirtNumber` int DEFAULT NULL,
  `F_Active` int DEFAULT NULL,
  `F_StartUp` int DEFAULT NULL,
  `F_Comment` varchar(50) DEFAULT NULL,
  `F_MaxSrvSpeed` int DEFAULT NULL,
  `F_IRMID` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`,`F_RegisterID`),
  KEY `FK_TS_Match_Member_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Match_Member_TD_Position1` (`F_PositionID`),
  CONSTRAINT `FK_TS_Match_Member_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Match_Member_TD_Position1` FOREIGN KEY (`F_PositionID`) REFERENCES `td_position` (`f_positionid`),
  CONSTRAINT `FK_TS_Match_Member_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_model 结构
CREATE TABLE IF NOT EXISTS `ts_match_model` (
  `F_MatchID` int NOT NULL,
  `F_MatchModelID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_MatchModelName` varchar(100) DEFAULT NULL,
  `F_MatchModelComment` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchModelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_model_match_result 结构
CREATE TABLE IF NOT EXISTS `ts_match_model_match_result` (
  `F_MatchID` int NOT NULL,
  `F_MatchModelID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_CompetitionPositionDes1` int DEFAULT NULL,
  `F_CompetitionPositionDes2` int DEFAULT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_StartPhaseID` int DEFAULT NULL,
  `F_StartPhasePosition` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_HistoryMatchID` int DEFAULT NULL,
  `F_HistoryMatchRank` int DEFAULT NULL,
  `F_HistoryLevel` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchModelID`,`F_CompetitionPosition`),
  KEY `FK_TS_Match_Model_Match_Result_TS_Match_Result` (`F_MatchID`,`F_CompetitionPosition`),
  CONSTRAINT `FK_TS_Match_Model_Match_Result_TS_Match_Model` FOREIGN KEY (`F_MatchID`, `F_MatchModelID`) REFERENCES `ts_match_model` (`F_MatchID`, `F_MatchModelID`),
  CONSTRAINT `FK_TS_Match_Model_Match_Result_TS_Match_Result` FOREIGN KEY (`F_MatchID`, `F_CompetitionPosition`) REFERENCES `ts_match_result` (`F_MatchID`, `F_CompetitionPosition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_model_match_result_des 结构
CREATE TABLE IF NOT EXISTS `ts_match_model_match_result_des` (
  `F_MatchID` int NOT NULL,
  `F_MatchModelID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_CompetitorSourceDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressType` int DEFAULT NULL,
  `F_Comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchModelID`,`F_CompetitionPosition`,`F_LanguageCode`),
  KEY `FK_TS_Match_Model_Match_Result_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Model_Match_Result_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Model_Match_Result_Des_TS_Match_Model_Match_Result` FOREIGN KEY (`F_MatchID`, `F_MatchModelID`, `F_CompetitionPosition`) REFERENCES `ts_match_model_match_result` (`F_MatchID`, `F_MatchModelID`, `F_CompetitionPosition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_officialgroup 结构
CREATE TABLE IF NOT EXISTS `ts_match_officialgroup` (
  `F_OfficialGroupID` int DEFAULT NULL,
  `F_MatchID` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  KEY `FK_TS_Match_OfficialGroup_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Match_OfficialGroup_TD_OfficialGroup_Des` (`F_OfficialGroupID`),
  KEY `FK_TS_Match_OfficialGroup_TS_Match` (`F_MatchID`),
  CONSTRAINT `FK_TS_Match_OfficialGroup_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Match_OfficialGroup_TD_OfficialGroup_Des` FOREIGN KEY (`F_OfficialGroupID`) REFERENCES `td_officialgroup_des` (`f_officialgroupid`),
  CONSTRAINT `FK_TS_Match_OfficialGroup_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_result 结构
CREATE TABLE IF NOT EXISTS `ts_match_result` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_StartPhaseID` int DEFAULT NULL,
  `F_StartPhasePosition` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_HistoryMatchID` int DEFAULT NULL,
  `F_HistoryMatchRank` int DEFAULT NULL,
  `F_HistoryLevel` int DEFAULT NULL,
  `F_ResultID` int DEFAULT NULL,
  `F_Rank` int DEFAULT NULL,
  `F_DisplayPosition` int DEFAULT NULL,
  `F_Points` int DEFAULT NULL,
  `F_RealScore` int DEFAULT NULL,
  `F_IRMID` int DEFAULT NULL,
  `F_Service` int DEFAULT NULL,
  `F_UniformID` int DEFAULT NULL,
  `F_UniformID2` int DEFAULT NULL,
  `F_WinPoints` int DEFAULT NULL,
  `F_LosePoints` int DEFAULT NULL,
  `F_WinSets` int DEFAULT NULL,
  `F_DrawSets` int DEFAULT NULL,
  `F_LoseSets` int DEFAULT NULL,
  `F_WinSets_1` int DEFAULT NULL,
  `F_LoseSets_1` int DEFAULT NULL,
  `F_WinSets_2` int DEFAULT NULL,
  `F_LoseSets_2` int DEFAULT NULL,
  `F_CompetitionPositionDes1` int DEFAULT NULL,
  `F_CompetitionPositionDes2` int DEFAULT NULL,
  `F_PointsCharDes1` varchar(50) DEFAULT NULL,
  `F_PointsCharDes2` varchar(50) DEFAULT NULL,
  `F_PointsCharDes3` varchar(50) DEFAULT NULL,
  `F_PointsCharDes4` varchar(50) DEFAULT NULL,
  `F_PointsNumDes1` int DEFAULT NULL,
  `F_PointsNumDes2` int DEFAULT NULL,
  `F_PointsNumDes3` int DEFAULT NULL,
  `F_PointsNumDes4` int DEFAULT NULL,
  `F_StartTimeCharDes` varchar(50) DEFAULT NULL,
  `F_StartTimeNumDes` int DEFAULT NULL,
  `F_FinishTimeCharDes` varchar(50) DEFAULT NULL,
  `F_FinishTimeNumDes` int DEFAULT NULL,
  `F_Comment` varchar(100) DEFAULT NULL,
  `F_GroupPoints` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`),
  KEY `FK_TS_Match_Result_TC_IRM1` (`F_IRMID`),
  KEY `FK_TS_Match_Result_TC_Result` (`F_ResultID`),
  KEY `FK_TS_Match_Result_TR_Register` (`F_RegisterID`),
  KEY `FK_TS_Match_Result_TR_Uniform` (`F_UniformID`),
  KEY `FK_TS_Match_Result_TS_Match1` (`F_SourceMatchID`),
  KEY `FK_TS_Match_Result_TS_Phase` (`F_SourcePhaseID`),
  KEY `FK_TS_Match_Result_TS_Phase1` (`F_StartPhaseID`),
  CONSTRAINT `FK_TS_Match_Result_TC_IRM1` FOREIGN KEY (`F_IRMID`) REFERENCES `tc_irm` (`f_irmid`),
  CONSTRAINT `FK_TS_Match_Result_TC_Result` FOREIGN KEY (`F_ResultID`) REFERENCES `tc_result` (`f_resultid`),
  CONSTRAINT `FK_TS_Match_Result_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Result_TR_Uniform` FOREIGN KEY (`F_UniformID`) REFERENCES `tr_uniform` (`F_UniformID`),
  CONSTRAINT `FK_TS_Match_Result_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`),
  CONSTRAINT `FK_TS_Match_Result_TS_Match1` FOREIGN KEY (`F_SourceMatchID`) REFERENCES `ts_match` (`F_MatchID`),
  CONSTRAINT `FK_TS_Match_Result_TS_Phase` FOREIGN KEY (`F_SourcePhaseID`) REFERENCES `ts_phase` (`F_PhaseID`),
  CONSTRAINT `FK_TS_Match_Result_TS_Phase1` FOREIGN KEY (`F_StartPhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_result_des 结构
CREATE TABLE IF NOT EXISTS `ts_match_result_des` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_CompetitorSourceDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressType` int DEFAULT NULL,
  `F_Comment` varchar(100) DEFAULT NULL,
  `F_ProgressDes` varchar(100) DEFAULT NULL,
  `F_ProgressType` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`,`F_LanguageCode`),
  KEY `FK_TS_Match_Result_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Result_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Result_Des_TS_Match_Result` FOREIGN KEY (`F_MatchID`, `F_CompetitionPosition`) REFERENCES `ts_match_result` (`F_MatchID`, `F_CompetitionPosition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_servant 结构
CREATE TABLE IF NOT EXISTS `ts_match_servant` (
  `F_MatchID` int NOT NULL,
  `F_ServantNum` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_ServantNum`),
  KEY `FK_TS_Match_Servant_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Match_Servant_TD_Position` (`F_PositionID`),
  KEY `FK_TS_Match_Servant_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Servant_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Match_Servant_TD_Position` FOREIGN KEY (`F_PositionID`) REFERENCES `td_position` (`f_positionid`),
  CONSTRAINT `FK_TS_Match_Servant_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Servant_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_split_des 结构
CREATE TABLE IF NOT EXISTS `ts_match_split_des` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_MatchSplitShortName` varchar(50) DEFAULT NULL,
  `F_MatchSplitLongName` varchar(100) DEFAULT NULL,
  `F_MatchSplitComment1` varchar(100) DEFAULT NULL,
  `F_MatchSplitComment2` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`,`F_LanguageCode`),
  KEY `FK_TS_Match_Split_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Split_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Match_Split_Des_TS_Match_Split_Info` FOREIGN KEY (`F_MatchID`, `F_MatchSplitID`) REFERENCES `ts_match_split_info` (`F_MatchID`, `F_MatchSplitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_split_info 结构
CREATE TABLE IF NOT EXISTS `ts_match_split_info` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_FatherMatchSplitID` int DEFAULT NULL,
  `F_MatchSplitCode` varchar(20) DEFAULT NULL,
  `F_MatchSplitType` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_MatchSplitStatusID` int DEFAULT NULL,
  `F_StartTime` datetime DEFAULT NULL,
  `F_EndTime` datetime DEFAULT NULL,
  `F_SpendTime` int DEFAULT NULL,
  `F_Memo` varchar(50) DEFAULT NULL,
  `F_MatchSplitComment` varchar(100) DEFAULT NULL,
  `F_MatchSplitComment1` varchar(100) DEFAULT NULL,
  `F_MatchSplitComment2` varchar(100) DEFAULT NULL,
  `F_MatchSplitComment3` varchar(100) DEFAULT NULL,
  `F_MatchSplitPrecision` int DEFAULT NULL,
  `F_StartSplitID` int DEFAULT NULL,
  `F_EndSplitID` int DEFAULT NULL,
  `F_DecisionID` int DEFAULT NULL,
  `F_MatchStatXml` text,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`),
  KEY `FK_TS_Match_Split_Info_TC_Decision` (`F_DecisionID`),
  CONSTRAINT `FK_TS_Match_Split_Info_TC_Decision` FOREIGN KEY (`F_DecisionID`) REFERENCES `tc_decision` (`f_decisionid`),
  CONSTRAINT `FK_TS_Match_Split_Info_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_split_member 结构
CREATE TABLE IF NOT EXISTS `ts_match_split_member` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_ShirtNumber` int DEFAULT NULL,
  `F_Active` int DEFAULT NULL,
  `F_StartUp` int DEFAULT NULL,
  `F_Comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`,`F_CompetitionPosition`,`F_RegisterID`),
  KEY `FK_TS_Match_Split_Member_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Match_Split_Member_TD_Position1` (`F_PositionID`),
  CONSTRAINT `FK_TS_Match_Split_Member_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Match_Split_Member_TD_Position1` FOREIGN KEY (`F_PositionID`) REFERENCES `td_position` (`f_positionid`),
  CONSTRAINT `FK_TS_Match_Split_Member_TS_Match_Split_Info` FOREIGN KEY (`F_MatchID`, `F_MatchSplitID`) REFERENCES `ts_match_split_info` (`F_MatchID`, `F_MatchSplitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_split_result 结构
CREATE TABLE IF NOT EXISTS `ts_match_split_result` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_FatherMatchSplitID` int DEFAULT NULL,
  `F_ResultID` int DEFAULT NULL,
  `F_Points` int DEFAULT NULL,
  `F_PointsCharDes1` varchar(50) DEFAULT NULL,
  `F_PointsCharDes2` varchar(50) DEFAULT NULL,
  `F_PointsCharDes3` varchar(50) DEFAULT NULL,
  `F_PointsNumDes1` int DEFAULT NULL,
  `F_PointsNumDes2` int DEFAULT NULL,
  `F_PointsNumDes3` int DEFAULT NULL,
  `F_Rank` int DEFAULT NULL,
  `F_DisplayPosition` int DEFAULT NULL,
  `F_Service` int DEFAULT NULL,
  `F_IRMID` int DEFAULT NULL,
  `F_Comment` varchar(100) DEFAULT NULL,
  `F_SplitPoints` int DEFAULT NULL,
  `F_SplitPointsCharDes1` varchar(50) DEFAULT NULL,
  `F_SplitPointsCharDes2` varchar(50) DEFAULT NULL,
  `F_SplitPointsCharDes3` varchar(50) DEFAULT NULL,
  `F_SplitPointsNumDes1` int DEFAULT NULL,
  `F_SplitPointsNumDes2` int DEFAULT NULL,
  `F_SplitPointsNumDes3` int DEFAULT NULL,
  `F_SplitRank` int DEFAULT NULL,
  `F_SplitDisplayPosition` int DEFAULT NULL,
  `F_SplitInfo1` int DEFAULT NULL,
  `F_SplitInfo2` int DEFAULT NULL,
  `F_SplitInfo3` int DEFAULT NULL,
  `F_Comment1` int DEFAULT NULL,
  `F_Comment2` int DEFAULT NULL,
  `F_Pt1` int DEFAULT NULL,
  `F_Pt2` int DEFAULT NULL,
  `F_Pt3` int DEFAULT NULL,
  `F_C1W` int DEFAULT NULL,
  `F_C1K` int DEFAULT NULL,
  `F_C1HC` int DEFAULT NULL,
  `F_C1H` int DEFAULT NULL,
  `F_C2W` int DEFAULT NULL,
  `F_C2K` int DEFAULT NULL,
  `F_C2HC` int DEFAULT NULL,
  `F_C2H` int DEFAULT NULL,
  `F_RealScore` varchar(50) DEFAULT NULL,
  `F_Memo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`,`F_CompetitionPosition`),
  KEY `FK_TS_Match_Split_Result_TC_IRM1` (`F_IRMID`),
  KEY `FK_TS_Match_Split_Result_TC_Result` (`F_ResultID`),
  KEY `FK_TS_Match_Split_Result_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Split_Result_TC_IRM1` FOREIGN KEY (`F_IRMID`) REFERENCES `tc_irm` (`f_irmid`),
  CONSTRAINT `FK_TS_Match_Split_Result_TC_Result` FOREIGN KEY (`F_ResultID`) REFERENCES `tc_result` (`f_resultid`),
  CONSTRAINT `FK_TS_Match_Split_Result_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Split_Result_TS_Match_Split_Info` FOREIGN KEY (`F_MatchID`, `F_MatchSplitID`) REFERENCES `ts_match_split_info` (`F_MatchID`, `F_MatchSplitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_split_servant 结构
CREATE TABLE IF NOT EXISTS `ts_match_split_servant` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_ServantNum` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_PositionID` int DEFAULT NULL,
  `F_FunctionID` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`,`F_ServantNum`),
  KEY `FK_TS_Match_Split_Servant_TD_Function` (`F_FunctionID`),
  KEY `FK_TS_Match_Split_Servant_TD_Position` (`F_PositionID`),
  KEY `FK_TS_Match_Split_Servant_TR_Register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Split_Servant_TD_Function` FOREIGN KEY (`F_FunctionID`) REFERENCES `td_function` (`f_functionid`),
  CONSTRAINT `FK_TS_Match_Split_Servant_TD_Position` FOREIGN KEY (`F_PositionID`) REFERENCES `td_position` (`f_positionid`),
  CONSTRAINT `FK_TS_Match_Split_Servant_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Match_Split_Servant_TS_Match_Split_Info` FOREIGN KEY (`F_MatchID`, `F_MatchSplitID`) REFERENCES `ts_match_split_info` (`F_MatchID`, `F_MatchSplitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_match_statistic 结构
CREATE TABLE IF NOT EXISTS `ts_match_statistic` (
  `F_MatchID` int NOT NULL,
  `F_MatchSplitID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  `F_StatisticID` int NOT NULL,
  `F_StatisticValue` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_MatchSplitID`,`F_CompetitionPosition`,`F_RegisterID`,`F_StatisticID`),
  KEY `FK_TS_Match_Statistic_TD_Statistic` (`F_StatisticID`),
  CONSTRAINT `FK_TS_Match_Statistic_TD_Statistic` FOREIGN KEY (`F_StatisticID`) REFERENCES `td_statistic` (`f_statisticid`),
  CONSTRAINT `FK_TS_Match_Statistic_TS_Match` FOREIGN KEY (`F_MatchID`) REFERENCES `ts_match` (`F_MatchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_offical_communication 结构
CREATE TABLE IF NOT EXISTS `ts_offical_communication` (
  `F_NewsID` int NOT NULL AUTO_INCREMENT,
  `F_DisciplineID` int DEFAULT NULL,
  `F_NewsItem` varchar(20) DEFAULT NULL,
  `F_SubTitle` varchar(100) DEFAULT NULL,
  `F_Heading` varchar(100) DEFAULT NULL,
  `F_Text` text,
  `F_Issued_by` varchar(100) DEFAULT NULL,
  `F_Type` int DEFAULT NULL,
  `F_Date` datetime DEFAULT NULL,
  `F_Note` text,
  `F_ReportTitle` varchar(100) DEFAULT NULL,
  `F_Summary` text,
  `F_Details` text,
  PRIMARY KEY (`F_NewsID`),
  KEY `FK_TS_Offical_Communication_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_Offical_Communication_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_oldevent_position 结构
CREATE TABLE IF NOT EXISTS `ts_oldevent_position` (
  `F_ItemID` int NOT NULL AUTO_INCREMENT,
  `F_EventID` int DEFAULT NULL,
  `F_EventPosition` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  PRIMARY KEY (`F_ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_oldphase_position 结构
CREATE TABLE IF NOT EXISTS `ts_oldphase_position` (
  `F_ItemID` int NOT NULL AUTO_INCREMENT,
  `F_PhaseID` int DEFAULT NULL,
  `F_PhasePosition` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  PRIMARY KEY (`F_ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase 结构
CREATE TABLE IF NOT EXISTS `ts_phase` (
  `F_PhaseID` int NOT NULL AUTO_INCREMENT,
  `F_EventID` int DEFAULT NULL,
  `F_FatherPhaseID` int DEFAULT NULL,
  `F_PhaseCode` varchar(10) DEFAULT NULL,
  `F_OpenDate` datetime DEFAULT NULL,
  `F_CloseDate` datetime DEFAULT NULL,
  `F_PhaseStatusID` int DEFAULT NULL,
  `F_PhaseNodeType` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_PhaseType` int DEFAULT NULL,
  `F_PhaseSize` int DEFAULT NULL,
  `F_PhaseRankSize` int DEFAULT NULL,
  `F_PhaseIsQual` int DEFAULT NULL,
  `F_PhaseInfo` varchar(50) DEFAULT NULL,
  `F_PhaseIsPool` int DEFAULT NULL,
  `F_PhaseHasPools` int DEFAULT NULL,
  `F_UsingModelID` int DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`),
  KEY `FK_TS_Phase_TC_Phase_Status` (`F_PhaseStatusID`),
  KEY `FK_TS_Phase_TS_Event` (`F_EventID`),
  CONSTRAINT `FK_TS_Phase_TC_Phase_Status` FOREIGN KEY (`F_PhaseStatusID`) REFERENCES `tc_phase_status` (`f_statusid`),
  CONSTRAINT `FK_TS_Phase_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phaserank2eventrank 结构
CREATE TABLE IF NOT EXISTS `ts_phaserank2eventrank` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseRank` int NOT NULL,
  `F_EventID` int NOT NULL,
  `F_EventRank` int NOT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseRank`,`F_EventID`,`F_EventRank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_competitors 结构
CREATE TABLE IF NOT EXISTS `ts_phase_competitors` (
  `F_PhaseID` int NOT NULL,
  `F_RegisterID` int NOT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_RegisterID`),
  CONSTRAINT `FK_TS_Phase_Competitors_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_des 结构
CREATE TABLE IF NOT EXISTS `ts_phase_des` (
  `F_PhaseID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_PhaseLongName` varchar(100) DEFAULT NULL,
  `F_PhaseShortName` varchar(50) DEFAULT NULL,
  `F_PhaseComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_LanguageCode`),
  KEY `FK_TS_Phase_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Phase_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Phase_Des_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_matchpoint 结构
CREATE TABLE IF NOT EXISTS `ts_phase_matchpoint` (
  `F_PhaseID` int NOT NULL,
  `F_WonMatchPoint` int DEFAULT NULL,
  `F_DrawMatchPoint` int DEFAULT NULL,
  `F_LostMatchPoint` int DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`),
  CONSTRAINT `FK_TS_Phase_MatchPoint_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_model 结构
CREATE TABLE IF NOT EXISTS `ts_phase_model` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseModelID` int NOT NULL,
  `F_Order` int DEFAULT NULL,
  `F_PhaseModelName` varchar(100) DEFAULT NULL,
  `F_PhaseModelComment` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseModelID`),
  CONSTRAINT `FK_TS_Phase_Model_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_model_match_result 结构
CREATE TABLE IF NOT EXISTS `ts_phase_model_match_result` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseModelID` int NOT NULL,
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_CompetitionPositionDes1` int DEFAULT NULL,
  `F_CompetitionPositionDes2` int DEFAULT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_StartPhaseID` int DEFAULT NULL,
  `F_StartPhasePosition` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_HistoryMatchID` int DEFAULT NULL,
  `F_HistoryMatchRank` int DEFAULT NULL,
  `F_HistoryLevel` int DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseModelID`,`F_MatchID`,`F_CompetitionPosition`),
  KEY `FK_TS_Phase_Model_Match_Result_TS_Match_Result` (`F_MatchID`,`F_CompetitionPosition`),
  CONSTRAINT `FK_TS_Phase_Model_Match_Result_TS_Match_Result` FOREIGN KEY (`F_MatchID`, `F_CompetitionPosition`) REFERENCES `ts_match_result` (`F_MatchID`, `F_CompetitionPosition`),
  CONSTRAINT `FK_TS_Phase_Model_Match_Result_TS_Phase_Model` FOREIGN KEY (`F_PhaseID`, `F_PhaseModelID`) REFERENCES `ts_phase_model` (`F_PhaseID`, `F_PhaseModelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_model_match_result_des 结构
CREATE TABLE IF NOT EXISTS `ts_phase_model_match_result_des` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseModelID` int NOT NULL,
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_CompetitorSourceDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressDes` varchar(100) DEFAULT NULL,
  `F_SouceProgressType` int DEFAULT NULL,
  `F_Comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseModelID`,`F_MatchID`,`F_CompetitionPosition`,`F_LanguageCode`),
  KEY `FK_TS_Phase_Model_Match_Result_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Phase_Model_Match_Result_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Phase_Model_Match_Result_Des_TS_Phase_Model_Match_Result` FOREIGN KEY (`F_PhaseID`, `F_PhaseModelID`, `F_MatchID`, `F_CompetitionPosition`) REFERENCES `ts_phase_model_match_result` (`F_PhaseID`, `F_PhaseModelID`, `F_MatchID`, `F_CompetitionPosition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_model_phase_position 结构
CREATE TABLE IF NOT EXISTS `ts_phase_model_phase_position` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseModelID` int NOT NULL,
  `F_PhasePosition` int NOT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_StartPhaseID` int DEFAULT NULL,
  `F_StartPhasePosition` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseModelID`,`F_PhasePosition`),
  CONSTRAINT `FK_TS_Phase_Model_Phase_Position_TS_Phase_Model` FOREIGN KEY (`F_PhaseID`, `F_PhaseModelID`) REFERENCES `ts_phase_model` (`F_PhaseID`, `F_PhaseModelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_model_phase_result 结构
CREATE TABLE IF NOT EXISTS `ts_phase_model_phase_result` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseModelID` int NOT NULL,
  `F_PhaseResultNumber` int NOT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseModelID`,`F_PhaseResultNumber`),
  KEY `FK_TS_Phase_Model_Phase_Resut_TS_Phase_Result` (`F_PhaseID`,`F_PhaseResultNumber`),
  CONSTRAINT `FK_TS_Phase_Model_Phase_Resut_TS_Phase_Model` FOREIGN KEY (`F_PhaseID`, `F_PhaseModelID`) REFERENCES `ts_phase_model` (`F_PhaseID`, `F_PhaseModelID`),
  CONSTRAINT `FK_TS_Phase_Model_Phase_Resut_TS_Phase_Result` FOREIGN KEY (`F_PhaseID`, `F_PhaseResultNumber`) REFERENCES `ts_phase_result` (`F_PhaseID`, `F_PhaseResultNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_position 结构
CREATE TABLE IF NOT EXISTS `ts_phase_position` (
  `F_ItemID` int NOT NULL AUTO_INCREMENT,
  `F_PhaseID` int DEFAULT NULL,
  `F_PhasePosition` int DEFAULT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_StartPhaseID` int DEFAULT NULL,
  `F_StartPhasePosition` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  PRIMARY KEY (`F_ItemID`),
  KEY `FK_TS_Phase_Position_TS_Phase` (`F_PhaseID`),
  CONSTRAINT `FK_TS_Phase_Position_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_phase_result 结构
CREATE TABLE IF NOT EXISTS `ts_phase_result` (
  `F_PhaseID` int NOT NULL,
  `F_PhaseResultNumber` int NOT NULL,
  `F_PhaseRank` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_SourceType` int DEFAULT NULL,
  `F_SourcePhaseID` int DEFAULT NULL,
  `F_SourcePhaseRank` int DEFAULT NULL,
  `F_SourceMatchID` int DEFAULT NULL,
  `F_SourceMatchRank` int DEFAULT NULL,
  `F_PhasePoints` int DEFAULT NULL,
  `F_PhaseDisplayPosition` int DEFAULT NULL,
  `F_PhasePointsIntDes1` int DEFAULT NULL,
  `F_PhasePointsIntDes2` int DEFAULT NULL,
  `F_PhasePointsIntDes3` int DEFAULT NULL,
  `F_PhasePointsIntDes4` int DEFAULT NULL,
  `F_PhasePointsCharDes1` varchar(50) DEFAULT NULL,
  `F_PhasePointsCharDes2` varchar(50) DEFAULT NULL,
  `F_PhasePointsCharDes3` varchar(50) DEFAULT NULL,
  `F_PhasePointsCharDes4` varchar(50) DEFAULT NULL,
  `F_IRMID` int DEFAULT NULL,
  `F_PhaseComment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_PhaseID`,`F_PhaseResultNumber`),
  KEY `FK_TS_Phase_Result_TC_IRM` (`F_IRMID`),
  KEY `FK_TS_Phase_Result_TR_Register` (`F_RegisterID`),
  KEY `FK_TS_Phase_Result_TS_Phase1` (`F_SourcePhaseID`),
  CONSTRAINT `FK_TS_Phase_Result_TC_IRM` FOREIGN KEY (`F_IRMID`) REFERENCES `tc_irm` (`f_irmid`),
  CONSTRAINT `FK_TS_Phase_Result_TR_Register` FOREIGN KEY (`F_RegisterID`) REFERENCES `tr_register` (`F_RegisterID`),
  CONSTRAINT `FK_TS_Phase_Result_TS_Phase` FOREIGN KEY (`F_PhaseID`) REFERENCES `ts_phase` (`F_PhaseID`),
  CONSTRAINT `FK_TS_Phase_Result_TS_Phase1` FOREIGN KEY (`F_SourcePhaseID`) REFERENCES `ts_phase` (`F_PhaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_record_member 结构
CREATE TABLE IF NOT EXISTS `ts_record_member` (
  `F_RecordID` int NOT NULL,
  `F_MemberNum` int NOT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_RegisterCode` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `F_FamilyName` varchar(50) DEFAULT NULL,
  `F_GivenName` varchar(50) DEFAULT NULL,
  `F_NOC` char(3) DEFAULT NULL,
  `F_Gender` varchar(50) DEFAULT NULL,
  `F_Birth_Date` datetime DEFAULT NULL,
  `F_PositionCode` varchar(50) DEFAULT NULL,
  `F_CompetitorReportingName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RecordID`,`F_MemberNum`),
  CONSTRAINT `FK_TS_Record_Member_TS_Event_Record` FOREIGN KEY (`F_RecordID`) REFERENCES `ts_event_record` (`F_RecordID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_record_values 结构
CREATE TABLE IF NOT EXISTS `ts_record_values` (
  `F_RecordID` int NOT NULL,
  `F_ValueNum` int NOT NULL,
  `F_ValueType` varchar(50) DEFAULT NULL,
  `F_IntValue1` int DEFAULT NULL,
  `F_IntValue2` int DEFAULT NULL,
  `F_CharValue1` varchar(50) DEFAULT NULL,
  `F_CharValue2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RecordID`,`F_ValueNum`),
  CONSTRAINT `FK_TS_Record_Values_TS_Event_Record` FOREIGN KEY (`F_RecordID`) REFERENCES `ts_event_record` (`F_RecordID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_result_record 结构
CREATE TABLE IF NOT EXISTS `ts_result_record` (
  `F_MatchID` int NOT NULL,
  `F_CompetitionPosition` int NOT NULL,
  `F_RecordID` int NOT NULL,
  `F_NewRecordID` int DEFAULT NULL,
  `F_RegisterID` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_RecordDate` datetime DEFAULT NULL,
  `F_RecordTime` datetime DEFAULT NULL,
  `F_Equalled` int DEFAULT NULL,
  `F_SubEventCode` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_MatchID`,`F_CompetitionPosition`,`F_RecordID`),
  KEY `FK_TS_Result_Record_TS_Event_Record` (`F_RecordID`),
  CONSTRAINT `FK_TS_Result_Record_TS_Event_Record` FOREIGN KEY (`F_RecordID`) REFERENCES `ts_event_record` (`F_RecordID`),
  CONSTRAINT `FK_TS_Result_Record_TS_Match_Result` FOREIGN KEY (`F_MatchID`, `F_CompetitionPosition`) REFERENCES `ts_match_result` (`F_MatchID`, `F_CompetitionPosition`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_round 结构
CREATE TABLE IF NOT EXISTS `ts_round` (
  `F_RoundID` int NOT NULL AUTO_INCREMENT,
  `F_EventID` int DEFAULT NULL,
  `F_Order` int DEFAULT NULL,
  `F_RoundCode` varchar(20) DEFAULT NULL,
  `F_Comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_RoundID`),
  KEY `FK_TS_Round_TS_Event` (`F_EventID`),
  CONSTRAINT `FK_TS_Round_TS_Event` FOREIGN KEY (`F_EventID`) REFERENCES `ts_event` (`F_EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_round_des 结构
CREATE TABLE IF NOT EXISTS `ts_round_des` (
  `F_RoundID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_RoundLongName` varchar(100) DEFAULT NULL,
  `F_RoundShortName` varchar(50) DEFAULT NULL,
  `F_RoundComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_RoundID`,`F_LanguageCode`),
  KEY `FK_TS_Round_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Round_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Round_Des_TS_Round` FOREIGN KEY (`F_RoundID`) REFERENCES `ts_round` (`F_RoundID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_session 结构
CREATE TABLE IF NOT EXISTS `ts_session` (
  `F_SessionID` int NOT NULL AUTO_INCREMENT,
  `F_DisciplineID` int DEFAULT NULL,
  `F_SessionDate` datetime DEFAULT NULL,
  `F_SessionNumber` int DEFAULT NULL,
  `F_SessionTime` datetime DEFAULT NULL,
  `F_SessionEndTime` datetime DEFAULT NULL,
  `F_SessionTypeID` int DEFAULT NULL,
  PRIMARY KEY (`F_SessionID`),
  KEY `FK_TS_Session_TC_SessionType` (`F_SessionTypeID`),
  KEY `FK_TS_Session_TS_Discipline` (`F_DisciplineID`),
  CONSTRAINT `FK_TS_Session_TC_SessionType` FOREIGN KEY (`F_SessionTypeID`) REFERENCES `tc_sessiontype` (`f_sessiontypeid`),
  CONSTRAINT `FK_TS_Session_TS_Discipline` FOREIGN KEY (`F_DisciplineID`) REFERENCES `ts_discipline` (`f_disciplineid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_sport 结构
CREATE TABLE IF NOT EXISTS `ts_sport` (
  `f_sportid` int NOT NULL AUTO_INCREMENT,
  `f_sportcode` varchar(50) DEFAULT NULL,
  `f_opendate` datetime DEFAULT NULL,
  `f_closedate` datetime DEFAULT NULL,
  `f_order` int DEFAULT NULL,
  `f_sportinfo` varchar(50) DEFAULT NULL,
  `f_active` int DEFAULT NULL,
  PRIMARY KEY (`f_sportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_sport_config 结构
CREATE TABLE IF NOT EXISTS `ts_sport_config` (
  `F_SportID` int NOT NULL,
  `F_ConfigType` int NOT NULL,
  `F_ConfigName` varchar(50) DEFAULT NULL,
  `F_ConfigValue` int DEFAULT NULL,
  `F_ConfigValueDes` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_SportID`,`F_ConfigType`),
  CONSTRAINT `FK_TS_Sport_Config_TS_Sport` FOREIGN KEY (`F_SportID`) REFERENCES `ts_sport` (`f_sportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_sport_des 结构
CREATE TABLE IF NOT EXISTS `ts_sport_des` (
  `F_SportID` int NOT NULL,
  `F_LanguageCode` char(3) NOT NULL,
  `F_SportLongName` varchar(100) DEFAULT NULL,
  `F_SportShortName` varchar(50) DEFAULT NULL,
  `F_SportComment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`F_SportID`,`F_LanguageCode`),
  KEY `FK_TS_Sport_Des_TC_Language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Sport_Des_TC_Language` FOREIGN KEY (`F_LanguageCode`) REFERENCES `tc_language` (`F_LanguageCode`),
  CONSTRAINT `FK_TS_Sport_Des_TS_Sport` FOREIGN KEY (`F_SportID`) REFERENCES `ts_sport` (`f_sportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

-- 导出  表 eq.ts_weather_conditions 结构
CREATE TABLE IF NOT EXISTS `ts_weather_conditions` (
  `F_WeatherID` int NOT NULL AUTO_INCREMENT,
  `F_CurrentDate` datetime DEFAULT NULL,
  `F_WeatherNumber` int DEFAULT NULL,
  `F_CurrentTime` datetime DEFAULT NULL,
  `F_VenueID` int DEFAULT NULL,
  `F_Air_Temperature` varchar(25) DEFAULT NULL,
  `F_Water_Temperature` varchar(25) DEFAULT NULL,
  `F_Snow_Temperature` varchar(25) DEFAULT NULL,
  `F_Humidity` varchar(25) DEFAULT NULL,
  `F_Wind_Speed` varchar(25) DEFAULT NULL,
  `F_Wind_Speed1` varchar(25) DEFAULT NULL,
  `F_Bar_Pressure` varchar(25) DEFAULT NULL,
  `F_WeatherTypeID` int DEFAULT NULL,
  `F_WindDirectionID` int DEFAULT NULL,
  `F_Weather_Des` varchar(50) DEFAULT NULL,
  `F_WindDirection_Des` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`F_WeatherID`),
  KEY `FK_TS_Weather_Conditions_TC_WeatherType` (`F_WeatherTypeID`),
  KEY `FK_TS_Weather_Conditions_TC_WindDirection` (`F_WindDirectionID`),
  CONSTRAINT `FK_TS_Weather_Conditions_TC_WeatherType` FOREIGN KEY (`F_WeatherTypeID`) REFERENCES `tc_weathertype` (`f_weathertypeid`),
  CONSTRAINT `FK_TS_Weather_Conditions_TC_WindDirection` FOREIGN KEY (`F_WindDirectionID`) REFERENCES `tc_winddirection` (`f_winddirectionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 数据导出被取消选择。

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
