USE [BJ_EQ]
GO

/****** Object:  User [ovr]    Script Date: 08/07/2020 22:46:49 ******/
GO

CREATE USER [ovr] WITHOUT LOGIN WITH DEFAULT_SCHEMA=[dbo]
GO

