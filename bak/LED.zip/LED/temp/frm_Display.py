import sys
import json
from func_json import *
from cls_loadModule import *
from cls_database import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from frm_top_code import cod_top
from frm_bottom_code import cod_bottom

class frm_display(object):
	def setupUi(self, Form):
		sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
		Form.setSizePolicy(sizePolicy)
		self.horizontalLayout = QtWidgets.QHBoxLayout(Form)
		self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
		self.horizontalLayout.setObjectName("horizontalLayout")
		self.gridLayout = QtWidgets.QGridLayout()
		self.gridLayout.setSpacing(0)
		self.gridLayout.setObjectName("gridLayout")
		self.load_config()
		self.horizontalLayout.addLayout(self.gridLayout)


		self.retranslateUi(Form)
		QtCore.QMetaObject.connectSlotsByName(Form)

	def retranslateUi(self, Form):
		_translate = QtCore.QCoreApplication.translate
		Form.setWindowTitle(_translate("Form", "Form"))


	def load_config(self):
		path="./initialize/confige.ini"
		args = read_file(path)
		self.modulepath = args['modulepath']
		self.x = int(args['x'])
		self.y =  int(args['y'])
		self.width =  int(args['width'])
		self.height =  int(args['height'])
		self.setStyleSheet(args['stylesheet'])
		self.udp_ip = args['udp_ip']
		self.udp_port = args['udp_port']
		self.pic_path = args['pic_path']


		# 加入页眉和页脚
		self.gridLayout.addWidget(cod_top(""), 0, 0)
		self.gridLayout.addWidget(cod_bottom(""), 2, 0)

class cod_display(QWidget,frm_display):
	"""docstring for cod_display"""
	def __init__(self, arg):
		super(cod_display, self).__init__()
		self.path = ''
		self.arg = arg
		self.setupUi(self)
		self.tempform = QWidget
		self.setWindowFlags(Qt.FramelessWindowHint)


	def paintEvent(self,event):
		# self.move(0,0)#窗体定位
		# self.resize(1024,768) 
		self.move(self.x,self.y)#窗体定位
		self.resize(self.width,self.height) 
		# '''设置窗体背景'''
		# palette = QPalette()
		# palette.setColor(QPalette.Background, QColor(0x00,0xff,0x00,0x00))
		# self.setPalette(palette)
		# '''设置窗体图片'''
		# if (self.path == '') : return
		painter = QPainter(self)
		pixmap = QPixmap(self.pic_path)
		painter.drawPixmap(self.rect(),pixmap)

	def closeEvent(self,event):
		pass

	def keyPressEvent(self,event):
		'''退出窗体快捷键escape'''
		self.key = ""
		if (type(self.tempform)==QWidget): self.tempform.clear
		if event.key() == Qt.Key_Escape:
			self.close()
			self.arg.show()

		elif event.key() == Qt.Key_Left:

			# if (isinstance(QWidget,self.tempform) ==False) : 
			self.tempform = schedule()
			self.gridLayout.addWidget(self.tempform, 1, 0)

			# else :
			# 	self.tempform.show()
			# self.setCentralWidget(schedule())

		elif event.key() == Qt.Key_Right:
			self.tempform = judge()
			self.gridLayout.addWidget(self.tempform, 1, 0)

		elif event.key() == Qt.Key_Up:
			self.tempform = schedule()
			self.gridLayout.addWidget(self.tempform, 1, 0)

		elif event.key() == Qt.Key_Down:
			self.c = cc()
			self.gridLayout.addWidget(self.c, 1, 0)

			# self.setCentralWidget(team_c())



if __name__ == '__main__':
	app = QApplication(sys.argv)
	example = cod_display("hello")
	example.show()
	sys.exit(app.exec_())