import json
import re
# print(json.dumps({'4': 5, '6': 7}, sort_keys=True, indent=4))
data2={} #存放读取的数据

# f = open("../initialize/confige.ini",'r')
# args = f.read()
data = { 'a' : 1, 'b' : 2, 'c' : 3, 'd' : 4, 'e' : 5 } 

# data2 = json.dumps({'a': 'Runoob', 'b': 7}, sort_keys=True, indent=4, separators=(',', ': '))
data2 = json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))
print(data2)
data = json.loads(data2)
print(data)
# print(data2[0])
print(data['a'])