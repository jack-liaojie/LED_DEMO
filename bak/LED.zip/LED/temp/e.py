import json
import sys


args = {
	"top":
			{
			"left_path":"./resource/sward.jpg",
			"right_path":"./resource/sward.jpg",
			"title":"盛装舞步预赛"
			},
	"center":
			{
		    "height": "1080",
		    "modulepath": "./initialize/confige.ini",
		    "pic_path": "E:/2020EQ/CODE/LED/resource/sward.jpg",
		    "stylesheet": "font-size:24pt;background-color:rgb(255, 0,0);",
		    "udp_ip": "127.0.0.1",
		    "udp_port": "8080",
		    "width": "1920",
		    "x": "0",
		    "y": "0"
			},
	"bottom":
			{
			"left_path":"./resource/sward.jpg",
			"right_path":"./resource/sward.jpg",
			"title":"盛装舞步预赛"
			}
}

args =	{
"judge" :{"title":"盛装舞步预赛"},
"content":
	[ 
		{"judge":"主裁判","name" : "吉喆","city":"山东"},
		{"judge":"裁判员","name":"廖杰","city":"北戴河"},
		{"judge":"裁判员","name":"廖杰","city":"北戴河"},
		{"judge":"E","name":"廖杰","city":"北戴河"},
		{"judge":"M","name":"廖杰","city":"北戴河"},
		{"judge":"C","name":"廖杰","city":"北戴河"}
	]
}
a = args.keys()


print(list(a)[0])

# print(args["center"]["height"])

# print(args['startlist'])
# print(args['startlist']['title'])
# print(args['content'][0]['order'])
# print(args['content'][0]['name'])
# print(args['content'][0]['horse'])
# print(args['content'][0]['city'])


# for x in range(0,len(args["content"])):
# 	print(args['content'][x]['order'])
# 	print(args['content'][x]['name'])
# 	print(args['content'][x]['horse'])
# 	print(args['content'][x]['city'])
	