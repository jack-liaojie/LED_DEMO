# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\2020EQ\CODE\LED\temp\ui\maintitlebar.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!

import sys
from PyQt5.QtWidgets import QWidget,QApplication,QLabel,QSizePolicy

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainTitleBar(object):
    def setupUi(self, MainTitleBar):
        MainTitleBar.setObjectName("MainTitleBar")
        MainTitleBar.resize(688, 45)
        MainTitleBar.setStyleSheet("")
        self.verticalLayout = QtWidgets.QVBoxLayout(MainTitleBar)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.frameBorder = QtWidgets.QFrame(MainTitleBar)
        self.frameBorder.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frameBorder.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frameBorder.setObjectName("frameBorder")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.frameBorder)
        self.horizontalLayout.setContentsMargins(9, 9, 9, 9)
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.labelTitleName = QtWidgets.QLabel(self.frameBorder)
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.labelTitleName.setFont(font)
        self.labelTitleName.setScaledContents(True)
        self.labelTitleName.setObjectName("labelTitleName")
        self.horizontalLayout.addWidget(self.labelTitleName)
        self.labelImage = QtWidgets.QLabel(self.frameBorder)
        self.labelImage.setMinimumSize(QtCore.QSize(25, 25))
        self.labelImage.setMaximumSize(QtCore.QSize(25, 25))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.labelImage.setFont(font)
        self.labelImage.setText("")
        self.labelImage.setPixmap(QtGui.QPixmap(":/res/res/image/image.png"))
        self.labelImage.setScaledContents(True)
        self.labelImage.setObjectName("labelImage")
        self.horizontalLayout.addWidget(self.labelImage)
        spacerItem = QtWidgets.QSpacerItem(492, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButtonMin = QtWidgets.QPushButton(self.frameBorder)
        self.pushButtonMin.setMinimumSize(QtCore.QSize(25, 4))
        self.pushButtonMin.setMaximumSize(QtCore.QSize(25, 4))
        font = QtGui.QFont()
        font.setPointSize(6)
        self.pushButtonMin.setFont(font)
        self.pushButtonMin.setStyleSheet("")
        self.pushButtonMin.setText("")
        self.pushButtonMin.setObjectName("pushButtonMin")
        self.horizontalLayout.addWidget(self.pushButtonMin)
        self.pushButtonNormalMax = QtWidgets.QPushButton(self.frameBorder)
        self.pushButtonNormalMax.setMinimumSize(QtCore.QSize(20, 20))
        self.pushButtonNormalMax.setMaximumSize(QtCore.QSize(20, 20))
        font = QtGui.QFont()
        font.setPointSize(6)
        self.pushButtonNormalMax.setFont(font)
        self.pushButtonNormalMax.setStyleSheet("")
        self.pushButtonNormalMax.setText("")
        self.pushButtonNormalMax.setObjectName("pushButtonNormalMax")
        self.horizontalLayout.addWidget(self.pushButtonNormalMax)
        self.pushButtonClose = QtWidgets.QPushButton(self.frameBorder)
        self.pushButtonClose.setMinimumSize(QtCore.QSize(20, 20))
        self.pushButtonClose.setMaximumSize(QtCore.QSize(20, 20))
        self.pushButtonClose.setText("")
        self.pushButtonClose.setObjectName("pushButtonClose")
        self.horizontalLayout.addWidget(self.pushButtonClose)
        self.verticalLayout.addWidget(self.frameBorder)

        self.retranslateUi(MainTitleBar)
        QtCore.QMetaObject.connectSlotsByName(MainTitleBar)

    def retranslateUi(self, MainTitleBar):
        _translate = QtCore.QCoreApplication.translate
        MainTitleBar.setWindowTitle(_translate("MainTitleBar", "Form"))
        self.labelTitleName.setText(_translate("MainTitleBar", "QCoolPage"))
# import res_rc

class code_Display(QWidget,Ui_MainTitleBar):
  """docstring for code_Display"""
  def __init__(self):
    super(code_Display, self).__init__()
    self.setupUi(self)

if __name__ == '__main__':
  app = QApplication(sys.argv)
  example = code_Display()
  example.show()
  sys.exit(app.exec_())