import json

def read_file(path):
	f = open(path,'r')
	data = f.read()
	args = json.loads(data)#将文件中的字符串转换为dict对象
	f.close()
	return args #返回dict对象

def write_file(path,args):
	f = open(path,'w')
	data = json.dumps(args, sort_keys=True, indent=4, separators=(',', ': '))#dict对象转换成格式化字符串
	f.write(data)#写入文件中
	f.close()
	return data 

def str_to_dict(args):
	args = eval(args)
	return args #返回字典类型

def dict_to_str(args):
	return str(args)


if __name__ == '__main__':
	# main()

	args = {
		'7':{'name':'eq','code': 'mod','data':'f_language','property':""},
		'1':{'name':'language','code':'chn','data':'f_language','property':'chn'}, 
 		'2':{'name':'modul_path','code': 'path','data':'f_language','property':'d:/workstudio/'}, 
 		'3':{'name':'rolling_udp','code': 'udp','data':'f_language','property':{'port': '8080', 'ip': '127.0.0.1'}},
 		'4':{'name':'database','code':'db','data':'','property': ""},
 		'5':{'name':'window','code':'led', 'data':'','property': "top:100px;left:300px;width:1024pt;height:768pt;border:2pxsolidgreen;background-color: #00FFFF;font-size:100pt;"},
		'6':{'name':'eventTitle','code': 'top','data':'f_language','property': ""},
		'8':{'name':'footer','code': 'foot','data':'f_language','property':""},
		'9':{'name':'image','code': 'img','data':'and.bmp','property': "border:2pxsolidgreen;color:red;font-size:100pt;"},
		'10':{'name':'title_1','code': 'txt','data':'f_language','property':"margin-top:400px;margin-left:200px;width:100pt;height:100pt;border:2pxsolidgreen;color:red;font-size:100pt;"},
		'11':{'name':'title_2','code':'txt','data':'f_language','property':"margin-top:100px;margin-left:200px;width:200pt;height:300pt;border:2pxsolidgreen;color:red;font-size:100pt;"},
 		'12':{'name':'grid','code': 'grd','data':'f_language','property':""},
 		'13':{'name':'shape','code': 'shp','data':'f_language','property':""}
 		}
 		
	path="./initialize/confige.ini"
	data = write_file(path,args)
	print(data)

	# args = read_file(path)
	# print(args['1'])
