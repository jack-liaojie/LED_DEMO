
# -*- coding:UTF-8 -*-

global sss 
global lbltime 
def f():
	global sss
	global lbltime
	sss = '1'
	lbltime = '2'
def start_working():
	"""lblobject需要传入QLabel对象"""
	sss = 'a'
	lbltime = 'b'
	print(sss,lbltime)

def x():
	global sss
	global lbltime
	print(sss,lbltime)
f()
start_working()
x()
