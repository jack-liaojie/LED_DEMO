#!/usr/bin/env python3

from PyQt5.QtWidgets import *


class lstv_Widget(object):
    def setupUi(self, ListWidget):
        self.lst_ManagerItem = QListWidget()
        self.lst_ManagerItem.setViewMode(QListView.ListMode)

        lyt = QHBoxLayout()
        lyt.addWidget(self.lst_ManagerItem)
        ListWidget.setLayout(lyt)