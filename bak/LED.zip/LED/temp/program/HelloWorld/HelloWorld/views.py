# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.shortcuts import render


# def hello(request):
#     return HttpResponse("LiaoJie's World!")

def runoob(request):
    # context = {}
    # context['hello'] = 'Hello World'
    # # views_dict= ["廖杰教程","学习力","廖天琪学习"]
    # views_dict= {"name":"防护网"}
    import datetime
    now = datetime.datetime.now()
    return render(request,'runoob.html',{"time":now})

    #
    # return render(request,'runoob.html', )
# def runoob(request):
#     view_name = "廖杰教程"
#     return render(request,'runoob.html', {"name":view_name})
