# -*- coding: utf-8 -*-
#
# import _thread
# import time
#
# # 为线程定义一个函数
# def print_time( threadName, delay):
#    count = 0
#    while count < 5:
#       time.sleep(delay)
#       count += 1
#       print ("%s: %s" % ( threadName, time.ctime(time.time()) ))
#
# # 创建两个线程
# try:
#    _thread.start_new_thread( print_time, ("Thread-1", 2, ) )
#    _thread.start_new_thread( print_time, ("Thread-2", 4, ) )
# except:
#    print ("Error: 无法启动线程")
#
# while 1:
#    pass

# 666666666666666666666666666666666666666666666666666666666666
# # 单一线程
# import threading
# import time
#
# exitFlag = 0
#
# class myThread (threading.Thread):
#     def __init__(self, threadID, name, counter):
#         threading.Thread.__init__(self)
#         self.threadID = threadID
#         self.name = name
#         self.counter = counter
#     def run(self):
#         print ("开始线程：" + self.name)
#         print_time(self.name, self.counter, 5)
#         print ("退出线程：" + self.name)
#
# def print_time(threadName, delay, counter):
#     while counter:
#         if exitFlag:
#             threadName.exit()
#         time.sleep(delay)
#         print ("%s: %s" % (threadName, time.ctime(time.time())))
#         counter -= 1
#
# # 创建新线程
# thread1 = myThread(1, "Thread-1", 1)
# thread2 = myThread(2, "Thread-2", 2)
#
# # 开启新线程
# thread1.start()
# thread2.start()
# thread1.join()
# thread2.join()
# print ("退出主线程")

# # #666666666666666666666666666666666666666666666666666666666666
# import threading
# import time
# #线程同步
# # 1
# class myThread (threading.Thread):
#     def __init__(self, threadID, name, counter):
#         threading.Thread.__init__(self)
#         self.threadID = threadID
#         self.name = name
#         self.counter = counter
#     def run(self):
#         print ("开启线程： " + self.name)
#
#         # 获取锁，用于线程同步
#         threadLock.acquire()
#         print_time(self.name, self.counter, 12)
#         # 释放锁，开启下一个线程
#         threadLock.release()
# # 2
# def print_time(threadName, delay, counter):
#     while counter:
#         time.sleep(delay)
#         print ("%s: %s" % (threadName, time.ctime(time.time())))
#         counter -= 1
#
# threadLock = threading.Lock()
# threads = []
#
# # 3 创建新线程
# thread1 = myThread(1, "Thread-1", 1)
# thread2 = myThread(2, "Thread-2", 2)
#
# # 4 开启新线程
# thread1.start()
# thread2.start()
#
# # 添加线程到线程列表
# # threads.append(thread1)
# # threads.append(thread2)
# #
# # # 等待所有线程完成
# # for t in threads:
# #     t.join()
# # print ("退出主线程")
# 666666666666666666666666666666666666666666666666666666666666
# # 队列优先
# import queue
# import threading
# import time
#
# exitFlag = 0
#
# class myThread (threading.Thread):
#     def __init__(self, threadID, name, q):
#         threading.Thread.__init__(self)
#         self.threadID = threadID
#         self.name = name
#         self.q = q
#     def run(self):
#         print ("开启线程：" + self.name)
#         process_data(self.name, self.q)
#         print ("退出线程：" + self.name)
#
# def process_data(threadName, q):
#     while not exitFlag:
#         queueLock.acquire()
#         if not workQueue.empty():
#             data = q.get()
#             queueLock.release()
#             print ("%s processing %s" % (threadName, data))
#         else:
#             queueLock.release()
#         time.sleep(1)
#
# threadList = ["Thread-1", "Thread-2", "Thread-3"]
# nameList = ["One", "Two", "Three", "Four", "Five"]
# queueLock = threading.Lock()
# workQueue = queue.Queue(10)
# threads = []
# threadID = 1
#
# # 创建新线程
# for tName in threadList:
#     thread = myThread(threadID, tName, workQueue)
#     thread.start()
#     threads.append(thread)
#     threadID += 1
#
# # 填充队列
# queueLock.acquire()
# for word in nameList:
#     workQueue.put(word)
# queueLock.release()
#
# # 等待队列清空
# while not workQueue.empty():
#     pass
#
# # 通知线程是时候退出
# exitFlag = 1
#
# # 等待所有线程完成
# for t in threads:
#     t.join()
# print ("退出主线程")


# 666666666666666666666666666666666666666666666666666666666666
"""
传递参数
"""
# import time
# import threading
#
# def song(a,b,c):
#     print(a, b, c)
#     for i in range(5):
#         print("song")
#         time.sleep(1)
# if __name__ == "__main__":
#     # threading.Thread(target=song,args=(1,2,3)).start()
#     threading.Thread(target=song, args=(1,), kwargs={"c": 3, "b": 2}).start()
#     # threading.Thread(target=song,kwargs={"a":1,"c":3,"b":2}).start() #参数顺序可以变
# 666666666666666666666666666666666666666666666666666666666666
# import time
# import threading
# # 使用 threading 模块创建线程
# import queue
#
# # 优先级队列模块
# # 线程优先级队列(Queue)
# exitFlag = 0
#
#
# class myThread(threading.Thread):
#     def __init__(self, threadID, name, q):
#         threading.Thread.__init__(self)
#         self.threadID = threadID
#         self.name = name
#         self.q = q
#
#     def run(self):
#         print("开启线程：" + self.name)
#         process_data(self.threadID, self.name, self.q)
#         print("退出线程：" + self.name)
#
#
# def process_data(id, threadName, q):
#     while not exitFlag:
#         id += 1
#         if id >= 4:
#             data = q.get()
#             print("%s processing %s" % (threadName, data))
#         time.sleep(1)
#
#
# threadList = ["Thread-1", "Thread-2", "Thread-3"]
# nameList = ["One", "Two", "Three", "Four", "Five"]
# workQueue = queue.Queue(10)
# threads = []
# threadID = 1
# # 填充队列
# for word in nameList:
#     workQueue.put(word)
# # 创建新线程
# for tName in threadList:
#     thread = myThread(threadID, tName, workQueue)
#     thread.start()
#     threads.append(thread)
#     threadID += 1
# # 等待队列清空
# while not workQueue.empty():
#     pass
# # 通知线程是时候退出
# exitFlag = 1
# # 等待所有线程完成
# for t in threads:
#     t.join()
# print("退出主线程")
# 666666666666666666666666666666666666666666666666666666666666
import sys
import threading
import time

from PyQt5.QtWidgets import QWidget, QApplication, QPushButton, QHBoxLayout


class myThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        print('ok')

def myWin():
    thread = myThread()
    thread.start()

class Tw(QWidget):
    def __init__(self):
        super(Tw,self).__init__()
        self.resize(300,100)
        btn = QPushButton('Threadw')
        ly = QHBoxLayout()
        ly.addWidget(btn)
        self.setLayout(ly)

class Win(QWidget):
    def __init__(self):
        super(Win,self).__init__()
        self.resize(300,100)
        btn = QPushButton('Thread')
        ly = QHBoxLayout()
        ly.addWidget(btn)
        self.setLayout(ly)
        btn.clicked.connect(myWin)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWin = Win()
    mainWin.show()
    sys.exit(app.exec_())

# #666666666666666666666666666666666666666666666666666666666666
# 666666666666666666666666666666666666666666666666666666666666
# #666666666666666666666666666666666666666666666666666666666666
# 666666666666666666666666666666666666666666666666666666666666
# #666666666666666666666666666666666666666666666666666666666666
# 666666666666666666666666666666666666666666666666666666666666
# #666666666666666666666666666666666666666666666666666666666666
# 666666666666666666666666666666666666666666666666666666666666
