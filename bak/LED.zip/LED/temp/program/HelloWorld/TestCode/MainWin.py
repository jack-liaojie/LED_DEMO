# -*- coding: utf-8 -*-

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QBrush, QColor
from PyQt5.QtCore import Qt, QRect


class TreeWidgetDemo(QMainWindow):
    def __init__(self):
        # 1. 初始化主界面
        super(TreeWidgetDemo,self).__init__()
        self.status = self.statusBar()
        self.status.showMessage("This is my first statusBar")
        # 设置程序图标
        self.setWindowIcon(QIcon("../../images/admin.png"))
        # 设置汽包提示
        self.setToolTip("这是一个提示<b>气泡提示</b>")
        # 加载label标签
        lblDemo = QLabel('&Sdemo',self)
        lblDemo.setText("&This is a first label")

        lblHttp = QLabel(self)
        lblHttp.setText("<A href='http://baidu.com' >thank you </a>")
        lblHttp.setOpenExternalLinks(True)
        # 设置树控件
        treView = QTreeWidget()
        treView.setColumnCount(2)
        treView.setHeaderLabels(['1','2'])

        root = QTreeWidgetItem(treView)
        root.setText(0,"My")
        treView.addTopLevelItem(root)



        # 2. 设置 控件-->布局-->挂件-->窗体
        btnOK = QPushButton("OK")

        # 2.1 控件
        layout = QHBoxLayout()
        layout.addWidget(treView)
        layout.addStretch(1)
        layout.addWidget(btnOK)
        layout.addStretch(1)
        layout.addWidget(lblDemo)
        layout.addStretch(1)
        layout.addWidget(lblHttp)

        wdgFrame = QWidget()
        wdgFrame.setLayout(layout)

        self.setCentralWidget(wdgFrame)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    my_login_form = TreeWidgetDemo()
    # 显示登陆页面
    my_login_form.showMaximized()
    sys.exit(app.exec_())