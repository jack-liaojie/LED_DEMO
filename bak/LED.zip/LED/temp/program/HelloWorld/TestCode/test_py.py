# -*- coding: utf-8 -*-
enum = ["order", "sport_code", "sport_long_name", "sport_short_name",
        "opendate", "closedate", "sportid", "SportInfo", "lanuagecode", "SportComment", "SportConfigValue", "result"]
truple = {1:'1',2:'2',3:'3'}

print(truple(1))


