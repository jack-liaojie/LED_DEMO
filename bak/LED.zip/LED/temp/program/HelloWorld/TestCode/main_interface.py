import sys
from PyQt5 import QtWidgets
from login import Ui_login
from HelloWorld.TestCode.MainWin import TreeWidgetDemo


# 登陆页面

class login_form(QtWidgets.QWidget, Ui_login):
    def __init__(self):
        super(login_form, self).__init__()
        self.setupUi(self)

    def jump(self):
        self.close()
        self.m2 = jump_test()
        self.m2.showMaximized()


# 跳转页面
class jump_test(TreeWidgetDemo):
    def __init__(self):
        super(jump_test,self).__init__()
        self.test()

    def test(self):
       pass


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    my_login_form = login_form()
    # 显示登陆页面
    my_login_form.show()
    sys.exit(app.exec_())
