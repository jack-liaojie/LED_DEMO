# -*- coding: utf-8 -*-
# a = [1,2,3,4,5,6,7,8,9]
# b = [i*i for i in a if i>=5]
# c = [i**3 for i in a ]
# print(b)
# print(c)

# 666666666666666666666666666666666666666666666666666666666666

# fruits = ['orange', 'grape', 'pitaya', 'blueberry']
# for index, fruit in enumerate(fruits):
# 	print(index, ':', fruit)
# 666666666666666666666666666666666666666666666666666666666666
# students = {
#     'liaojie' : 18,
#     'xuexuli' : 30,
#     'liaotianqi' : 12
# }
# # b = [key for key,value in students.items()]
# b = {value:key for key,value in students.items()}
#
# print(b)

# 666666666666666666666666666666666666666666666666666666666666
# print(type(None))
#
# a = []
# if not a:
#     print('s')
# else:
#     print('f')
#
# if a is None:
#     print('s')
# else:
#     print('f')

# 666666666666666666666666666666666666666666666666666666666666

class Player():
    __stance = None
    __Flag = False
    def __new__(cls, *args, **kwargs):
        print("new is printing.")
        if cls.__stance is None:
            cls.__stance = super().__new__(cls)

        return cls.__stance
    def __init__(self):
        if not Player.__Flag:
            print("init printing")
            Player.__Flag = True


video = Player()
print(video)
stero = Player()
print(stero)