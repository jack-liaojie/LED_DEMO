# -*- coding: utf-8 -*-

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QWidget, QTreeWidget
from PyQt5.uic.properties import QtGui
from qtconsole.qt import QtCore


class treeWin(QWidget):

    def __init__(self):
        super().__init__()
        self.setupUi()

    def setupUi(self):
        self.treeWidget = QTreeWidget()
        self.treeWidget.setMinimumSize(QtCore.QSize(178, 200))
        self.treeWidget.setMaximumSize(QtCore.QSize(378, 571))
        self.treeWidget.setStyleSheet("background-color:#eeeeee;border:outset;color:#215b63;")
        self.treeWidget.setAutoScroll(True)
        self.treeWidget.setEditTriggers(QtWidgets.QAbstractItemView.DoubleClicked|QtWidgets.QAbstractItemView.EditKeyPressed)
        self.treeWidget.setTextElideMode(QtCore.Qt.ElideMiddle)
        self.treeWidget.setIndentation(25)
        self.treeWidget.setRootIsDecorated(True)
        self.treeWidget.setUniformRowHeights(False)
        self.treeWidget.setItemsExpandable(True)
        self.treeWidget.setAnimated(False)
        self.treeWidget.setHeaderHidden(True)
        self.treeWidget.setExpandsOnDoubleClick(True)
        self.treeWidget.setObjectName("treeWidget")

        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/images/file.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        item_0.setIcon(0, icon1)
        item_0.setFlags(QtCore.Qt.ItemIsEnabled)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/images/paper.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        item_1.setIcon(0, icon2)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.NoBrush)
        item_1.setBackground(0, brush)
        item_1.setIcon(0, icon2)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)

        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)

        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)


        item_0 = QtWidgets.QTreeWidgetItem(self.treeWidget)
        item_0.setIcon(0, icon1)
        item_1 = QtWidgets.QTreeWidgetItem(item_0)
        item_1.setIcon(0, icon2)


        self.treeWidget.header().setVisible(False)
        self.treeWidget.header().setDefaultSectionSize(91)
        #
        # self.content = QtWidgets.QWidget(self.splitter)
        # self.content.setEnabled(True)
        # self.content.setStyleSheet("background-color:#f4f9f4;")
        # self.content.setObjectName("content")
        #
        #
        #
        # self.label2 = QtWidgets.QLabel(self.content)
        # # self.label2.setGeometry(QtCore.QRect(290, 110, 301, 191))
        # self.label2.setStyleSheet("border-image: url(:/images/welcome.png);")
        # self.label2.setText("")
        # self.label2.setObjectName("label2")
        # self.label1 = QtWidgets.QLabel(self.content)
        # self.label1.setGeometry(QtCore.QRect(self.splitter.width(), 310, 221, 31))
        # self.label1.setStyleSheet("font: 16pt \"隶书\";color:#6ba083;")
        # self.label1.setObjectName("label1")
        # self.label1.setText("马术赛事管理系统")
        # self.label1.setAlignment(Qt.AlignCenter)

        self.retranslateUi()

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("MainWindow", "马术赛事管理系统"))
        self.treeWidget.headerItem().setText(0, _translate("MainWindow", "马术赛事管理系统"))
        __sortingEnabled = self.treeWidget.isSortingEnabled()
        self.treeWidget.setSortingEnabled(False)
        self.treeWidget.topLevelItem(0).setText(0, _translate("MainWindow", "基础数据"))
        self.treeWidget.topLevelItem(0).child(0).setText(0, _translate("MainWindow", "基本项目信息"))
        self.treeWidget.topLevelItem(0).child(1).setText(0, _translate("MainWindow", "系统设置"))

        self.treeWidget.topLevelItem(1).setText(0, _translate("MainWindow", "报名报项"))
        self.treeWidget.topLevelItem(1).child(0).setText(0, _translate("MainWindow", "参赛人员信息"))
        self.treeWidget.topLevelItem(1).child(1).setText(0, _translate("MainWindow", "报项信息"))

        self.treeWidget.topLevelItem(2).setText(0, _translate("MainWindow", "抽签编排"))
        self.treeWidget.topLevelItem(2).child(0).setText(0, _translate("MainWindow", "抽签编排"))
        self.treeWidget.topLevelItem(2).child(1).setText(0, _translate("MainWindow", "抽签展示"))

        self.treeWidget.topLevelItem(3).setText(0, _translate("MainWindow", "赛时数据"))
        self.treeWidget.topLevelItem(3).child(0).setText(0, _translate("MainWindow", "赛事安排"))

        self.treeWidget.topLevelItem(4).setText(0, _translate("MainWindow", "排名奖牌"))
        self.treeWidget.topLevelItem(4).child(0).setText(0, _translate("MainWindow", "奖牌统计"))

        self.treeWidget.topLevelItem(5).setText(0, _translate("MainWindow", "赛事纪录"))
        self.treeWidget.topLevelItem(5).child(0).setText(0, _translate("MainWindow", "纪录设置"))

        self.treeWidget.topLevelItem(6).setText(0, _translate("MainWindow", "报表管理"))
        self.treeWidget.topLevelItem(6).child(0).setText(0, _translate("MainWindow", "报表打印"))

        self.treeWidget.topLevelItem(7).setText(0, _translate("MainWindow", "数据备份"))
        self.treeWidget.topLevelItem(7).child(0).setText(0, _translate("MainWindow", "数据库备份"))

        self.treeWidget.topLevelItem(8).setText(0, _translate("MainWindow", "官方通告"))
        self.treeWidget.topLevelItem(8).child(0).setText(0, _translate("MainWindow", "通告打印"))

        self.treeWidget.setSortingEnabled(__sortingEnabled)


