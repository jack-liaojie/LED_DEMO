# # 11111111111111111111
# # import xml.etree.ElementTree as ET
# #
# # tree = ET.parse('students.xml')
# # root = tree.getroot()  # 使用getroot()获取根节点，得到的是一个Element对象
# #
# # #root = ET.fromstring(country_data_as_string) #从字符串变量中读取，返回的是Element对象
# #
# #
# # # 访问XML
# # """
# # tag = element.text      #访问Element标签
# # attrib = element.attrib #访问Element属性
# # text = element.text     #访问Element文本
# # """
# #
# # for element in root.findall('student'):
# #     tag = element.tag                  # 访问Element标签
# #     attrib = element.attrib            # 访问Element属性
# #     text = element.find('name').text   # 访问Element文本
# #     print(tag, attrib, text)
# #
# # print(root[0][0].text)                 # 子节点是嵌套的，我们可以通关索引访问特定的子节点
# #
# # # 查找元素
# # print("============ Element.iter() ===============")
# # for student in root.iter('student'):   # Element.iter()
# #     print(student[0].text)
# #
# #
# # print("============ Element.findall() ============")
# # for element in root.findall('student'):# Element.findall()
# #     name = element.find('name').text
# #     age = element.find('age').text
# #     score = element.find('score').text
# #
# #     print (name,age,score)
#
# 7777777777777777777777777777777777777777777777777


# # import xml.etree.ElementTree as ET
# #
# #
# # # 创建xml文件 #
# #
# # a = ET.Element("root")       #创建根节点
# #
# # b = ET.SubElement(a,"sub1")  #创建子节点，并添加属性
# # b.attrib = {"name":"name attribute"}
# #
# # c = ET.SubElement(a,"sub2")  #创建子节点，并添加数据
# # c.text = "test"
# #
# # tree = ET.ElementTree(a)    #创建elementtree对象，写文件
# # tree.write("test.xml")
# #
# # # 修改XML
#
# """
#     ElementTree.write()       将构建的XML文档写入文件。
#     Element.text = ''         直接改变字段内容
#     Element.append(Element)   为当前的Elment对象添加子对象
#     Element.remove(Element)   删除Element节点
#     Element.set(key, value)   添加和修改属性
#     ElementTree.write('filename.xml')   写出（更新）XMl文件
# """
# # #3
# # import xml.etree.ElementTree as ET
# # updateTree = ET.parse("test.xml")   # 读取待修改文件
# # root = updateTree.getroot()
# #
# # #
# # # newEle = ET.Element("NewElement")   # 创建新节点并添加为root的子节点
# # # newEle.attrib = {"name":"NewElement","age":"20"}
# # # newEle.text = "This is a new element"
# # # root.append(newEle)                 # 更新xml
# #
# # sub1 = root.find("sub1")            # 修改sub1的name属性
# # sub1.set("name","New Name")
# #
# # sub2 = root.find("sub2")            # 修改sub2的数据值
# # sub2.text = "New Value"
# #
# #
# # updateTree.write("test.xml")        # 写回原文件
# #
#
# 7777777777777777777777777777777777777777777777777

# from xml.etree.ElementTree import ElementTree, Element
#
#
# def read_xml(in_path):
#     '''读取并解析xml文件
#        in_path: xml路径
#        return: ElementTree'''
#     tree = ElementTree()
#     tree.parse(in_path)
#     return tree
#
#
# def write_xml(tree, out_path):
#     '''将xml文件写出
#        tree: xml树
#        out_path: 写出路径'''
#     tree.write(out_path, encoding="utf-8", xml_declaration=True)
#
#
# def if_match(node, kv_map):
#     '''判断某个节点是否包含所有传入参数属性
#        node: 节点
#        kv_map: 属性及属性值组成的map'''
#     for key in kv_map:
#         if node.get(key) != kv_map.get(key):
#             return False
#     return True
#
#
# # ----------------search -----------------
# def find_nodes(tree, path):
#     '''查找某个路径匹配的所有节点
#        tree: xml树
#        path: 节点路径'''
#     return tree.findall(path)
#
#
# def get_node_by_keyvalue(nodelist, kv_map):
#     '''根据属性及属性值定位符合的节点，返回节点
#        nodelist: 节点列表
#        kv_map: 匹配属性及属性值map'''
#     result_nodes = []
#     for node in nodelist:
#         if if_match(node, kv_map):
#             result_nodes.append(node)
#     return result_nodes
#
#
# # ---------------change ----------------------
# def change_node_properties(nodelist, kv_map, is_delete=False):
#     '''修改/增加 /删除 节点的属性及属性值
#        nodelist: 节点列表
#        kv_map:属性及属性值map'''
#     for node in nodelist:
#         for key in kv_map:
#             if is_delete:
#                 if key in node.attrib:
#                     del node.attrib[key]
#             else:
#                 node.set(key, kv_map.get(key))
#
#
# def change_node_text(nodelist, text, is_add=False, is_delete=False):
#     '''改变/增加/删除一个节点的文本
#        nodelist:节点列表
#        text : 更新后的文本'''
#     for node in nodelist:
#         if is_add:
#             node.text += text
#         elif is_delete:
#             node.text = ""
#         else:
#             node.text = text
#
#
# def create_node(tag, property_map, content):
#     '''新造一个节点
#        tag:节点标签
#        property_map:属性及属性值map
#        content: 节点闭合标签里的文本内容
#        return 新节点'''
#     element = Element(tag, property_map)
#     element.text = content
#     return element
#
#
# def add_child_node(nodelist, element):
#     '''给一个节点添加子节点
#        nodelist: 节点列表
#        element: 子节点'''
#     for node in nodelist:
#         node.append(element)
#
#
# def del_node_by_tagkeyvalue(nodelist, tag, kv_map):
#     '''同过属性及属性值定位一个节点，并删除之
#        nodelist: 父节点列表
#        tag:子节点标签
#        kv_map: 属性及属性值列表'''
#     for parent_node in nodelist:
#         children = parent_node.getchildren()
#         for child in children:
#             if child.tag == tag and if_match(child, kv_map):
#                 parent_node.remove(child)
#
#
# if __name__ == "__main__":
#     # 1. 读取xml文件
#     tree = read_xml("test_02.xml")
#
#     # 2. 属性修改
#     nodes = find_nodes(tree, "processers/processer")  # 找到父节点
#     result_nodes = get_node_by_keyvalue(nodes, {"name": "BProcesser"})  # 通过属性准确定位子节点
#     change_node_properties(result_nodes, {"age": "1"})  # 修改节点属性
#     change_node_properties(result_nodes, {"value": ""}, True)  # 删除节点属性
#
#     #  3. 节点修改 #
#     a = create_node("person", {"age": "15", "money": "200000"}, "this is the firest content")  # 新建节点
#     add_child_node(result_nodes, a)  # 插入到父节点之下
#
#     # 4. 删除节点 #
#     del_parent_nodes = find_nodes(tree, "processers/services/service")  # 定位父节点
#     target_del_node = del_node_by_tagkeyvalue(del_parent_nodes, "chain", {"sequency": "chain1"})  # 准确定位子节点并删除之
#
#     # 5. 修改节点文本 #
#     text_nodes = get_node_by_keyvalue(find_nodes(tree, "processers/services/service/chain"),
#                                       {"sequency": "chain3"})  # 定位节点
#     change_node_text(text_nodes, "new text")
#
#     # 6. 输出到结果文件
#     write_xml(tree, "./xiugai.xml")


# 7777777777777777777777777777777777777777777777777
# """
# # from xml.dom import minidom
# #
# # from xml.dom.minidom import parse
#
# import xml.etree.ElementTree as ET
#
#
# # def getXMLString(strSection, strItem):
# #     # 1. 获得xml文件，parse进行解析。
# #     domTree = parse("./Localization/en.xml")
# #     # 2. 获得跟节点,这里是<Localization>
# #     rootNode = domTree.documentElement
# #     # 3. 根据已知子节点strSection=<OVRLogin>,获得子节点目录
# #     customers = rootNode.getElementsByTagName(strSection)
# #     # 4. 遍历查找strItem，获取其的数据内容
# #     for customer in customers:
# #         # 5.当子项目是<Server>时，赋值给name.
# #         name = customer.getElementsByTagName(strItem)[0]
# #         print(name.nodeName)
# #     # 6.返回<Server>的值
# #     return name.childNodes[0].data
# #
#
# # def updateXMLString(strSection, strItem, strVolue):
# #     # 1. 获得xml文件，parse进行解析。
# #     domTree = parse("./Localization/en.xml")
# #     # 2. 获得跟节点,这里是<Localization>
# #     rootNode = domTree.documentElement
# #     # 3. 根据已知子节点strSection=<OVRLogin>,获得子节点目录
# #     customers = rootNode.getElementsByTagName(strSection)
# #     # 4. 遍历查找strItem，获取其的数据内容
# #     for customer in customers:
# #         # 5.当子项目是<Server>时，赋值给name.
# #         name = customer.getElementsByTagName(strItem)[0]
# #         name.childNodes[0].data = strVolue
# #     # 6.返回<Server>的值
# #
# #     with open("./Localization/en.xml", 'w') as f:
# #         # 缩进 - 换行 - 编码
# #         domTree.writexml(f, indent='', addindent='\t',  encoding='UTF-8')
# #         # newl = '\n',
# #     return True
#
#
# # def writeXMLFile():
# #     domTree = parse("./customer.xml")
# #     # 文档根元素
# #     rootNode = domTree.documentElement
# #
# #     # 新建一个customer节点
# #     customer_node = domTree.createElement("customer")
# #     customer_node.setAttribute("ID", "C003")
# #
# #     # 创建name节点,并设置textValue
# #     name_node = domTree.createElement("name")
# #     name_text_value = domTree.createTextNode("kavin")
# #     name_node.appendChild(name_text_value)  # 把文本节点挂到name_node节点
# #     customer_node.appendChild(name_node)
# #
# #     # 创建phone节点,并设置textValue
# #     phone_node = domTree.createElement("phone")
# #     phone_text_value = domTree.createTextNode("32467")
# #     phone_node.appendChild(phone_text_value)  # 把文本节点挂到name_node节点
# #     customer_node.appendChild(phone_node)
# #
# #     # 创建comments节点,这里是CDATA
# #     comments_node = domTree.createElement("comments")
# #     cdata_text_value = domTree.createCDATASection("A small but healthy company.")
# #     comments_node.appendChild(cdata_text_value)
# #     customer_node.appendChild(comments_node)
# #
# #     rootNode.appendChild(customer_node)
# #
# #     with open('added_customer.xml', 'w') as f:
# #         # 缩进 - 换行 - 编码
# #         domTree.writexml(f, addindent='  ', encoding='utf-8', standalone='true')
#
# """
# 6666666666666666666666666666666666666666
# import kivy
# from kivy.app import App
# from kivy.uix.label import Label
# from kivy.uix.gridlayout import GridLayout
# from kivy.uix.textinput import TextInput
# kivy.require("1.11.1")
# class One:
#     def __init__(self):
#         print("One!")
# class Two:
#     def __init__(self):
#         super().__init__()
#         print("Two")
# class ConnectPage(GridLayout):
#     def __init__(self,**kwargs):
#         super(ConnectPage, self).__init__(**kwargs)
#
# class EpicApp(App):
#     def build(self):
#         return ConnectPage()
#
#
# if __name__ == "__main__":
#     EpicApp().run()
# 7777777777777777777777777777777777777777777777777
# python -m pip uninstall pillow
# python -m pip install --use-wheel pillow
# pip install kivy.deps.glew kivy.deps.sdl2 kivy.deps.angle
# def y(**kwargs):
#     print(kwargs['server'],kwargs['user'])
#
# y(server='127.0.0.1', user='sa', password='111', database='N_EQ')
#
# x = {'server': '127.0.0.1', "user": 'sa', "password": '111', "database": 'N_EQ'}
# x['server'] = '1234123'
# print(x)
#
# x ={}
# x['server'] = '127.0.0.2'
# x['user'] = 'sa'
# print(x)
#

# 7777777777777777777777777777777777777777777777777
# def del_Position(param):
#     return print('del_Position****')
#
# def edit_Position(param):
#     return print('edit_Position****')
#
# def get_default(param):
#     return "Looking forward to the Weekend"
#
#
# switcher = {
#     'edit_Position': edit_Position,
#     'del_Position': del_Position,
#     'get_default': get_default
# }
# param = ['1']
# switcher.get('edit_Position')(param)

# 7777777777777777777777777777777777777777777777777
# import sys
# from PyQt5.QtWidgets import QApplication, QWidget, QHBoxLayout, QPushButton
#
#
# class Winform(QWidget):
#     def init(self, parent=None):
#         super(Winform, self).init(parent)
#         self.setWindowTitle("水平布局管理例子")
#         self.resize(800, 50)
#         # 水平布局按照从左到右的顺序进行添加按钮部件。
#         hlayout = QHBoxLayout()
#         # 添加伸缩
#         hlayout.addStretch(0)
#
#         hlayout.addWidget(QPushButton(str(1)))
#         hlayout.addWidget(QPushButton(str(2)))
#         hlayout.addWidget(QPushButton(str(3)))
#         hlayout.addWidget(QPushButton(str(4)))
#         hlayout.addWidget(QPushButton(str(5)))
#         # 添加伸缩
#         # hlayout.addStretch(1)
#
#         self.setLayout(hlayout)
#
#
# if __name__ == "__main__":
#     app = QApplication(sys.argv)
#     form = Winform()
#     form.show()
#     sys.exit(app.exec_())
# 7777777777777777777777777777777777777777777777777
# class DBSetting(QWidget,Ui_Form):
#     def __init__(self):
#         QWidget.__init__(self)
#         self.setupUi(self)
# 
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     my_login_form = DBSetting()
#     # 显示登陆页面
#     my_login_form.show()
#     sys.exit(app.exec_())
# 7777777777777777777777777777777777777777777777777
# from kivy.app import App
# from kivy.uix.button import Button
#
# class TestApp(App):
#     def build(self):
#         return Button(text='Hello World')
#
# TestApp().run()
# 7777777777777777777777777777777777777777777777777
# day = 2
#
#
# def get_sunday():
#     return 'sunday'
#
#
# def get_monday():
#     return 'monday'
#
#
# def get_tuesday():
#     return 'tuesday'
#
#
# def get_default():
#     return 'unknow'
#
#
# switcher = {
#     0: get_sunday,
#     1: get_monday,
#     2: get_tuesday
# }
# day_name = switcher.get(day, get_default)()
# print(day_name)

# 7777777777777777777777777777777777777777777777777
# import sys
#
# from PyQt5.QtWidgets import QWidget, QApplication, QMainWindow, QPushButton
#
#
# class A(object):
#     def __init__(self):
#
#         self.a_1 = 'a_1'
#         self.a_2 = 'a_2'
#     def a_pro(self):
#         print(self.a_1)
#
#     def b_pro(self):
#         print(self.a_2)
#
# class C(QMainWindow,A):
#     def __init__(self):
#         super().__init__()
#
# class B(QMainWindow,A):
#     def __init__(self):
#         super().__init__()
#         self.resize(600, 300)
#         self.b_1 = 'b_1'
#         btn = QPushButton('OK')
#
#         # self.b_pro()
#         # print(self.parent().children())
#     # def a_pro(self):
#     #     print(self.b_1)
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     x = B()
#     x.show()
#     sys.exit(app.exec_())
# # x.a_pro()
# 7777777777777777777777777777777777777777777777777
# fruits = ['orange', 'grape', 'pitaya', 'blueberry']
# for index, fruit in enumerate(fruits):
# 	print(index, ':', fruit)
# # 7777777777777777777777777777777777777777777777777
# data = [7, 20, 3, 15, 11]
# result = [num * 3 for num in data if num > 10]
# print(result)  # [60, 45, 33]
# # 7777777777777777777777777777777777777777777777777
# keys = ['1001', '1002', '1003']
# values = ['骆昊', '王大锤', '白元芳']
# d = dict(zip(keys, values))
# print(d)
# 7777777777777777777777777777777777777777777777777
# # 不需要建立连接
# import socket
#
# # 创建socket对象
# # SOCK_DGRAM    udp模式
# s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# # 发送数据 字节
# # s.sendto("你好".encode(), ("127.0.0.1", 8000))
# s.sendto("I'm Jack.L Hello World!".encode(), ("127.0.0.1", 8000))
# 7777777777777777777777777777777777777777777777777
# UDP
# import socket
#
# BUFSIZE = 1024
# client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# while True:
#     msg = input(">> ").strip()
#     ip_port = ('127.0.0.1', 9999)
#     client.sendto(msg.encode('utf-8'), ip_port)
#
#     data, server_addr = client.recvfrom(BUFSIZE)
#     print('客户端recvfrom ', data, server_addr)
#     print('Im Jack.L Hello World! ', data, server_addr)
# 7777777777777777777777777777777777777777777777777
# tcp 客户端
from socket import *

HOST = gethostbyname(gethostname())
PORT = 9000
BUFSIZ = 1024
ADDRESS = (HOST, PORT)

tcpClientSocket = socket(AF_INET, SOCK_STREAM)
tcpClientSocket.connect(ADDRESS)

while True:
    data = input('>')
    if not data:
        break

    # 发送数据
    tcpClientSocket.send(data.encode('utf-8'))
    # 接收数据
    data, ADDR = tcpClientSocket.recvfrom(BUFSIZ)
    if not data:
        break
    print("服务器端响应：", data.decode('utf-8'))

print("链接已断开！")
tcpClientSocket.close()
# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777

# 7777777777777777777777777777777777777777777777777
