# -*- coding: utf-8 -*-
# day = 0
# switcher = {
#     0 : 'Sunday',
#     1 : 'Monday',
#     2 : 'Tuesday'
# }
# # r = switcher[day]
# r = switcher.get(day,'Unkown')
# print(r)
# 666666666666666666666666666666666666666666666666666666666666

# day = 2
# def get_sunday():
#     return 'Sunday'
# def get_monday():
#     return 'Monday'
# def get_tuesday():
#     return 'Tuesday'
# def get_default():
#     return 'Default'
# switcher = {
#     0 : get_sunday,
#     1 : get_monday,
#     2 : get_tuesday
# }
#
# r = switcher.get(day,get_default)()
# print(r)

# 666666666666666666666666666666666666666666666666666666666666



# 666666666666666666666666666666666666666666666666666666666666



# 666666666666666666666666666666666666666666666666666666666666

# 666666666666666666666666666666666666666666666666666666666666



# 666666666666666666666666666666666666666666666666666666666666


