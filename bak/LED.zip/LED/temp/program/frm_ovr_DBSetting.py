# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'frmOVRDBSetting.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!

import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

class Ui_frmOVRDBSetting(object):

    def setupUi(self, frmOVRDBSetting):
        self.lbl_Sever = QLabel("服务器设置:")
        self.txt_SeverName = QLineEdit()
        self.lbl_Password = QLabel("密码:")
        self.txt_PasswordName = QLineEdit()
        self.lbl_UserID = QLabel("用户名:")
        self.txt_UserIDName = QLineEdit()
        self.lbl_getPWD = QLabel("")
        self.chk_getPWD = QCheckBox("保存密码")
        self.lbl_DB = QLabel("数据库")
        self.cmb_DataBase = QComboBox()


        self.layout_setDB = QFormLayout()
        self.layout_setDB.addRow(self.lbl_Sever,self.txt_SeverName)
        self.layout_setDB.addRow(self.lbl_Password,self.txt_PasswordName)
        self.layout_setDB.addRow(self.lbl_UserID,self.txt_UserIDName)
        self.layout_setDB.addRow(self.lbl_getPWD,self.chk_getPWD)
        self.layout_setDB.addRow(self.lbl_DB,self.cmb_DataBase)

        self.btnOK = QPushButton("OK")
        self.btnCancel = QPushButton("Cancel")
        self.btnTest = QPushButton("Test")

        self.layout_HBox = QHBoxLayout()
        self.layout_HBox.addWidget(self.btnTest)
        self.layout_HBox.addWidget(self.btnCancel)
        self.layout_HBox.addWidget(self.btnOK)



        self.layout_VBox = QVBoxLayout()
        self.layout_VBox.addLayout(self.layout_setDB)
        self.layout_VBox.addLayout(self.layout_HBox)

        frmOVRDBSetting.setLayout(self.layout_VBox)

