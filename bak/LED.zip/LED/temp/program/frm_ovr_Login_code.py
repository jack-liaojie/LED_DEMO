# -*- coding: utf-8 -*-
import sys

from PyQt5.QtWidgets import QDialog, QApplication, QMainWindow, QWidget

import ADB_running
from frm_ovr_AMain import OVRMainFrameForm
from frm_ovr_AMain_code import show_AMain
from frm_ovr_DBSetting_code import DBSetting
from frm_ovr_Login import Ui_OVRLoginForm
import AXML_running as x


class subWindow(QDialog, Ui_OVRLoginForm):
    def __init__(self):
        QDialog.__init__(self)
        self.setupUi(self)
        self.path = './Localization/config.xml'
        self.section = 'UserSettings'
        self.server = 'Server'
        self.DataBase = 'DataBase'
        self.PdfPath = 'PrtPath'
        self.load_XML()
        self.load_DB_proc()

        self.btnLogin.clicked.connect(self.load_AMain)
        self.btnDBSetting.clicked.connect(self.load_DBSet)


    def load_DB_proc(self):
        x = ADB_running.get_Results()
        # 加载用户信息
        params =[]
        results = x.do('Proc_GetOperatorsInfo', params)
        i = 0
        for txt_user in results:
            self.cmbUser.addItem(txt_user[1],txt_user[0])
            print(self.cmbUser.itemData(i))
            i += 1
        # 加载角色信息
        results = x.do('Proc_GetOperatorRoles', [self.cmbUser.itemData(0)])
        self.cmbRole.addItem(results[0][3])

    def load_XML(self):
        # TODO:load xml config.xml
        self.lbServerName.setText(x.get_xml_text(self.path, self.section, self.server))
        self.lbDbName.setText(x.get_xml_text(self.path, self.section, self.DataBase))
        self.txRptPrtPath.setText(x.get_xml_text(self.path, self.section, self.PdfPath))

    def load_AMain(self):
        self.close()
        self.x = show_AMain()
        self.x.showMaximized()

    def load_DBSet(self):
        self.y = DBSetting()
        self.y.show()


class jump_AMain(QMainWindow, OVRMainFrameForm):
    def __init__(self):
        super(jump_AMain, self).__init__()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    sub = subWindow()
    sub.show()
    sys.exit(app.exec_())
