# -*- coding: utf-8 -*-
import sys

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QListWidgetItem, QWidget, QMessageBox, QApplication

from frm_ovr_ListView import lstv_Widget


class ListWidgetCode(QWidget, lstv_Widget):
    mySignal = pyqtSignal(str)
    def __init__(self):
        super(ListWidgetCode, self).__init__()
        self.setupUi(self)

        # 设置根节点
        root = QListWidgetItem(self.lst_ManagerItem)

        AItemT = [("GeneralData", "GeneralData.ico"), ("Register", "Register.ico"),
                  ("Draw Arrange", "DrawArrange.ico"), ("Schedule", "MatchSchedule.ico"),
                  ("Machdate", "DataEntry.ico"), ("Medal", "RankMedal.ico"),
                  ("Record", "DataEntry.ico"), ("Report", "Report.ICO"),
                  ("Network", "Network_OK.ico"), ("Database", "dbBackup.ico")]
        for AName, AFileName in AItemT:
            child1 = QListWidgetItem(self.lst_ManagerItem)
            child1.setText(AName)
            child1.setIcon(QIcon("./images/" + AFileName))

        self.lst_ManagerItem.clicked.connect(self.clicklistItem)
        self.lst_ManagerItem.addItem(root)

    def clicklistItem(self, index):
        self.switcher.get(index.row(), self.get_default)(self.mySignal)

    def GeneralData(signal):
        signal.emit('GeneralData')
        return '1'

    def Register(signal):
        signal.emit('Register')
        return '2'

    def DrawArrange(signal):
        signal.emit('DrawArrange')
        return '3'

    def MatchSchedule(signal):
        signal.emit('MatchSchedule')
        return '4'

    def DataEntry(signal):
        signal.emit('DataEntry')
        return '5'

    def RankMedal(signal):
        signal.emit('RankMedal')
        return '6'

    def Record(signal):
        signal.emit('Record')
        return '7'

    def Report(signal):
        signal.emit('Report')
        return '8'

    def Network(signal):
        signal.emit('Network')
        return '9'

    def dbBackup(signal):
        signal.emit('dbBackup')
        return '10'

    def get_default(signal):
        return 'unknow'

    switcher = {
        0: get_default,
        1: GeneralData,
        2: Register,
        3: DrawArrange,
        4: MatchSchedule,
        5: DataEntry,
        6: RankMedal,
        7: Record,
        8: Report,
        9: Network,
        10: dbBackup
    }

if __name__ == '__main__':
    app = QApplication(sys.argv)
    tree = ListWidgetCode()
    tree.show()
    sys.exit(app.exec_())
