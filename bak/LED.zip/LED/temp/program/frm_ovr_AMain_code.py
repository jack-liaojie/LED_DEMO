# -*- coding: utf-8 -*-
import sys

from PyQt5.QtWidgets import QMainWindow, QApplication

from frm_ovr_AMain import OVRMainFrameForm
from frm_ovr_Centwidget import tab_Widget
from frmdatagrid import DataGrid
from HelloWorld.TestCode.untitled import subWindow

class show_AMain(QMainWindow, OVRMainFrameForm):
    def __init__(self):
        super(show_AMain, self).__init__()
        self.wdg_treeview.mySignal.connect(self.set_centWidget)

    def set_centWidget(self, widgetname):
        self.takeCentralWidget()
        if widgetname == 'GeneralData':
            wdg_tab = tab_Widget()
            self.setCentralWidget(wdg_tab)
        elif widgetname == 'Register':
            wdg_grid = DataGrid()
            self.setCentralWidget(wdg_grid)
        elif widgetname == 'DrawArrange':
            subWin = subWindow()
            self.setCentralWidget(subWin)
        elif widgetname == 'MatchSchedule':
            wdg_tab = tab_Widget()
            self.setCentralWidget(wdg_tab)
        elif widgetname == 'DataEntry':
            wdg_tab = tab_Widget()
            self.setCentralWidget(wdg_tab)
        elif widgetname == 'RankMedal':
            wdg_grid = DataGrid()
            self.setCentralWidget(wdg_grid)
        elif widgetname == 'Record':
            wdg_grid = DataGrid()
            self.setCentralWidget(wdg_grid)
        elif widgetname == 'Report':
            wdg_tab = tab_Widget()
            self.setCentralWidget(wdg_tab)
        elif widgetname == 'Network':
            wdg_grid = DataGrid()
            self.setCentralWidget(wdg_grid)
        elif widgetname == 'dbBackup':
            wdg_tab = tab_Widget()
            self.setCentralWidget(wdg_tab)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    my_login_form = show_AMain()
    # 显示登陆页面
    my_login_form.showMaximized()
    sys.exit(app.exec_())
