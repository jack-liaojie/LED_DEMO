# -*- coding: utf-8 -*-

'''
    【简介】
	PyQT5中单元格的基本例子

'''
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QMenu, QComboBox, \
    QPushButton, QAbstractItemView, QMessageBox
import ADB_running

from frmOVRBasicItemEdit import OVRBasicItemEditForm


class frmDisciplineEvents(object):
    def setupUi(self, DisciplineEvents):
        DisciplineEvents.setObjectName("DisciplineEvents")
        DisciplineEvents.resize(1024, 300)

        conLayout = QVBoxLayout()
        self.tblw_center = QTableWidget()

        conLayout.addWidget(self.tblw_center)
        self.setLayout(conLayout)
