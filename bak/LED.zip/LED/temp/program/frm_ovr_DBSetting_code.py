# -*- coding: utf-8 -*-
import sys

from PyQt5.QtWidgets import QDialog, QApplication

from frm_ovr_DBSetting import Ui_frmOVRDBSetting


class DBSetting(QDialog, Ui_frmOVRDBSetting):
    def __init__(self):
        super(DBSetting, self).__init__()
        self.setupUi(self)

        self.btnOK.clicked.connect(self.btnOK_click)
        self.btnCancel.clicked.connect(self.btnCancel_click)
        self.btnTest.clicked.connect(self.btnTest_click)

    def btnOK_click(self):
        print("ok")

    def btnCancel_click(self):
        print('cancel')

    def btnTest_click(self):
        print('Test')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    my_login_form = DBSetting()
    # 显示登陆页面
    my_login_form.show()
    sys.exit(app.exec_())
