# -*- coding: utf-8 -*-
import sys

from PyQt5.QtCore import QDate, pyqtSignal
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QLabel, QComboBox, QCalendarWidget, QFormLayout, \
    QVBoxLayout, QPushButton, QSpacerItem, QDateTimeEdit, QHBoxLayout


class OVRBasicItemEditForm(QWidget):
    # 1.定义传递给主窗体的消息，及包含的数据类型。
    signel_ovrbasicitemedit = pyqtSignal(list)

    def __init__(self, enum=[]):
        super(OVRBasicItemEditForm, self).__init__()

        self.setupUi()
        if enum:
            self.load_data_fromclass(enum)

    def setupUi(self):
        self.lbl_Language = QLabel("语言")
        self.cmb_Language = QComboBox()

        self.lbl_LongName = QLabel("长名")
        self.txt_LongName = QLineEdit()

        self.lbl_ShortName = QLabel("短名")
        self.txt_shortname = QLineEdit()

        self.lbl_RegCode = QLabel("代码")
        self.txt_regcode = QLineEdit()

        self.lbl_StartDate = QLabel("开始日期")
        self.cmb_startdate = QDateTimeEdit(QDate.currentDate(), self)
        self.cmb_startdate.setDisplayFormat("yyyy-MM-dd")

        self.lbl_EndDate = QLabel("结束日期")
        self.cmb_enddate = QDateTimeEdit(QDate.currentDate(), self)
        self.cmb_enddate.setDisplayFormat("yyyy-MM-dd")

        self.lbl_Sex = QLabel("注册性别")
        self.cmb_sex = QComboBox()

        self.lbl_RegType = QLabel("注册类型")
        self.cmb_regtype = QComboBox()

        self.lbl_CompetitionType = QLabel("比赛类型")
        self.cmb_competitiontype = QComboBox()

        self.lbl_Group = QLabel("序号")
        self.txt_group = QLineEdit()

        self.lbl_Comment = QLabel("备注")
        self.txt_comment = QLineEdit()

        infolayout = QFormLayout()
        infolayout.addRow(self.lbl_Language, self.cmb_Language)
        infolayout.addRow(self.lbl_LongName, self.txt_LongName)
        infolayout.addRow(self.lbl_ShortName, self.txt_shortname)
        infolayout.addRow(self.lbl_RegCode, self.txt_regcode)
        infolayout.addRow(self.lbl_StartDate, self.cmb_startdate)
        infolayout.addRow(self.lbl_EndDate, self.cmb_enddate)
        infolayout.addRow(self.lbl_Sex, self.cmb_sex)
        infolayout.addRow(self.lbl_RegType, self.cmb_regtype)
        infolayout.addRow(self.lbl_CompetitionType, self.cmb_competitiontype)
        infolayout.addRow(self.lbl_Group, self.txt_group)
        infolayout.addRow(self.lbl_Comment, self.txt_comment)

        self.btn_OK = QPushButton("确定")
        self.spc_Litter = QSpacerItem(40, 20)
        self.btn_Cancel = QPushButton("取消")

        btnlayout = QHBoxLayout()
        btnlayout.addWidget(self.btn_Cancel)
        btnlayout.addItem(self.spc_Litter)
        btnlayout.addWidget(self.btn_OK)

        formlayout = QVBoxLayout()
        formlayout.addLayout(infolayout)
        formlayout.addLayout(btnlayout)
        self.setLayout(formlayout)

        self.btn_OK.clicked.connect(self.btn_OK_clicked)
        self.btn_Cancel.clicked.connect(self.close)

    def load_data_fromclass(self, enums):
        self.cmb_Language.addItem(enums[1])
        self.txt_LongName.setText(enums[2])
        self.txt_shortname.setText(enums[3])
        # self.txt_regcode.text = emus[3]
        self.cmb_startdate.setDate(QDate.fromString(enums[4], "yyyy-MM-dd"))
        self.cmb_enddate.setDate(QDate.fromString(enums[5], "yyyy-MM-dd"))
        # self.cmb_sex.text = emus[6]
        # self.cmb_regtype.text = emus[7]
        # self.cmb_competitiontype.text = emus[8]
        # self.txt_group.text = emus[9]

    def return_data_toclass(self):
        self.lst_sportinfo = []
        self.lst_sportinfo.append(self.cmb_Language.currentText())
        self.lst_sportinfo.append(self.txt_LongName.text())
        self.lst_sportinfo.append(self.txt_shortname.text())
        self.lst_sportinfo.append(self.cmb_startdate.text())
        self.lst_sportinfo.append(self.cmb_enddate.text())
        return self.lst_sportinfo

    def btn_OK_clicked(self):
        # 2. 将给主窗体的消息进行发送，包括传递的信息内容，这里是list类型。
        self.signel_ovrbasicitemedit.emit(self.return_data_toclass())
        # self.destroy()
        self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    example = OVRBasicItemEditForm(['chn','1','2','3','2000-1-1','2002-2-2'])
    example.show()
    sys.exit(app.exec_())
