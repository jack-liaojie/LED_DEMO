# -*- coding: utf-8 -*-
import sys

from PyQt5.QtWidgets import QWidget, QMessageBox, QApplication, QMenu

import ADB_running
from frmOVRBasicItemEdit import OVRBasicItemEditForm
from frm_ovr_DisciplineEvents import frmDisciplineEvents

class DisciplineEvents(QWidget, frmDisciplineEvents):
    def __init__(self, table_params):
        super(DisciplineEvents, self).__init__()
        self.setupUi(self)
        self.tblw_center.customContextMenuRequested.connect(self.do_menu)  # 右键菜单

        self.instance_DB = ADB_running.get_Results()
        self.table_params = table_params  # 如：{'operater':'get_disciplineEvents', 'params':['1', 'CHN']}通过字典传递需要加载的数据

        # 读取sql数据加载到tablewidget上，并返回数据集给results.
        # {'operater':'get_disciplineEvents', 'params':['1', 'CHN']}
        self.results = self.instance_DB.get_SQL_results(self.tblw_center,
                                                        self.table_params['operater'], self.table_params[
                                                            'params'])

    def del_row(self):
        if QMessageBox.Ok == QMessageBox.information(self, "提示", "确定删除该数据!", QMessageBox.Cancel | QMessageBox.Ok):
            self.do_SQL('get_disciplineEvents', self.results['results'][self.row_num])

    def add_row(self):
        self.call_Editform()

    def edit_row(self):
        self.call_Editform()

    def call_Editform(self):
        # 通过self.enum传递row数据
        self.row_num = self.tblw_center.selectionModel().currentIndex().row()  # 选定的行号
        self.instance_basicitem = OVRBasicItemEditForm(self.results['results'][self.row_num])  # 根据SQL返回的数据集中，找到选定行数据
        # 3. 绑定处理过程，用于处理子窗体返回的消息。
        self.instance_basicitem.signel_ovrbasicitemedit.connect(self.do_SQL)
        self.instance_basicitem.show()

    def do_SQL(self, params):
        '''
        执行更新，添加命令
        :param params: 从编辑窗体返回，编辑完成的list数据
        :return:
        '''
        results = self.instance_DB.do('update_venuelist', params)
        return results

    def do_menu(self, pos):
        menu = QMenu()
        menu_edit = menu.addAction(u"编辑")
        menu_add = menu.addAction(u"添加")
        menu_delete = menu.addAction(u"删除")
        menu_refresh = menu.addAction(u"刷新")
        action = menu.exec_(self.tblw_center.mapToGlobal(pos))

        if action == menu_edit:
            self.edit_row()

        elif action == menu_add:
            self.add_row()

        elif action == menu_delete:
            self.del_row()

        elif action == menu_refresh:
            self.results = self.instance_DB.get_SQL_results(self.tblw_center,
                                                            self.table_params['operater'], self.table_params[
                                                                'params'])

        else:
            return


if __name__ == '__main__':
    app = QApplication(sys.argv)
    example = DisciplineEvents({'operater': 'get_disciplineEvents', 'params': ['1', 'CHN']})
    example.show()
    sys.exit(app.exec_())
