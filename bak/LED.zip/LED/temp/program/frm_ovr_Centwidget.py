# -*- coding: utf-8 -*-
"""
项目基础信息处理界面
Designer: Jack.L
Date:2020-5-17
"""

import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

from frm_ovr_DisciplineEvents_code import DisciplineEvents
from frm_ovr_Sport_code import SportCode
from frmdatagrid import DataGrid


class tab_Widget(QTabWidget):
    def __init__(self, parent=None):
        super(tab_Widget, self).__init__(parent)
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.addTab(self.tab1, "Tab 1")
        self.addTab(self.tab2, "Tab 2")
        self.tab1UI()
        self.tab2UI()
        self.setWindowTitle("项目基础信息处理系统")

    def tab1UI(self):
        layout = QVBoxLayout()
        # 纵向加载控件
        tbw_sport = SportCode()
        tbw_disciplineEvent = DisciplineEvents({'operater': 'get_disciplineEvents', 'params': ['1', 'CHN']})
        wdg_grid = DataGrid()
        spl_V = QSplitter(Qt.Vertical)
        spl_V.addWidget(tbw_sport)
        spl_V.addWidget(tbw_disciplineEvent)
        spl_V.addWidget((wdg_grid))

        # 横向加载控件
        spl_H = QSplitter(Qt.Horizontal)
        textedit = QTextEdit()
        spl_H.addWidget(spl_V)
        spl_H.addWidget(textedit)

        layout.addWidget(spl_H)
        self.setTabText(0, '基础信息')
        self.tab1.setLayout(layout)

    def tab2UI(self):
        layout = QFormLayout()
        sex = QHBoxLayout()
        sex.addWidget(QRadioButton("男"))
        sex.addWidget(QRadioButton("女"))
        layout.addRow(QLabel("性别"), sex)
        layout.addRow("生日", QLineEdit())
        self.setTabText(1, "个人详细信息")
        self.tab2.setLayout(layout)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    demo = tab_Widget()
    demo.show()
    sys.exit(app.exec_())
