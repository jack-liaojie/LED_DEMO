# -*- coding: utf-8 -*-
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QDockWidget, QLabel
from frm_ovr_ListView_code import ListWidgetCode
from frm_ovr_Centwidget import tab_Widget


class OVRMainFrameForm(object):

    def __init__(self):
        self.addToolBar("Toolbar")
        self.statusBar()
        # 1.控件
        self.wdg_treeview = ListWidgetCode()
        self.wdg_tab = tab_Widget()


        self.lbl_Bottom = QLabel("lbl_Bottom")
        self.lbl_Top = QLabel("lbl_Top")
        # 2.挂件
        self.dock_Bottom = QDockWidget('BottomDock', self)
        self.dock_Top = QDockWidget('TopDock', self)
        self.dock_Right = QDockWidget('RightDock', self)
        self.dock_Left = QDockWidget('LeftDock', self)
        self.dock_Left.setWidget(self.wdg_treeview)
        self.dock_Top.setWidget(self.lbl_Top)
        self.dock_Bottom.setWidget(self.lbl_Bottom)
        # 3. 主体(上下左右中) 挂件
        self.addDockWidget(Qt.LeftDockWidgetArea, self.dock_Left)
        self.addDockWidget(Qt.RightDockWidgetArea, self.dock_Right)
        self.addDockWidget(Qt.TopDockWidgetArea, self.dock_Top)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.dock_Bottom)
        self.setCentralWidget(self.wdg_tab)


