# -*- coding: utf-8 -*-
import pymssql
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTableWidgetItem, QAbstractItemView


class open_db(object):
    __stance = None
    __Flag = False

    def __new__(cls, *args, **kwargs):
        # 初始化一个实例
        if cls.__stance is None:
            cls.__stance = super().__new__(cls)
        # 返回给__init__实例
        return cls.__stance

    def __init__(self, server, user, password, database):
        if not open_db.__Flag:
            open_db.__Flag = True
        self.conn = pymssql.connect(server, user, password, database)
        self.cursor = self.conn.cursor()

    def __enter__(self):
        return self.cursor

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.conn.commit()
        self.cursor.close()
        self.conn.close()


class get_Results(object):
    def __init__(self):
        super().__init__()
        self.description = []
        self.conn = {"server": '127.0.0.1', "user": 'sa', "password": '111', "database": 'N_EQ'}

    def get_sport(param):
        return f"exec Proc_GetSports @LanguageCode={param[0]}"

    def add_sport(param):
        return f""" exec proc_AddSport 
                        @SportCode={param[0]},
                        @OpenDate={param[1]},
                        @CloseDate={param[2]},
                        @Order={param[3]},
                        @SportInfo={param[4]},
                        @languageCode={param[5]},
                        @SportLongName={param[6]},
                        @SportShortName={param[7]},
                        @SportComment={param[8]},
                        @SportConfigValue={param[9]},
                        @Result={param[10]}
                """

    def update_sport(param):
        return f"""exec proc_EditSport
                            @Order='{param[0]}',
                            @SportCode='{param[1]}',
                            @SportLongName='{param[2]}',
                            @SportShortName='{param[3]}',
                            @OpenDate='{param[4]}',
                            @CloseDate='{param[5]}',
                            @SportID='{param[6]}',
                            @SportInfo='{param[7]}',
                            @languageCode='{param[8]}',
                            @SportComment='{param[9]}',
                            @SportConfigValue='{param[10]}',
                            @result = {param[11]} """

    def del_sport(param):
        return f""" exec proc_DelSport
                    @SportID={param[0]},
                    @Result={param[0]}"""

    def proc_AddDiscipline(param):
        return f"""EXEC proc_AddDiscipline @SportID={param[0]},@DisciplineID={param[1]},
                       @Order={param[2]},@DisciplineInfo={param[3]},@DisciplineLongName={param[4]},
                       @DisciplineShortName={param[5]},@DisciplineComment={param[6]},
                       @Result={param[7]}, @LanguageCode={param[8]}"""

    def get_sportDisciplines(param):
        return f"""EXEC Proc_GetSportDisciplines @SportID={param[0]},
                        @LanguageCode={param[1]}"""

    def get_Languages(param):
        return f""" EXEC Proc_GetLanguages """

    def get_venuelist(param):
        return f"EXEC  Proc_GetVenueList @DisciplineCode={param[0]}"

    def get_disciplineEvents(param):
        return f"""EXEC Proc_GetDisciplineEvents @DisciplineID={param[0]},
                        @LanguageCode={param[1]}"""

    def del_disciplineEvents(param):
        pass
        # return f"""EXEC Proc_GetDisciplineEvents @DisciplineID={param[0]},
        #                 @LanguageCode={param[1]}"""

    def get_IRMs(param):
        return f"""EXEC Proc_GetIRMs @DisciplineID={param[0]},
                        @LanguageCode={param[1]}"""

    def get_Functions(param):
        return f"""EXEC Proc_GetFunctions @DisciplineID={param[0]},
                        @LanguageCode={param[1]}"""

    def add_Function(param):
        return f"""EXEC Proc_AddFunction @DisciplineID={param[0]},@FunctionLongName={param[1]},
                       @FunctionShortName={param[2]},@FunctionComment={param[3]},
                       @FunctionCode={param[4]}, @FunctionCategoryCode={param[5]},
                       @Result={param[6]},@LanguageCode={param[7]}"""

    def edit_Function(param):
        return f"""EXEC Proc_EditFunction @DisciplineID={param[0]},@FunctionLongName={param[1]},
                       @FunctionShortName={param[2]},@FunctionComment={param[3]},
                       @FunctionCode={param[4]}, @FunctionCategoryCode={param[5]},
                       @Result={param[6]},@LanguageCode={param[7]},@FunctionID=={param[8]}"""

    def del_Function(param):
        return f"""EXEC Proc_DelFunction @FunctionID={param[0]},@Result={param[1]}"""

    def get_Positions(param):
        return f"""EXEC Proc_GetPositions @DisciplineID={param[0]},
                        @LanguageCode={param[1]}"""

    def add_Position(param):
        return f"""EXEC Proc_AddPosition @DisciplineID={param[0]},@PositionLongName={param[1]},
                       @PositionShortName={param[2]},@PositionComment={param[3]},
                       @PositionCode={param[4]},@Result={param[5]},@LanguageCode={param[6]}"""

    def edit_Position(param):
        return f"""EXEC Proc_EditPosition @DisciplineID={param[0]},@PositionLongName={param[1]},
                       @PositionShortName={param[2]},@PositionComment={param[3]},
                       @PositionCode={param[4]},@Result={param[5]},@LanguageCode={param[6]},@PositionID={param[7]}"""

    def del_Position(param):
        return f"""EXEC Proc_DelPosition @PositionID={param[0]},@Result={param[1]}"""

    def edit_SportActive(param):
        return f"""EXEC Proc_UpdateSportActive @LanguageCode={param[0]},@Active={param[1]},
                        @Result={param[2]}"""

    def edit_LanguageActive(param):
        return f"""EXEC Proc_UpdateLanguageActive @SportID={param[0]},@Active={param[1]},
                        @Result={param[2]}"""

    def edit_DisciplineActive(param):
        return f"""EXEC Proc_UpdateDisciplineActive @DisciplineID={param[0]},@Active={param[1]},
                        @Result={param[2]}"""

    def Proc_GetOperatorsInfo(param):
        return f"""EXEC Proc_GetOperatorsInfo """

    def Proc_GetOperatorRoles(param):
        return f"""EXEC Proc_GetOperatorRoles @PersonID={param[0]}"""

    def get_default(param):
        return "Looking forward to the Weekend"

    switcher = {
        'edit_SportActive': edit_SportActive,
        'edit_LanguageActive': edit_LanguageActive,
        'edit_DisciplineActive': edit_DisciplineActive,
        'get_sport': get_sport,
        'add_sport': add_sport,
        'update_sport': update_sport,
        'del_sport': del_sport,
        'get_venuelist': get_venuelist,
        'get_disciplineEvents': get_disciplineEvents,
        'del_disciplineEvents': del_disciplineEvents,
        'get_sportDisciplines': get_sportDisciplines,
        'get_Languages': get_Languages,
        'get_IRMs': get_IRMs,
        'get_Functions': get_Functions,
        'add_Function': add_Function,
        'edit_Function': edit_Function,
        'del_Function': del_Function,
        'get_Positions': get_Positions,
        'add_Position': add_Position,
        'edit_Position': edit_Position,
        'del_Position': del_Position,
        'Proc_GetOperatorsInfo': Proc_GetOperatorsInfo,
        'Proc_GetOperatorRoles': Proc_GetOperatorRoles
    }

    def get_SQL_results(self, tablewidget, operate_name, params):
        """
        加载数据到表控件上，执行Proc_GetSports存储过程，输入语言类型CHN.
        :operate_name:sql 名称
        :params:sql 参数
        :return:数据集
        """
        results = self.do_field(operate_name, params)
        tablewidget.setColumnCount(len(results['desc']))  # 设定列数
        tablewidget.setHorizontalHeaderLabels(results['desc'])  # 设置表头内容

        # 加载数据到表格
        i = 0
        for row in results['results']:
            j = 0
            tablewidget.setRowCount(i + 1)
            for cln in row:
                tablewidget.setItem(i, j, QTableWidgetItem(str(cln)))
                j += 1
            i += 1
        tablewidget.resizeColumnsToContents()  # 与内容同宽
        tablewidget.resizeRowsToContents()  # 设置行列高宽与内容匹配
        tablewidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 不可编辑
        tablewidget.setSelectionBehavior(QAbstractItemView.SelectRows)  # 单行选择
        tablewidget.setContextMenuPolicy(Qt.CustomContextMenu)  # 允许右键产生子菜单
        return results

    def do_field(self, operation, param):
        self.results = []
        self.description = []
        with open_db(self.conn['server'], self.conn['user'], self.conn['password'], self.conn['database']) as db:
            db.execute(self.switcher.get(operation)(param))
            self.results = db.fetchall()  # 得到结果集

            for field in db.description:
                self.description.append(field[0])
        return {'desc': self.description, 'results': self.results}

    def do(self, operation, param):
        with open_db(self.conn['server'], self.conn['user'], self.conn['password'], self.conn['database']) as db:
            db.execute(self.switcher.get(operation, self.get_default)(param))
            self.results = db.fetchall()  # 得到结果集

        return self.results


if __name__ == '__main__':
    x = get_Results()
    # y = x.do_field('get_disciplineEvents', ['1','chn'])
    y = x.do_field('get_venuelist', ['1'])

    print(y)
