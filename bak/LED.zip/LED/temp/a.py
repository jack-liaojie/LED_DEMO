# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\2020EQ\CODE\LED\a.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!
import sys
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget,QApplication,QLabel,QSizePolicy,QTableWidget, QVBoxLayout



class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(783, 522)
        self.layout = QVBoxLayout()

        self.btn = QPushButton(Form)
        self.btn.setText ="ok"
        self.btn_a = QPushButton(Form)
        self.btn_a.setText ="ok-2"

        self.layout.addWidget(self.btn)
        self.layout.addWidget(self.btn_a)

        self.btn.clicked.connect(self.open)
        self.btn_a.clicked.connect(self.open_a)
        self.index = 1
        self.setLayout(self.layout)
        self.lbl_temp ={}

    def open_a(self):
        self.lbl_temp["1_key"].setText("success")

    def open(self):
        self.lbl_temp[str(self.index) +"_key"] = QLabel(f"{self.index}")
        self.layout.addWidget(self.lbl_temp[str(self.index)+"_key"])
        self.index += 1

class code_Display(QWidget,Ui_Form):
  """docstring for code_Display"""
  def __init__(self):
    super(code_Display, self).__init__()
    self.setupUi(self)

if __name__ == '__main__':
  app = QApplication(sys.argv)
  example = code_Display()
  example.show()
  sys.exit(app.exec_())