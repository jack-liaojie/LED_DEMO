
# from PyQt5.QtCore import *
# from PyQt5.QtWidgets import *
# import sys

# arg = '43afdas'
# # print(QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss dddd"))

# sec = int(arg) if arg.isnumeric() else 300
# print(sec)

global a
a = 3

def ss():
	print(a)

def x():
	a =2
	print(a)
def sss():
	print(a)
ss()
x()
sss()
