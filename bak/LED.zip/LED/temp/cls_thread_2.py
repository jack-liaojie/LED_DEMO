
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
import sys


class TimerThread(QThread):
	"""docstring for TimerThread"""
	trigger = pyqtSignal()

	def __init__(self):
		super(TimerThread, self).__init__()
		self.flag = True
	
	def __del__(self):
		self.flag = False
		self.wait()

	def run(self): 
		while self.flag == True:
			self.sleep(1)

		self.trigger.emit()

class callThread(QWidget):

	"""docstring for ClassName"""
	def __init__(self, arg,lblobject):
		super(callThread, self).__init__()
		self.arg = arg
		self.thread = TimerThread()
		self.timer = QTimer()
		self.lblobject = lblobject
		print(type(self.lblobject))

	def start_working(self):
		"""lblobject需要传入QLabel对象"""
		global sec
		if (self.arg[0] == 'fivetime'):
			sec = int(self.arg[1]) if self.arg[1].isnumeric() else 300
			self.timer.timeout.connect(self.five_working)
		elif (self.arg[0] == 'datetime'):
			self.timer.timeout.connect(self.curr_working)

		self.thread.trigger.connect(self.stop)
		self.timer.start(1000)
		self.thread.start()

	def curr_working(self):
		d = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss dddd")
		self.lblobject.setText(d)
		print(str(d))

	def five_working(self):
		global sec
		sec -= 1
		if (sec == 0): 
			self.stop()
		else :
			self.lblobject.setText(self.intotime(sec)) #在lbl对象上显示数字
			print(self.intotime(sec))

	def stop(self):
		self.timer.stop()
		self.thread.flag = False
		global sec
		sec = int(self.arg[1]) if self.arg[1].isnumeric() else 300
		
	def intotime(self,sec):
		m, s = divmod(sec, 60)
		h, m = divmod(m, 60)
		return ("%02d:%02d:%02d" % (h, m, s))


if __name__ == '__main__':
	app = QApplication(sys.argv)
	x = callThread(['fivetime','5'],QLabel())
	x.start_working()
	# x = callThread(['datetime'],QtWidgets.QLabel())
	# x.start_working()
	sys.exit(app.exec_())
