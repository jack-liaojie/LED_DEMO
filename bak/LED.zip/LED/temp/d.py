#encoding:utf-8
'''
Created on 2016年7月10日

@author: Administrator
'''
import sys
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget,QApplication,QLabel,QSizePolicy,QTableWidget, QVBoxLayout



class ImageFrame(QMainWindow):
	def __init__(self):
		super(ImageFrame, self).__init__()
		self.initUI()

	def initUI(self):
#窗体设置
		self.setGeometry(100, 100, 500, 400)
		self.setMaximumSize(500, 400)
		self.setMinimumSize(500, 400)
		self.setVisible(True)
		self.statusBar()
		toolbar = self.addToolBar('image')
		label = QLabel()
		label.setGeometry(0, 0, 400, 400)
		self.setCentralWidget(label)
		layout = QGridLayout()
		self.label1 = QLabel()
		self.label1.setGeometry(0, 0, 200, 200)
		#设置label对齐方式
		self.label1.setAlignment(Qt.AlignLeft)
		button = QPushButton('edit')
		button.clicked.connect(self.openImage)
		edit = QLineEdit()
		layout.addWidget(self.label1, 0, 0)
		layout.addWidget(edit, 1, 0)
		layout.addWidget(button, 1, 1)
		label.setLayout(layout)

		self.updataImage()

	def openImage(self):
		imageName = QFileDialog.getOpenFileName(self,"Open file dialog","/","jpg files(*.jpg)")
		self.updataImage(imageName)

	def updataImage(self, imageName = 'icon.png'):
		pixmap = QPixmap(imageName)
		'''图像缩放:使用pixmap的scare方法，参数aspectRatioMode=Qt.KeepAspectRatio设置为等比例缩放，
		aspectRatioMode=Qt.IgnoreAspectRatio为不按比例缩放'''
		scaredPixmap = pixmap.scaled(400, 400, aspectRatioMode=Qt.KeepAspectRatio)
		#图像缩放：使用label的setScaledContents(True)方法，自适应label大小
		#self.label1.setScaledContents(True)
		self.label1.setPixmap(scaredPixmap)

if __name__ == '__main__':
  app = QApplication(sys.argv)
  example = ImageFrame()
  example.show()
  sys.exit(app.exec_())