# -*- coding: utf-8 -*-
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QMessageBox, QMenu, QApplication, QTableWidgetItem, QAbstractItemView

import ADB_running
from frmOVRBasicItemEdit import OVRBasicItemEditForm
from frm_ovr_Sport import Sport


class SportCode(QWidget,Sport):
    def __init__(self):
        super(SportCode,self).__init__()
        self.setupUi(self)
        self.resize(1024, 300)
        self.column = 0
        self.enum = []
        self.read_SQLresults(self.tblw_center, 'get_sport', ['chn'])
        self.tblw_center.customContextMenuRequested.connect(self.do_menu)  # 右键菜单
        self.tblw_center.resizeColumnsToContents()  # 与内容同宽
        self.tblw_center.resizeRowsToContents()  # 设置行列高宽与内容匹配
        self.tblw_center.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 不可编辑
        self.tblw_center.setSelectionBehavior(QAbstractItemView.SelectRows)  # 单行选择
        self.tblw_center.setContextMenuPolicy(Qt.CustomContextMenu)  # 允许右键产生子菜单

    def del_row(self):
        if QMessageBox.Ok == QMessageBox.information(self, "提示", "确定删除该数据!", QMessageBox.Cancel | QMessageBox.Ok):
            print('OK')

    def add_row(self):
        self.enum = []
        self.call_Editform()

    def edit_row(self):
        self.get_rows()
        self.call_Editform()

    def read_SQLresults(self, tablewidget, operate_name, params):
        """
        加载赛事信息，执行Proc_GetSports存储过程，输入语言类型CHN.
        :return:
        """
        x = ADB_running.get_Results()
        results = x.do_field(operate_name, params)
        tablewidget.setColumnCount(len(results['desc']))  # 设定列数
        tablewidget.setHorizontalHeaderLabels(results['desc'])  # 设置表头内容
        # 加载数据到表格
        i = 0
        for row in results['results']:
            j = 0
            tablewidget.setRowCount(i + 1)
            for cln in row:
                tablewidget.setItem(i, j, QTableWidgetItem(str(cln)))
                j += 1
            i += 1
        self.column = tablewidget.columnCount()

    def call_Editform(self):
        # 通过self.enum传递row数据
        self.instance_basicitem = OVRBasicItemEditForm(self.enum)
        # 3. 绑定处理过程，用于处理子窗体返回的消息。
        self.instance_basicitem.signel_ovrbasicitemedit.connect(self.do_SQL)
        self.instance_basicitem.show()

    def get_rows(self):
        """
        根据选定行的信息传递给frmOVRBasicItemEdit窗体进行编辑
        :param row_num: 选定行的行数
        :return: 返回执行成功与否的bool值
        """
        row_num = self.tblw_center.selectionModel().currentIndex().row()  # 将选定的行数传递
        order = self.tblw_center.item(row_num, 1).text()
        sport_code = self.tblw_center.item(row_num, 2).text()
        sport_long_name = self.tblw_center.item(row_num, 3).text()
        sport_short_name = self.tblw_center.item(row_num, 4).text()
        opendate = self.tblw_center.item(row_num, 5).text()
        closedate = self.tblw_center.item(row_num, 6).text()
        sportid = self.tblw_center.item(row_num, 7).text()
        SportInfo = ""
        lanuagecode = "CHN"
        SportComment = ""
        SportConfigValue = ""
        result = 0
        self.enum = [order, sport_code, sport_long_name, sport_short_name,
                     opendate, closedate, sportid, SportInfo, lanuagecode, SportComment, SportConfigValue, result]

    def do_SQL(self, params):
        '''
        执行更新，添加命令
        :param params: 从编辑窗体返回，编辑完成的list数据
        :return:
        '''
        x = ADB_running.get_Results()
        results = x.do('update_sport', params)
        # print(results)

    def do_menu(self, pos):
        menu = QMenu()
        menu_edit = menu.addAction(u"编辑")
        menu_add = menu.addAction(u"添加")
        menu_delete = menu.addAction(u"删除")
        menu_refresh = menu.addAction(u"刷新")
        action = menu.exec_(self.tblw_center.mapToGlobal(pos))

        if action == menu_edit:
            self.edit_row()

        elif action == menu_add:
            self.add_row()

        elif action == menu_delete:
            self.del_row()

        elif action == menu_refresh:
            self.read_SQLresults(self.tblw_center, 'get_sport', ['chn'])
        else:
            return


if __name__ == '__main__':
    app = QApplication(sys.argv)
    example = SportCode()
    example.show()
    sys.exit(app.exec_())

