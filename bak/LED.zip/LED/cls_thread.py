
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
import sys
import time


class TimerThread(QThread):
	"""docstring for TimerThread"""
	trigger = pyqtSignal()

	def __init__(self):
		super(TimerThread, self).__init__()
		self.flag = True
	
	def __del__(self):
		self.flag = False
		self.wait()

	def run(self): 
		while self.flag == True:
			self.trigger.emit()
			time.sleep(0.99)

global f_thread
global d_thread
global f_lbltime
global d_lbltime
def start_working(arg,lblobject):
	"""lblobject需要传入QLabel对象"""
	global sec
	if (arg[0] == 'fivetime'):
		global f_lbltime
		global f_thread
		f_thread = TimerThread()
		f_lbltime = lblobject
		sec = int(arg[1]) if arg[1].isnumeric() else 300
		f_thread.trigger.connect(five_working)
		f_thread.start()

	elif (arg[0] == 'datetime'):
		global d_lbltime
		global d_thread
		d_thread = TimerThread()
		d_lbltime = lblobject
		
		d_thread.trigger.connect(curr_working)

		d_thread.start()

def curr_working():
	global d_lbltime
	d = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss dddd")
	d_lbltime.setText(d)
	print(d)

def five_working():
	global sec
	sec -= 1
	if (sec == -1): 
		stop("fivetime")
	else :
		f_lbltime.setText(intotime(sec)) #在lbl对象上显示数字
		print(intotime(sec))

def stop(arg):
	if (arg == 'datetime'):
		global d_thread
		d_thread.flag = False
	elif (arg == 'fivetime'):
		global f_thread
		f_thread.flag = False
		global sec
		sec = 300
	
def intotime(sec):
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	return ("%02d:%02d:%02d" % (h, m, s))


if __name__ == '__main__':
	app = QApplication(sys.argv)
	start_working(['fivetime','5'],QLabel())
	start_working(['datetime'],QLabel())
	sys.exit(app.exec_())
