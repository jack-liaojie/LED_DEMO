# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\Develop\0_PYTHON\projects\vscode_py\qt5designer\a.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!
import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5 import *
from module.frm_schedule import Ui_Form as a
from module.frm_result import Ui_Form as b
from module.frm_judge import Ui_Form as c
from module.frm_resultlist import Ui_Form as d
from module.frm_startlist import Ui_Form as e
from module.frm_welcome import Ui_Form as f


class mod_schedule(QWidget,a):
    def __init__(self, args):
        super(mod_schedule, self).__init__(parent)
        self.setupUi(self)
        self.args = args

class mod_result(QWidget,b):
    def __init__(self, args):
        super(mod_result, self).__init__(parent)
        self.setupUi(self)
        self.args = args

class mod_judge(QWidget,c):
    def __init__(self, args):
        super(mod_judge, self).__init__(parent)
        self.setupUi(self)
        self.args = args

class mod_resultlist(QWidget,d):
    def __init__(self, args):
        super(mod_resultlist, self).__init__(parent)
        self.setupUi(self)
        self.args = args

class mod_startlist(QWidget,e):
    def __init__(self, args):
        super(mod_startlist, self).__init__(parent)
        self.setupUi(self)
        self.args = args

class mod_welcome(QWidget,f):
    def __init__(self, args):
        super(mod_welcome, self).__init__(parent)
        self.setupUi(self)
        self.args = args


    def keyPressEvent(self,event):
        '''退出窗体快捷键escape'''
        self.key = ""
        if event.key() == Qt.Key_Escape:
            self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    demo = mod_welcome()
    demo.show()
    sys.exit(app.exec_())