import sys
import json
from func_json import *
from cls_loadModule import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from frm_top_code import cod_top
from frm_bottom_code import cod_bottom
from frm_display import *

class cod_display(QWidget,Ui_Form):
	"""docstring for cod_display"""
	def __init__(self, arg):
		super(cod_display, self).__init__()
		self.ini_path = ''
		self.arg = arg
		self.setupUi(self)
		self.load_config()
		self.tempform = QWidget
		self.setWindowFlags(Qt.FramelessWindowHint)
		self.load_frame()

	def load_config(self):
		ini_path="./initialize/confige.ini"
		ini_args = read_file(ini_path)
		self.modulepath = ini_args["center"]['modulepath']
		self.x = int(ini_args["center"]['x'])
		self.y =  int(ini_args["center"]['y'])
		self.width =  int(ini_args["center"]['width'])
		self.height =  int(ini_args["center"]['height'])
		self.setStyleSheet(ini_args["center"]['stylesheet'])
		self.udp_ip = ini_args["center"]['udp_ip']
		self.udp_port = ini_args["center"]['udp_port']
		self.pic_path = ini_args["center"]['pic_path']

		self.move(self.x,self.y)#窗体定位
		self.resize(self.width,self.height) 		
		'''设置窗体图片'''
		painter = QPainter(self)
		pixmap = QPixmap(self.pic_path)
		painter.drawPixmap(self.rect(),pixmap)	

		'''设置窗体背景'''
	# def paintEvent(self,event):
		# self.move(0,0)#窗体定位
		# self.resize(1024,768) 
		# palette = QPalette()
		# palette.setColor(QPalette.Background, QColor(0x00,0xff,0x00,0x00))
		# self.setPalette(palette)	



	def load_frame(self):
		# 加入页眉和页脚
		self.ly_top.addWidget(cod_top(""))
		self.ly_bottom.addWidget(cod_bottom(""))

	def keyPressEvent(self,event):
		'''退出窗体快捷键escape'''
		self.key = ""
		# 从ly_center卸载widget
		if (self.ly_center.itemAt(0)): 
			for i in reversed(range(self.ly_center.count())): 
				self.ly_center.itemAt(i).widget().deleteLater()
				# ly_center.itemAt(i).widget().setParent(None)

		if event.key() == Qt.Key_Escape:
			try:
				self.close()
				self.arg.show()
			except Exception as e:
				raise e

		elif event.key() == Qt.Key_Left:

			self.tempform = mod_schedule(self.data_ini_args)
			self.ly_center.addWidget(self.tempform)

		elif event.key() == Qt.Key_Right:
			self.tempform = mod_judge()
			self.ly_center.addWidget(self.tempform)

		elif event.key() == Qt.Key_Up:
			self.tempform = mod_result()
			self.ly_center.addWidget(self.tempform)

		elif event.key() == Qt.Key_Down:
			self.tempform = mod_resultlist()
			self.ly_center.addWidget(self.tempform)

		elif event.key() == Qt.Key_Shift:
			self.tempform = mod_welcome()
			self.ly_center.addWidget(self.tempform)

	def load_data(self):
		data_path ="./initialize/data.ini"
		self.data_ini_args = read_file(data_path)
		a = self.data_ini_args.keys()
		
		if (a == "welcome"):
			self.tempform = mod_welcome(self.data_ini_args)
		elif (a == "result"):
			self.tempform = mod_result(self.data_ini_args)
		elif (a == "schedule"):
			self.tempform = mod_schedule(self.data_ini_args)
		elif (a == "startlist"):
			self.tempform = mod_startlist(self.data_ini_args)
		elif (a == "resultlist"):
			self.tempform = mod_resultlist(self.data_ini_args)
		elif (a == "judge"):
			self.tempform = mod_judge(self.data_ini_args)
		self.ly_center.addWidget(self.tempform)



if __name__ == '__main__':
	app = QApplication(sys.argv)
	example = cod_display("hello")
	example.show()
	sys.exit(app.exec_())